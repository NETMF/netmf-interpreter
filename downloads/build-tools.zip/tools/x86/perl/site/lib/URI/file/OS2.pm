package URI::file::OS2;

require URI::file::Win32;
@ISA=qw(URI::file::Win32);

1;
