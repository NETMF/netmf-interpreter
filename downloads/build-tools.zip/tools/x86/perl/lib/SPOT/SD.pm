#
# SPOT::SD.pm
#
# Uniform Source Depot Access from Perl
#
# Based on the Office version of SD.pm 
#
# _ALL_ perl Source Depot operations should use routines in this package.
#
# Call smueller to add missing functions as necessary.
#

package SPOT::SD;
require 5;	# some features require > 5.002, others >= 5.006, as marked


=head1 NAME

SPOT::SD - Uniform Source Depot Access from Perl

=head1 SYNOPSIS

  use SPOT::SD;
  ConfigSD(option => value);      # (optional) see ConfigSD for complete
                                  #  list of configurable options

  # query command 'sd command args' generally maps to:

  $rarray = SDCommandN(@args);    # reference-return (scalar context) multi-
                                  #  item ('N') form call is preferred ...
  #      or
                                  # ... but others:
  $rhash = SDCommand($arg);       #  single-item,
  @array = SDCommandN(@args);     #  value-returning and
  %hash = SDCommand($arg);        #  single-item, value-returning
                                  #  are supported, but deprecated

  # for commands that have multiple forms (e.g. sd change -o reports on a
  # change, other forms edit a change), there are additional
  # 'verb-specialized' functions:

  SDChange();                     # sd change (interactive form)
  $rhash = SDGetChange($ncl);     # sd change -o
  SDSetChange($rhash);            # sd change -i
  SDDelChange($ncl);              # sd change -d


  # some forms are only accessible using option specifications as in the
  # SD command line.  'sd command -opts args' maps to:

  $rhash = SDCommand(\$opts, @args);


  # all exported functions return undef (scalar context) or an empty list
  # (list context) on total failure.  Error and warning text are
  # available using:

  $sdwarning = SDWarning();       # text as one string or as array of
  @sderror = SDError();           #  lines, depending on return context


  # EXPORT_OK functions offer facilities not involving any SD server
  # including SD-style form parsing/creation and extended manipulation of
  # //depot/style/... strings.

  use SPOT::SD qw(specmatch);
  $fmatch = specmatch($arg, '//depot/*/project/...');

=head1 EXAMPLES

  # return values can be fairly complex; use Data::Dumper to get a sense
  # of what the data looks like:

  use Data::Dumper;
  $ref = SDCommandN(@args);
  print Dumper($ref);             # argument must be a reference


  # here's a canonical way to process a reference-to-array-of-references-
  # to-hashes return value:

  my $rlabels = SDLabels();          # get ref-to-array of refs-to-hashes
  foreach my $rlabel (@$rlabels) {   # foreach ref-to-hash in refed-array
      my $label = $rlabel->{Label};  # get a value from ref-to-hash
      print "$label\n";
  }


  # often, these complex return values contain more data than you care
  # about.  For example, If you're not interested in the access time and
  # description fields returned by SDLabels for each label, you can
  # extract a list of just the label names using:

  @labels = map { $_->{Label} } SDLabels();

  # if after dereferencing and selecting fields and whatnot, you find a
  # value isn't what you expect, you can sometimes use that info to lead
  # you in the right direction.  For example, if

  print $someexpression;

  # yields something like  ARRAY(0x123456)  it means you've printed the
  # reference, not what it references.  You'll probably want to try
  # @$someexpression  to get at the actual array.  Similarly, a value of
  # HASH(0x123456)  indicates you want to try  %$someexpression.

=head1 DESCRIPTION

SD.pm provides access to Source Depot from perl, in a fashion similar to that
provided by the SDAPI.

Traditionally, source control behaviour is scripted in an 'unstructured'
fashion -- calling code assembles command lines, spawns them, and parses the
output.  The SDAPI supports this model, but also offers 'structured' output
for some commands, allowing the caller to ask for specific fields by name.

SD.pm goes further in this direction.  SD.pm functions generally take
structured input -- specific positional parameters -- instead of strings of
options and filenames, and produce structured output -- hashes of results --
instead of streams of unparsed text.  Using structured input, the caller is
freed from having to worry about ordering and quoting of arguments.

Additionally, SD.pm can potentially include code to work around limitations or
irregularities of the SD command line and/or SDAPI.

Each SD command is encapsulated by one or more exported functions.  The default
behaviour for 'sd command' is exported in the function SDCommand.  More complex
SD commands have multiple forms, whose behaviour is determined by command line
options.  Such commands are encapsulated in separate SDVerbCommand exported
functions, with prefix verbs such as Get, Set and Del.  Generally, the value
returned by SDGetCommand can be passed to a subsequent SDSetCommand, with
modifications in between.  To delete existing entities, use SDDelCommand.
Extended versions of some commands are available as SDCommandEx.  These offer
capabilities not natively found in SD, but are intended to behave as if
built in.

Argument lists vary widely, but function argument order generally reflects the
SD command line argument order: options (optional, and rarely needed) come
first, followed by fixed arguments, followed by variable arguments (typically
zero or more filenames).  'verb-specializing' SD options are unnecessary
because they're implied by specific functions: e.g. use SDGetChange(...)
instead of SDChange(\'-o', ...).  To differentiate the remaining, optional
options from other arguments, they must be passed by reference, as the first
function argument, in a single string.  Options are copied unchecked into an SD
command line.  You're responsible for handling quoting, spacing and ensuring
the options are appropriate for the particular command line and particular
version of SD server you're working with.  Functions accepting structured data
can usually accept hashes or references to hashes.  In cases where more
arguments need to be passed after the hash, a hash reference is required.

Generally, exported functions return a hash of their results.  If called in
scalar context, the returned value is really a reference to a hash.  In array
context, the actual hash is returned.  Use the reference for slightly better
performance, or the actual hash for slightly more convenience.  In some cases,
the return value is a scalar (such as a changelist# or simple boolean) which is
uniformly returned, regardless of context.  Some functions can return data
about multiple files.  These are named with a trailing N, and return lists of
hashes (or references to them, depending on context).  See specific function
descriptions for argument and return details.

The keys of returned hashes usually correspond to labels in SD command output.
Non-uniformity with respect to names, case and use of spaces is inherited.

All functions return undef (or empty list in array context) in case of total
failure, generally defined as no recognized output from a spawned SD command,
an error spawning an SD command, or, in simple cases, a non-zero exit code from
a spawned SD command.  Functions may perform parameter checking and other work
before attempting to spawn SD, which can also result in failure.  You can call
SDError before any other SD.pm function to retrieve descriptive text for any
failures (i.e. an internally generated message and/or the SD command's stderr
output), even if a function doesn't return undef.  Call SDWarning for
non-failure descriptive text.

Not all output is completely structured (so you may still have to parse fields
of interest further), and not all input is either (so you may have to pass
explicit options in the optional first reference-to-scalar argument).  Where
structured data is supported, use it.  In future, more structured support will
be added.  Some SD commands and options are not supported at all.  Call
smueller to add missing functions as necessary, and in the meantime, use SDRun,
which handles ordering of arguments and quoting for you.

The SD.pm environment includes some global context information, such as whether
to echo output and (eventually) the current user, that affects the behaviour of
subsequent SD.pm functions.  Configure the environment by passing options to
ConfigSD.  Manage multiple environments yourself by saving and restoring the
hash returned by ConfigSD.

Where SD.pm behaviour differs substantially from 'sd command' or the SDAPI,
the differences will be noted in the function description.  Most common such
differences are in field names (select fields are renamed for consistency) and
error reporting (an 'sd command's stdout, stderr and exit code may ultimately
be considered in generating return values).

Currently, SD.pm invokes SD command lines and parses the text output to provide
structured results.  In future, it may use the SDAPI through a perl extension
DLL or, more likely, with IDispatch through OLE.pm.  SD.pm was developed and
tested against SD 1.6 through 3.7, with support for specific features added
on demand.

EXPORT_OK functions offer facilities for manipulating SD-style data without
necessarily referencing any SD server.  Some are extended (e.g. handling of
//depot/style/... strings with new metacharacters beyond * and ...) and others
are extensible (e.g. handling of forms with sections unknown to SD).

LIST-REF-RETURNING API (SDChanges, SDClients, ETC.) FAILURE RETURNS ARE CHANGED
SUBTLY WITH $VERSION 1.86 OF SD.PM.  Many APIs returned undef on any sd.exe
failure (i.e. non-zero exit code); these will now return partial results, if
any, and only return undef if there were no results at all -- no code changes
should be required, and data previously lost by SD.pm will be returned.  Other
APIs returned undef on any empty result set; these will now return empty lists
if sd.exe did not fail -- calling code must now be prepared for empty list ref
returns and can distinguish more easily between successful empty result sets
and failure.  There is no change when calling these APIs in list context; the
empty array still represents either 'no results' or failure.  As has always
been the case, you must check SDError()/SDExit() for absolute status.  There is
no change calling the non-N versions of APIs; these still return exactly one
result or undef.  Code correct for >= 1.86 is also correct for previous
versions of SD.pm, but the converse is not necessarily true.

=head1 DEPENDENCIES

SD.pm is essentially self-contained, providing its functionality without need
for any other files, except sd.exe (to communicate with SD servers; highest
released version is generally preferred) and a working perl 5 interpreter (5.6
or greater is preferred).  When using older perl interpreters, some behaviours
are unsupported.  When available, SD.pm will use a small number of perl
extension modules to provide slightly more refined behaviours.

Perl version dependencies:
When using a perl interpreter version $] <= 5.005:
- the 'safesync' config option is unsupported (missing core Win32::CopyFile)
- SDResolve3Ex is unsupported (missing core Win32::CopyFile and GetFullPathName
  at least)
- EditForm may be unable to invoke editor if SDFORMEDITOR="editor name" "arg"
  (system() fails to wrap command line with additional quotes to protect from
  cmd /? 'process quote' section behaviour; cpquote does not currently include
  a workaround)
When using a perl interpreter version $] <= 5.002:
- form parsing may fail (missing negative split limits)
- (spec|view)(patrep|subst) are unsupported (missing negative split limits)

Weak dependencies:
- when Win32::Console (in the standard perl distribution) is available, sd.exe
  output echoed to a console will respect SD ColorizeOutput and Attr* settings
- when Win32 (in the standard perl distribution) is available,
  SDGetEffective('SDUSER') will avoid a core Perl bug in which the machine
  domain may be substituted for the user domain
- when Win32::File (in the standard perl distribution) is available,
  SDResolve3Ex-generated merged file attributes will more closely mimic those
  of sd.exe resolve3 generated files (no hidden, system bits)

=head1 CLIENTS

Keep the list of all modules/scripts using this package current.
Modules/scripts not in this list may be broken without warning as this module
evolves.

=head1 FUTURE

Things to do/consider someday.

- complete Unix/MacOSX support including consideration/replacement of all
  Win32:: references and inline Unix/MacOSX FUTURE comments but not necessarily
  generalizing Windows-centric idioms and terminology
- share implementations among SD*, SDSet* (CreateFormCmd mirrors ParseFormCmd)
  and SDDel* subs
- provide sub name in synthinternal/synthcaller messages?
- simplify use of Parse/CreateFormFile/Cmd to not require passing all callbacks
- consider SD-internal notion of 'empty result' warnings; distinguish these
  from other warnings, allowing better failure returns and callers to decide
  for themselves more precisely.  Note that failure returns are somewhat sloppy
  but hard to fix -- SD can't provide perfect information and we must be
  backwards compatible
- old scripts use SDRun to do integrate; change them to use SDIntegrate.
- assert tagging scripts specifically still use SDRun to do revert, submit, and
  resolve.  Change them to use SDRevert, SDSubmit and SDResolve, respectively.
- jot\tools\jot.bat, mso\dw\bin\*.bat, otools\ohome\lab\aws*.bat, ots\src\...,
  contain perl code that does raw SD operations.  Change them.
- analog of SlmPak's InProject and friends to categorize status of files.
  NOTE: Slm bundles server and client status into one status field.  In SD,
  these appear to be a bit more distinct and there's also a third,
  pending-not-submitted status to consider.
- enhance %config global state control (e.g. current directory handling,
  options to sd.exe (as opposed to any particular command), SD env/registry
  variables)
- generally support more commands, more options on commands, more structured
  parsing of output, more sophisticated error/success decisions
- make form parsing more exactly match SD semantics as defined in SD sources
  support\spec[parse].cpp.  Form parsing and creation routines should use
  uniform approach, handle spaces and quoting at least as well as SD and have
  appropriate balance between simplicity and level of validation.
- for completeness, symmetry and performance (avoiding use of temp files in
  SDSetBranch/Change/Client/Label), implement and use CreateFormCmd
  (paralleling ParseFormCmd), somehow without piping both stdin and stdout
- config entry to enable more SDAPI-compatible field names
- config entry implying that SD* calls with no file arguments should operate on
  no files, rather than all files
- config entry to return undef for sample form returned for non-existent
  branches, clients, groups, labels and users from SDGet* (for all but groups,
  can use absence of Access: or Update: field)
- 'low-power mode' - a config entry controlling whether data is returned, or
  just success/failure.  (Consider huge uninteresting returns from an SDSync.)
  Implement with a no-op itemfunc (assuming widespread itemfunc support).
  Optimize automatically when ! defined wantarray (indicating caller void
  context).  Even better: 'iterator stream'-style return, retrieving items with
  an explicit NEXTVAL call (see 'Higher Order Perl').  Will need to handle
  simultaneous streams (so, per-SDCommand-stream %fspec, etc.) and caller
  ConfigSD while a stream is active (so, per-SDCommand-stream config, too) --
  likely, all globals.  See sub _SDSet.
- 'error parsing mode' - a config entry controlling whether known warnings/
  errors are returned in structured data.  (Consider what to return if exists
  $_->{errorFile} foreach @open.)
- document all the types of output lines that are expected by each command
- file types are generally in the old but ubiquitous monolithic form; add a
  config entry controlling mapping to base type + modifiers form
- allow calling APIs with references to lists of arguments (extra credit:
  within lists of arguments); use array references internally to avoid
  duplicating potentially large lists.  There need be no ambiguity with options
  (which are always scalar references).
- allow options as a reference to a hash as well as a string?
- allow options using indirect object syntax? (perl may only allow code block)
- function headers are imprecise about reference return; add \es to emphasize
  preferred form, and to be consistent with /undef failure alternative
- podify function headers
- should functions proactively provide fields not returned by corresponding sd
  commands?
- group EXPORT_OK names based on suitable EXPORT_TAGS
- use pseudohashes for return values? (likely not; pseudohashes are deprecated)
- implement more extensive debug/verbose mode that doesn't delete temp files,
  logs spawned processes, etc.  (when done, use osystem.pm's open() wrapper)
- move Administrator commands into a separate SDAdmin module?
- modify behaviour based on expected/detected version of sd.exe? (e.g. assume
  -u LocalSystem (SD client change 9205) by default for sd.exe >= 3.0)
- ensure non-N function arguments don't contain wildcards?
- drop single-item (SDFoo) APIs and rename SDFooN multi-item APIs as SDFoo,
  while minimizing backwards-compatibility pain (consider absolute FooN, with
  old/new Foo behaviour dictated by config option; somewhat analogous to
  Windows A/W/no suffix APIs)
- drop non-reference returns, generating caller error like nto1
- convert to/support SDAPI.  First step: consider converting to use -ztag=1
  structured output from command line SD in all commands that support it.  Use
  a common parser.  Really make field names consistent.  Create a general field
  name mapping table/mechanism for these.  Caveats: -ztag=1 treats as data some
  values that in normal output are warnings; echoInfo output when using -ztag=1
  is ztag-style, not standard.  Consider configuring -ztag=1 usage in ConfigSD.

=head1 AUTHOR

Stephan Mueller (smueller)

=cut



$VERSION = '2.93';	# find references for backwards incompatible changes

use strict;
#use warnings;	# FUTURE: enable (local suppression too) for perl $] >= 5.006
use Exporter;

@SPOT::SD::ISA = qw(Exporter);
@SPOT::SD::EXPORT = qw(
	brnDefault nclDefault
	echoNone echoText echoInfo echoWarning echoError echoInternal echoCaller
	echoStd echoAll
	sdcClient sdcServer

	InitSD ConfigSD

	SDBranch SDGetBranch SDSetBranch SDNewBranch SDDelBranch SDBranches
	SDChange SDGetChange SDSetChange SDNewChange SDDelChange SDChanges
	SDClient SDGetClient SDSetClient SDDelClient SDClients
	SDGetCounter SDSetCounter SDDelCounter SDCounters
	SDDescribe SDDescribeN
	SDDiff SDDiffN
	SDDiff2 SDDiff2N
	SDDiffSummary
	SDDirs
	SDEdit SDEditN SDAdd SDAddN SDDelete SDDeleteN
	SDFileLog SDFileLogN
	SDFiles SDFilesN
	SDFlush SDFlushN SDBranchFlush SDBranchFlushN
	SDFstat SDFstatN
	SDGetGroup SDDelGroup SDGroups
	SDHave SDHaveN
	SDInfo
	SDIntegrate SDIntegrateN
	SDIntegrated SDIntegratedN
	SDLabel SDGetLabel SDSetLabel SDDelLabel SDLabels
	SDLabelSync
	SDOpened SDOpenedN SDOpenedEx SDOpenedExN
	SDPrint SDPrintN SDPrintFile
	SDReopen SDReopenN
	SDResolve SDResolveN SDResolve2 SDResolve3 SDResolve3Ex
	SDResolved SDResolvedN
	SDRevert SDRevertN
	SDReview SDReviews
	SDSubmit SDSubmitError SDSubmitWarning
	SDSync SDSyncN SDBranchSync SDBranchSyncN
	SDUnlock SDUnlockN
	SDUser SDGetUser SDSetUser SDDelUser SDUsers SDUsersN
	SDWhere SDWhereN

	SDAdminInfo
	SDAdminSet
	SDAdminStatus SDAdminStatusN
	SDPurgeBin SDPurgeBinN SDObliterate SDObliterateN
	SDProxies SDGetProxies SDSetProxies
	SDProtectionsAccess
	SDTypeMap SDGetTypeMap SDSetTypeMap
	SDVerify SDVerifyN

	SDRun
	SDSet
	SDWarning SDError SDExit
	SDVersion SDAtLeastVersion
	SDSyncSD
	SDGetEffective
);

@SPOT::SD::EXPORT_OK = qw(
	tnNormal tnAliases tnAll tnTypeOnly tnModOnly

	cpquote

	echotype defechofunc clearwarnerr enext splitqs

	ParseFiles ParseView ParseOptions
	ParseNames ParseProtections ParseTypeMap
	ParseForm ParseFormFile ParseFormCmd

	CreateFiles CreateView CreateOptions
	CreateNames CreateProtections CreateTypeMap
	CreateForm CreateFormFile

	SetFormError EditForm EditChangeForm

	ParseSDAliasesIni ParseSDAliasesIniFile

	CreateSDAliasesIni CreateSDAliasesIniFile

	autoopt

	splitspec specstr unspecstr
	quotesdmeta specpat unspecpat specmatch
	specpatint specintersect
	specpatrep specsubst viewpatrep viewsubst

	expextspec

	typenorm
);



# manifest constants
sub brnDefault	() { '' }		# default branch
sub nclDefault	() { 0 }		# default changelist

sub echoNone	() { 0 }		# echo no output but (unsuppressable) prompts
sub echoText	() { 1 << 0 }	# echo output matching ^text\d?:
sub echoInfo	() { 1 << 1 }	# echo output matching ^info\d?:
sub echoWarning	() { 1 << 2 }	# echo output matching ^warning\d?:
sub echoError	() { 1 << 3 }	# echo output matching ^error\d?: or unmarked
sub echoInternal() { 1 << 4 }	# echo synthesized output matching ^internal:
sub echoCaller	() { 1 << 5 }	# echo synthesized output matching ^caller:
sub echoStd		() { echoText | echoInfo | echoWarning | echoError }
# AS OF $VERSION 2.71, echoAll INCLUDES echoInternal AND echoCaller, which will
# result in coding errors being echoed that were previously not.  Use echoStd
# for previous behaviour, but prefer to keep using echoAll.
sub echoAll		() { echoStd  | echoInternal | echoCaller }

sub tnNormal	() { 0 }		# include no implicit flags in typenorm output
sub tnAliases	() { 1 }		# tnNormal, but using aliases when available
sub tnAll		() { 2 }		# include implicit modifier flags
sub tnTypeOnly	() { 3 }		# include no flags, just base type
sub tnModOnly	() { 4 }		# include all flags, but no base type

sub sdcClient	() { 'sd'  }	# request version of sd.exe component
sub sdcServer	() { 'sds' }	# request version of sds.exe component


# globals
use vars qw(@sdwarning @sderror $sdexit);
use vars qw(%fspec %bin %config %configDef);
use vars qw($finitsd $fwin $funix);



#
# Implementation Notes
#
# There is a certain monotonous consistency to the implementation of the
# standard exports providing access to sd commands in this module.  This is a
# good thing.
# - all SD commands are spawned using sdpopen to capture and parse stdout and
#   stderr through a pipe.  info is returned immediately; warnings and errors
#   are saved for inspection on demand by SDWarning and SDError.  Backticks
#   can't be overridden, avoid them.
# - sd -s is used to coerce all (well, most) output to stdout, and prefix each
#   line with a type indicator.  Output that's not prefixed is assumed to be an
#   error.  Specific text is treated exceptionally.  All output seen by callers
#   or written to stdout is mapped to standard (non -s) output using mappd;
#   callers should not know we use -s.
# - simple functions respect the close *PIPE return value: $? != 0 means
#   failure, so return undef.  Otherwise, return parsed stdout/err.
# - complex functions ignore close *PIPE return value: parse stdout/err and
#   return parsed recognized text.  Return undef only if there was no
#   recognized text.
# - all command tokens are properly quoted using crtquote.  Most are handled
#   in sdpopen, but functions using ParseFormCmd must do so explicitly.
# - options are separated from arguments by '--' when subsequent arguments may
#   look like options.  Most are handled in sdpopen, but functions using
#   ParseFormCmd must do so explicitly.
# - if an SD command requires input beyond command line arguments (e.g. sd
#   command -i < input), input is written to a temp file, which is then passed
#   using input redirection in an open(PIPE, ...) as above.
# - every exportable function ensures @sderror is updated to reflect the cause
#   of an internal error.
#
# A small number of exports (typically ending in 'Ex') are macro functions
# encapsulating extensions to standard commands.  These are usually implemented
# as calls to multiple non-Ex exports.  Others implement unique functionality
# with one or more calls to other exports.  Such exports must appear to callers
# to be native; hence, macro functions must explicitly manage:
# - @sdwarning/error: to ensure errors from each export function call augment,
#   instead of replacing previous ones
# - @config{echo}: to ensure callers do not see implementation detail output.
#   In general, unexpected output (typically warnings and errors) should
#   respect config echo settings, whereas echo of expected output (typically
#   all text and info and perhaps select warnings and errors) should be
#   suppressed.  Put another way, interface (return value) of a macro function
#   is yours to define, but errors encountered are _not_ yours to hide
# - clean up/rollback on failure: to ensure callers see no partial results
#
# FUTURE: utilities to support aspects of macro functions, such as:
# - a mechanism to prevent clearwarnerr from doing anything in an inferior
#   export call.
# - a standard wrapper echofunc for filtering specific warnings/errors given a
#   predicate.  Use the same predicate with grep to accumulate only warnings/
#   errors that would be echoed.
#
# Some exports have non-exported '_'-prefixed variants.  These internal forms
# allow internal callers access to the exported API without side effects (no
# change to @sdwarning/error, no echo output, no interference with pipeless
# mode).  When calling an internal form, a caller must be prepared to continue
# on partial or total failure without details -- degrading gracefully in the
# absence of the requested but unavailable information.  Consider results from
# internal forms like 'optimization hints'.  Limit internal forms to simple
# exports (e.g. _SDSet, _SDAtLeastVersion) implemented using sub internal.
#



#
# Utilities
#

# internal constant regular expressions
# trailing count indicates number of paren groups in pattern, if any
# FUTURE: redu[c2] Unix/MacOSX awareness of domain accounts?
# FUTURE: use of counting and non-counting paren groups is somewhat arbitrary
use vars qw($redatime $redu $reduc2 $reftype1 $rever4 $remplat2);
$redatime = qr!\d{4}/\d\d/\d\d \d\d:\d\d:\d\d!;	# a d/a/te t:i:me pair
$redu     = qr/(?:\S+\\)?\S+/;				# user or domain\user
$reduc2   = qr/((?:\S+\\)?\S+)\@(\S+)/;		# user@client or domain\user@client
$reftype1 = qr/[a-z]+(\+[kemwx0CDFS]+)?/;	# type+modifier like binary+Swx
$rever4   = qr/(\d+)\.(\d+)\.(\d+)\.(\d+)/;	# SD[S] component version string
$remplat2 = qr/(?:(\w+) )?\((.*)\)/;  		# Beta modifier (platform)

# internal constant wildcard codes; ensure variable usages don't cause
# unnecessary regex recompilation by adding /o to operators involving patterns
# where only variable references are to these constants
# FUTURE: use illegal-in-depotspec (per SD (@#) or Windows (\/:*?"<>|))
# characters as placeholder metacharacters, avoiding assumptions (even if true)
# that \xfe and \xff are never legal in filenames?  \/ are obviously bad.  : is
# already used for meta-escaping (specpat/specmatch -> :*/:.../::, specpatrep/
# specsubst/viewpatrep/viewsubst -> :*/:...).  Avoid ? for future SD wildcard
# enhancements.  @" will need extra perl escaping because they are meaningful
# to perl.  <|> are already used for extended syntax, leaving just # with no
# strings attached.
# FUTURE: does Unix/MacOSX sd client allow any of :, <, |, >, ?  Reconcile
# regular and meta-usages somehow: config entry?  disallow regular usage or
# disable extended syntax in SD.pm?  Consider effects of *, ?, " if allowed as
# well.
# FUTURE: create constant subs for use in non-interpolated contexts?
# FUTURE: swap star and dots values to allow min/max comparisons?
use vars qw($star $dots $esc $mstar $mdots);
$star = "\xff";					# canonicalized *, %n in spec comparison subs
$dots = "\xfe";					# canonicalized ... in spec comparison subs
$esc = ':';						# NOTE: SD.pm invention for literalizing *, ...
$mstar = "([^\\\/$dots]*?)",	# capturing regex as string to match *, %n
$mdots = '(.*?)';				# capturing regex as string to match ...


#
# inlist - Return number of times val occurs in list.
#
sub inlist {
my ($val, @list) = @_;
	return scalar grep { $_ eq $val } @list;
}


#
# opt - Emphasize an argument is optional (i.e. to be passed by reference).
# Return the reference.  FUTURE: export?
#
sub opt ($) {
	return \$_[0];
}


#
# shiftopts - If first element of ary is a scalar reference, shift ary and
# return the referent, else return the empty string.
#
sub shiftopts (\@) {
	return (ref $_[0]->[0] eq 'SCALAR') ? ${shift(@{$_[0]})} : '';
}


#
# rshifthash - If first element of ary is a hash reference, shift ary and
# return the reference, else return a reference to rest of ary as a hash.
# Caller must be sure not to modify returned hash as it may belong to
# caller's caller.
#
sub rshifthash (\@) {
	if (ref $_[0]->[0] eq 'HASH') {
		return shift(@{$_[0]});
	} else {
		my %hash = @{$_[0]};
		return \%hash;
	}
}


#
# crtquote - Return list as string, quoted according to C RunTime rules.
#
# This variant handles embedded quotation marks but with caveats -- compare and
# contrast before copying.
#
# AS OF $VERSION 2.69, EMPTY AND UNDEFINED ITEMS ARE NO LONGER REMOVED FROM
# LIST, which will result in SD reporting "An empty string is not allowed as a
# filename." errors in SDError() that were previously silently ignored.  If an
# empty string/undef is the only argument to an SDFoo API, the API will now
# return undef; previously results were returned as if the argument '//...' had
# been specified.  In all other cases, return values are unchanged.
#
# FUTURE: by handling embedded quotation marks, we can confuse cmd.exe (e.g.
# when   foo"bar<zot   is quoted by crtquote, cmd.exe will see   <zot   as
# outside the string and treat it as a redirection token)
# FUTURE: don't quote strings with no spaces or cmd.exe metacharacters
#
sub crtquote {
my(@list) = @_;

	return ''	if @list == 0;
	# double trailing \es so they don't inadvertently escape delimiting "
	map { s/(\\*)$/$1x2/e } @list;
	# escape all in sequences of (zero or more) \es followed by "
	map { s/(\\*)"/$1x2 . '\\"'/eg } @list;
	return '"' . join('" "', @list) . '"';
}
sub crtquote_unix {		# dynamically selected if appropriate in InitSD
my(@list) = @_;

	return ''	if @list == 0;
	# escape all $, `, " and \es per man bash; /QUOTING
	map { s/([\$\`\"\\])/\\$1/g } @list;
	return '"' . join('" "', @list) . '"';
}


#
# cpquote - Attempt to quote an ambiguous command line (i.e. one potentially
# containing spaces in command name, but not necessarily quoting command name)
# in the manner of CreateProcess, as used by sd.exe to locate form and text
# editor (various commands), diff tool (diff and resolve), and pager and merge
# tool (resolve).  Return a more explicitly quoted form of cmdline, more
# suitable for system()/open("| ..."), if possible.  There is no guarantee that
# returned cmdline will be executable.  There is no guarantee that all and only
# command lines executable by CreateProcess will be executable by system()/
# open("| ...") after processing here.  cpquote is used in SD.pm only by
# EditForm to invoke form editor.  It is exportable for caller convenience in
# similar circumstances (i.e. for invoking tools specified in SD variables to
# mimic SD behaviour) even though not directly related to SD.
#
# FUTURE: refine emulation of CreateProcess 'IntelliSense' and any additional
# behaviour that differs from plain system(), or switch to using the real thing
# FUTURE: prepend 9>nul if command line includes any redirection (forcing use
# of cmd.exe) and starts with a quote to avoid cmd stripping of first and last
# (not matching!) quotes with perl $] == 5.005.
#
sub cpquote {
my($cmdline) = @_;

	if ($cmdline =~ / / && $cmdline !~ /^"/) {
		while ($cmdline =~ /( +|$)/g) {
			my $cmd = substr($cmdline, 0, pos $cmdline);
			$cmd =~ s/ *$//;
			if (-f $cmd) {
				return qq/"$cmd" / . substr($cmdline, pos $cmdline);
			} else {
				# CreateProcess appears to actually not support bat, cmd
				foreach my $ext (qw(com exe bat cmd)) {
					if ($cmd !~ /\.$ext$/i && -f "$cmd.$ext") {
						return qq/"$cmd.$ext" / . substr($cmdline, pos $cmdline);
					}
				}
			}
		}
		if ($cmdline =~ /^ *$/) {	# pathological, but avoids space-only
			return qq/"$cmdline"/;	#  cmdline using associations to start doc
		}
	}

	return $cmdline;
}
sub cpquote_unix {	# dynamically selected if appropriate in InitSD
	return $_[0];
}


#
# mappd - Map 'prefixed' lines (e.g. 'warning1: blah') to 'dotted' lines
# (e.g. '... blah').  Return mapped lines.
#
sub mappd {
my(@lines) = @_;

	s/^\w+?(\d*):\s/'... ' x $1 if $1/e		foreach @lines;
	return wantarray ? @lines : $lines[0];
}


#
# mapdp - Map 'dotted' lines (e.g. '... blah') to 'prefixed' lines
# (e.g. 'warning1: blah').  Return mapped lines.
#
sub mapdp {
my($prefix, @lines) = @_;
	my $l;
	s!^((\.\.\.\s)*)!($l = ($1 ? length($1)/4 : '')), "$prefix$l: "!e
		foreach @lines;
	return wantarray ? @lines : $lines[0];
}


# FUTURE: move all synth* definitions to avoid need for any forward references
use subs qw(synthinternal synthcaller);


#
# systemredir - system("0<infspec 1>outfspec 2>errfspec command") without using
# cmd.exe, avoiding external dependency, extra process invocation and cd-can't-
# be-UNC limitation.  Return value analogous to that returned by system(): exit
# code from spawned process or -1 on failure to spawn (here, including failure
# in preparatory open()s).  On failure to spawn, inspect $! for reason.  Any of
# infspec, outfspec and errfspec may be undef, indicating no redirection of
# corresponding handle should be performed.  Note that redirections are
# processed in the order shown above, so fspecs such as '&STDOUT' will refer to
# original STDOUT as infspec (an unlikely example), but new STDOUT as errfspec.
#
# ...all assuming no literal redirections in command force use of cmd.exe,
# which is not supported.  If cmd.exe is invoked, at least leading redirection
# (which caller must ensure) is necessary to avoid quote stripping.
#
# Implementation redirects STDIN, STDOUT and STDERR, then restores them.  If a
# standard handle appears not to exist on entry, (e.g. SD server running as a
# service spawns triggers with no stderr) it will be 'restored' as a real
# handle to nul on sub exit.  Doing so avoids a perl $] ~= 5.006 bug, where a
# subsequent open (perhaps reusing the missing handle's descriptor?) succeeds,
# but the newly opened handle only permits one I/O operation of any kind before
# claming to be at EOF.
#
# FUTURE: test Unix/MacOSX behaviour carefully: while code is portable, it's
# sensitive to implementation details of perl I/O and process handling
# FUTURE: we assume open failure leaves handle unchanged; ensure this is true
# FUTURE: assert no inappropriate redirections in command (requires accurate
# quote parsing)?
# FUTURE: have caller include <, >, >> or otherwise reasonably support append
# FUTURE: have caller include 0<, 1>, 2> to indicate order, allowing control
# over what &STDOUT references and eliminating need for undef placeholders
#
sub systemredir {
my($command, $infspec, $outfspec, $errfspec) = @_;

	my $bang;
	my $ret = -1;
	my ($fsavin, $fsavout, $fsaverr);
	my $funlink = 1;
	local (*SAVIN, *SAVOUT, *SAVERR);

	if (defined $infspec) {
		# defined fileno(HANDLE), at least in perl $] <= 5.008, assumes STD*
		# open on script entry, even if no stream is available to inherit.
		# clear $^W to suppress 'stat() on closed/unopened filehandle'
		#no warnings qw(unopened);	# enable for perl $] >= 5.006
		$fsavin = do { local $^W = 0; stat STDIN };
		if ($fsavin && ! open(SAVIN, '<&STDIN')) {
			$bang = $!;
			synthinternal "can't dup STDIN\n";
			goto ERROR_SAVIN;
		}
		if (! open(STDIN, "<$infspec")) {
			$bang = $!;
			synthinternal "can't open $infspec for read as STDIN\n";
			goto ERROR_STDIN;
		}
	}

	if (defined $outfspec) {
		$fsavout = do { local $^W = 0; stat STDOUT };
		if ($fsavout && ! open(SAVOUT, '>&STDOUT')) {
			$bang = $!;
			synthinternal "can't dup STDOUT\n";
			goto ERROR_SAVOUT;
		}
		if (! open(STDOUT, ">$outfspec")) {
			$bang = $!;
			synthinternal "can't open $outfspec for write as STDOUT\n";
			goto ERROR_STDOUT;
		}
		select((select(STDOUT), $| = 1)[0]);	# make unbuffered
	}

	if (defined $errfspec) {
		$fsaverr = do { local $^W = 0; stat STDERR };
		if ($fsaverr && ! open(SAVERR, '>&STDERR')) {
			$bang = $!;
			synthinternal "can't dup STDERR\n";
			goto ERROR_SAVERR;
		}
		if (! open(STDERR, ">$errfspec")) {
			$bang = $!;
			synthinternal "can't open $errfspec for write as STDERR\n";
			goto ERROR_STDERR;
		}
		select((select(STDERR), $| = 1)[0]);
	}


	# prep successful
	$! = 0;
	$ret = system($command);	# inherits STDIN, STDOUT, STDERR
	$bang = $!;
	$funlink = 0	if ! $!;


  SUCCESS:
	if (defined $errfspec) {
		close STDERR;
		unlink $errfspec
			if $funlink && $errfspec !~ /^&/ && ! $config{verbose};
		open  STDERR, $fsaverr ? '>&SAVERR' : '>nul';
  ERROR_STDERR:
		close SAVERR				if $fsaverr;
	}

  ERROR_SAVERR:
	if (defined $outfspec) {
		close STDOUT;
		unlink $outfspec
			if $funlink && $outfspec !~ /^&/ && ! $config{verbose};
		open  STDOUT, $fsavout ? '>&SAVOUT' : '>nul';
  ERROR_STDOUT:
		close SAVOUT				if $fsavout;
	}

  ERROR_SAVOUT:
	if (defined $infspec) {
		close STDIN;
		# don't unlink $infspec; not created here
		open  STDIN, $fsavin ? '<&SAVIN' : '<nul';
  ERROR_STDIN:
		close SAVIN					if $fsavin;
	}

  ERROR_SAVIN:
	$! = $bang;
	return $ret;
}


#
# _sdpopen - Common code to open a pipe to read sd command output, shared for
# use by sdpopen and sdprestart.
#
# ph indicates handle to connect as stdout/stderr reader to spawned opencmd,
# with opencmd's stdin optionally connected to infspec if defined.  caller
# indicates caller in verbose output.
#
# NOTE: in case of multiple redirections, last (rightmost) one wins.  Also, any
# 1> redirection wins over |, which can be usefully exploited by callers with
# redirection specified as part of opencmd.  Finally, open()-invoked cmd.exe
# may strip first and last (not matching!) quotes from command line if first
# character is a quote with perl $] == 5.005; placing redirection first ensures
# first character is not a quote, preventing cmd stripping.  (See cmd /?
# 'process quote' section.)
#
# FUTURE: test Unix/MacOSX behaviour carefully: while code is portable, it's
# sensitive to implementation details of perl I/O and process handling
# FUTURE: 2>&1 is all that forces cmd.exe invocation in pipe case.  Consider
# config option to eliminate it (for e.g. SDSet which never writes to stderr)?
# Investigate IPC::Open3 and CPAN IPC::Run for black magic to send spawned
# stdout and stderr to same filehandle here.  See also perldoc perlipc.
# Ask SD team to ensure sd.exe _never_ writes to stderr with sd -s, then don't
# bother to capture it.
# FUTURE: If avoiding cmd.exe is infeasible, consider pushd to avoid
# cd-can't-be-UNC limitation
#
sub _sdpopen (*$$$) {
my($ph, $opencmd, $infspec, $caller) = @_;

	my $inredir = defined $infspec ? '0<' . crtquote($infspec) . ' ' : '';
	if ($config{pipeless}) {
		print "$caller: spawning: [${inredir}1>" . crtquote($fspec{pip}) . " 2>&1] $opencmd\n"
			if $config{verbose};
		$! = 0;
		systemredir($opencmd, $infspec, $fspec{pip}, '&STDOUT');
		if ($!) {  # failed to spawn, not related to spawned program exit value
			synthinternal "can't run $opencmd\n";
			return;
		}
		if (! open($ph, "< $fspec{pip}")) {
			synthinternal "can't open $fspec{pip} for read\n";
			return;
		}
	} else {	# normal, pipe-based case
		$opencmd = "${inredir}2>&1 $opencmd |";
		print "$caller: spawning: $opencmd\n"	if $config{verbose};
		if (! open($ph, $opencmd)) {
			synthinternal "can't run $opencmd\n";
			return;
		}
	}

	binmode $ph		if $config{binmode};
	return 1;
}


#
# sdpopen - Open a pipe to read stdout and stderr from an sd command.
#
# Most commands are non-interactive, so stdin is generally irrelevant.  Some
# commands may require input and issue prompts using incomplete (i.e. non-\n
# terminated) lines.  For such commands, caller is responsible for passing a
# reference to an option string containing 'interactive' as the first argument
# after the filehandle to indicate that reads should be character-oriented
# (slow) instead of line-oriented (default, not slow).  Specifying the
# interactive option when not necessary is generally OK but slow.  Omitting the
# option when required can result in prompts not being displayed and treated as
# unknown leading text on subsequent 'real' output.  To avoid user confusion,
# interactive commands should probably always be used with
#   ConfigSD(echo => echoAll)
# so prompt context is also displayed.  The interactive option to sdpopen is
# incompatible with config{pipeless}.
#
# Known cases:
# - all commands using ShowForm (which prompt with 'Hit return to continue...'
#   on form errors)
# - SDResolve* (which prompt for merge actions with variants like
#   'Accept(a) Edit(e) Diff(d) Skip(s) Help(?) [am]: ' and
#   'Accept (at/ay) Edit (et/ey) Skip (s) Help (?) [s]: ')
#   and also
#   'File is not textual.  Are you sure you want to edit the file (y/n)? '
#   'This overrides your changes: confirm accept (y/n)? '
#   'There are still change markers: confirm accept (y/n)? '
# sdpreadlinec and readfilt need to remain in sync concerning these.
#
# Include 'ztag' in first-argument-after-filehandle option string to invoke
# sd.exe with -ztag=1 option if caller is prepared to parse structured mode
# output.
#
# Include "<$fspec" in option string to invoke sd.exe with stdin redirected
# to read from $fspec, useful principally for passing forms in SDSet* commands.
#
# Specify multiple values in option string by separating with |.  (This allows
# values to contain spaces and somewhat distinguishes options to sdpopen from
# option strings intended for sd.exe.)
#
# @args are quoted and appended if present (with '--' separator).  If resulting
# command line would annoy cmd.exe, use sd -x file to work around line length
# limitation.  If -x file would annoy -ztag=1, use multiple consecutive -x
# files to work around argument count limitation.  Return 1/undef on success/
# failure, respectively.  Set sderror in case of failure, too.  Redirection may
# be usefully specified by callers as part of cmd.
#
# FUTURE: handle -i fspec{ini} as flag in $sdpopenopts, not text in $cmd
# FUTURE: consider making $sdpopenopts an array reference instead of string,
# eliminating need for unavailble-in-data separator character?
# FUTURE: return $ph instead of taking one as argument.  Interface would be
# different from open, but more rational.  Messy typeglob issues; return a
# real struct for extra goo?
#
sub sdpopen (*;@) {
my $ph = shift(@_);
my $sdpopenopts = shiftopts(@_);
my($cmd, @args) = @_;

	# reasonably central place to trap lack of initialization
	if (! $finitsd) {
		my ($pkg, $file, $line, $sub) = caller(1);
		$sub =~ s/.*:://;	# trim package name
		die __PACKAGE__ . ".pm: $sub: InitSD not called\n"
	}

	# parse and validate sdpopen options
	my ($finteractive, $fztag, $infspec);
	foreach my $opt (split /\|/, $sdpopenopts) {
		if ($opt eq 'interactive') {
			$finteractive = 1;
		} elsif ($opt eq 'ztag') {
			$fztag = 1;
		} elsif ($opt =~ /^<\s*(.*)$/) {
			$infspec = $1;
		} else {
			synthcaller "invalid sdpopenopts component $opt\n";
			return;
		}
	}

	# validate combinations of options
	if ($config{pipeless} && $finteractive) {
		synthcaller "interactive commands cannot be pipeless\n";
		return;
	} elsif (defined $infspec && @args) {
		synthcaller "commands with <input cannot also have args\n";
		return;
	}

	my @opts;
	push @opts, '-i', crtquote($config{ini})	if defined $config{ini};
	push @opts, '-c', crtquote($config{client})	if defined $config{client};
	push @opts, '-d', crtquote($config{dir})	if defined $config{dir};
	push @opts, '-H', crtquote($config{host})	if defined $config{host};
	push @opts, '-M', crtquote($config{maxresults})
												if defined $config{maxresults};
	push @opts, '-p', crtquote($config{port})	if defined $config{port};
	push @opts, '-R', crtquote($config{proxy})	if defined $config{proxy};
	push @opts, '-P', crtquote($config{password})
												if defined $config{password};
	push @opts, '-u', crtquote($config{user})	if defined $config{user};
	push @opts, '-s';	# prefixed output always and guarantees @opts not empty
	push @opts, '-ztag=1'						if $fztag;
	my $opts = join(' ', '', @opts);

	my $opencmd = crtquote($bin{sd}) . $opts;

	my $args = ' ' . crtquote(@args);
	$args = ''	if $args eq ' ';

	my $dash = ($args ne '' && $cmd !~ / --/) ? ' --' : '';

	# Scary hack: $ph is really a typeglob, not just a filehandle.  Store
	# read function in unused slot for use by readfilt.
	*$ph = $finteractive ? \&sdpreadlinec : \&sdpreadline;

	# Estimate command length based on string assembly (here and in _sdpopen).
	# 50 is generous slop for small constant components (e.g. $dash, '2>&1').
	# FUTURE: be more precise (less slop) and consider config{pipeless}
	my $openlen = length($opencmd) + length($cmd) + length($args) + 50;
	$openlen += length(crtquote($infspec))	if defined $infspec;

	# 4096 is cmd.exe and POSIX (e.g. GNU xargs --show-limits) minimum limit
	# FUTURE: consider limits beyond total length; e.g. csh words must be <1K
	if ($openlen < 4096 && (@args <= 128 || ! defined $config{batchfunc})) {
		$opencmd .= " $cmd$dash$args";
	} else {	# use response file
		# FUTURE: can fspec{arg} (derived from %TEMP%) result in long line on
		# Unix/MacOSX?  If so, synthinternal/return? detect in Init/ConfigSD
		# and replace with ''?
		$opencmd .= ' -x ' . crtquote($fspec{arg}) . " $cmd$dash";
		local *FILE;
		if (! open(FILE, "> $fspec{arg}")) {
			synthinternal "can't open $fspec{arg} for write\n";
			return;
		}
		if ($fztag || defined $config{batchfunc}) {
			# sd.exe 3.7 (at least) and below only return structured values for
			# the first batch of 128 arguments sent to the server from a
			# response file.  When using -ztag=1, ensure the response file
			# never contains more than 128 entries.  sdpreadline* is
			# responsible for starting a new response file and command when the
			# current command stops returning output.  Also keep response file
			# size small when using batchfunc, so there are batches between
			# which to call it.
			# Scary hack: $ph is really a typeglob, not just a filehandle.
			# Store opencmd and remaining arguments into unused slots for use
			# by sdpreadline*.
			@{*$ph} = splice @args, (@args <= 128 ? scalar @args : 128);
			${*$ph} = $opencmd;
		}
		print FILE join("\n", @args), "\n";
		close FILE;
	}

	return _sdpopen($ph, $opencmd, $infspec, 'sdpopen');
}


#
# sdprestart - Refresh response file with next batch of arguments and restart
# SD command.
#
sub sdprestart (*) {
my($ph) = @_;

	return if ! @{*$ph};	# no arguments

	close $ph;

	# FUTURE: pass some useful arguments
	$config{batchfunc}->()		if defined $config{batchfunc};

	local *FILE;
	if (! open(FILE, "> $fspec{arg}")) {
		synthinternal "can't reopen $fspec{arg} for write\n";
		return;
	}
	# FUTURE: allow configuring batchsize?
	my @args = splice @{*$ph}, 0, 128;
	print FILE join("\n", @args), "\n";
	close FILE;

	# sdpopen enforces either an input file or arguments, never both, so if
	# batching (i.e. we get here) there are many aguments and can be no infspec
	return _sdpopen($ph, ${*$ph}, undef, 'sdpreadline[c]');
}


#
# sdpreadline[c] - Read from pipe opened by sdpopen, either line-oriented
# (sdpreadline) or character-oriented (sdpreadlinec).  On EOF, if there are
# arguments stashed in unused slots of ph (scary hack), start a new response
# file and command to generate more output.  Close eyes to ugly issues like
# potential failures during restart operations.  If config{binmode},
# approximate text-mode line-ending processing converting \r\n (\x0d\x0a) pairs
# to \n.  Simple approach is not entirely portable, assuming binary lines end
# with \n; true for Unix (\n) and Windows (\r\n), but perhaps not classic Mac
# (\r), unless MacPerl natively translates \r to \n.
#
# FUTURE: consider local $/ = "\r\n" to support binmode in sdpreadline; may be
# faster
#
sub sdpreadlinec (*) {
my($ph) = @_;

	my $line;
	while () {
	  RETRY:
		my $ch = getc(*$ph);
		if (! defined $ch || $ch eq '') {
			if (sdprestart($ph)) {
				goto RETRY;
			}
			return $line;
		}
		next	if $config{binmode} && $ch eq "\r";
		$line .= $ch;
		return $line 	if $ch eq "\n";
		return $line
			if $line eq 'Hit return to continue...'			# ShowForm commands
			|| $line =~ /^Accept.*\]: $/						# SDResolve*
			|| $line =~ m!^(File|This|There).* \(y/n\)\? $!;	# SDResolve*
	}
}

sub sdpreadline (*) {
my($ph) = @_;

  RETRY:
	my $line = readline *$ph;	# ends at \n even in binmode
	if (! defined $line && sdprestart($ph)) {
		goto RETRY;
	}
	$line =~ s/[\r\n]+$/\n/		if $config{binmode} && defined $line;
	return $line;
}


#
# sdpclose - Close pipe opened by sdpopen, cleaning up appropriately.
#
# FUTURE: only unlink if corresponding sdpopen created file
# FUTURE: consider safety of nested calls should both require response file
#
sub sdpclose (*) {
	my $ret = close $_[0];
	unlink $fspec{pip}	if ! $config{verbose} && $config{pipeless};
	unlink $fspec{arg}	if ! $config{verbose};
	return $ret;
}



#
# getconsole - Emulate use Win32::Console at runtime if available (so there's
# no hard dependency on that module) and attach a console to stdout if
# possible.  Return new console or undef if none.
#
sub getconsole {
	my $console;
	local $SIG{__DIE__};	# prevent __DIE__ being called during eval
	if (eval { require Win32::Console }) {
		eval { import Win32::Console };
		eval "\$console = new Win32::Console(STD_OUTPUT_HANDLE)";
	}
	return $console;
}


use vars qw(%mpechotypepref);		# map echo type to SD preference
%mpechotypepref = (
#	text     => 'AttrText',			# currently
#	info     => 'AttrInfo',			#  non-existent
	warning  => 'AttrWarning',
	error    => 'AttrError',
	internal => 'AttrSummary',		# AttrSummary is rare; internal and caller
	caller   => 'AttrSummary',		#  text should stand out in this colour
);


# Use $echotype (always localized) to communicate output type to defechofunc
# out of band (i.e. without incompatibly changing echofunc interface).
use vars qw($echotype);


#
# echotype - When called from an echofunc callback, return output type of
# current echo text.  If any argument is passed, change output type (as seen by
# defechofunc and subsequent calls to echotype) to specified string.
#
sub echotype {
	my $echotypeSav = $echotype;
	if (@_) {
		$echotype = $_[0];
	}
	return $echotypeSav;
}


# Win32::Console.pm closes stdout when a buffer created on it is destroyed, so
# keep console for duration of process to avoid.  Keep attributes (rattr) too,
# to minimize sd set calls.  fdoneconsole ensures we try opening console only
# once.
use vars qw($fdoneconsole $rattr $console);


#
# defechofunc - Default echofunc used if none specified.  Can be exported for
# use in caller echofunc callbacks.  NOTE: -t considers nul to be a tty.
# Current usage of console operations is safe on nul.  FUTURE: consider more
# rigorous check: $console->Info() returning short array indicates non-console.
#
sub defechofunc {

	return	if ! @_;

	# open output channels on first use by specific echotypes
	if (! $fdoneconsole && exists $mpechotypepref{$echotype}) {
		if (-t STDOUT) {	# stdout is a tty
			# FUTURE: if _SDSet fails (extremely unlikely), we don't colourize
			$rattr = _SDSet();
			if (SDGetEffective('ColorizeOutput', $rattr) != 0) {
				$console = getconsole;
			}
		}
		$fdoneconsole = 1;
	}

	# output text
	if (defined $console && exists $mpechotypepref{$echotype}) {
		my $attrSav = $console->Attr();
		my $attr = hex SDGetEffective($mpechotypepref{$echotype}, $rattr);
		if (SDGetEffective('AttrTransparency', $rattr) != 0) {
			my $trans = $attr & 0x300;
			$attr = ($attr & 0xf0) | ($attrSav & 0x0f)
				if $trans & 0x100;	# don't set (i.e. keep saved) foreground
			$attr = ($attr & 0x0f) | ($attrSav & 0xf0)
				if $trans & 0x200;	# don't set (i.e. keep saved) background
		}
		$console->Attr($attr & 0xff);
		print @_;		#$console->Write($_)	foreach @_;
		$console->Attr($attrSav);
	} else {
		print @_;
	}
}


#
# eprint - Echo print sd.exe output.  Respects config{echofunc} to allow caller
# access to the output stream.
#
sub eprint {
	local $echotype = shift;
	$config{echofunc}->(@_);
}


use vars qw(%mpprefixecho);		# map textual prefix to echo constant
%mpprefixecho = (
#	none    => echoNone,
	text    => echoText,
	info    => echoInfo,
#	warning => echoWarning,
#	error   => echoError,
#	internal=> echoInternal,
#	caller  => echoCaller,
);


#
# readfilt - Filter warnings, errors and exit code into @sdwarning, @sderror
# and $sdexit.  Non-\n-terminated prompt messages (only from sdpreadlinec)
# are unconditionally echoed but otherwise ignored.  Otherwise, act like
# readline, returning next line of input.  Depending on config{echo}, write
# text, info, warning and/or error output to echo streams as well.  Consider
# unrecognized text to be errors, or prefix-type if provided.
#
# FUTURE: tighten prefix matching to always expect exactly one space after foo:
# FUTURE: consider prompts a new category?
# FUTURE: set sdexit based on $? if not found with prefix parsing due to
# catastrophic failure?
#
sub readfilt (*;$) {
my($fh, $prefix) = @_;

	my @recs;
	$prefix = 'error'	if ! defined $prefix;

	my $fhSav = select STDOUT;
	my $afSav = $|;
	$| = 1;

	while () {
		my $rec = (defined *$fh{CODE})
			? &{*$fh}($fh)
			: sdpreadline $fh;

	  RETRY:
		# no data
		if (! defined $rec) {
			$| = $afSav; select $fhSav;
			wantarray ? return @recs : return;

		# prefixed lines respect config{echo}
		} elsif ($rec =~ /^(text|info)/) {
			eprint $1, scalar mappd $rec  if $config{echo} & $mpprefixecho{$1};
			if (wantarray) {
				push @recs, $rec;
			} else {
				$| = $afSav; select $fhSav;
				return $rec;
			}
		} elsif ($rec =~ /^warning/) {
			eprint 'warning', scalar mappd $rec	if $config{echo} & echoWarning;
			push @sdwarning, $rec;
		} elsif ($rec =~ /^error/) {
			eprint 'error', scalar mappd $rec	if $config{echo} & echoError;
			push @sderror, $rec;
		} elsif ($rec =~ /^exit:\s*(-?\d+)$/) {
			$sdexit = +$1;	# force numeric context

		# prompts are unconditionally echoed
		} elsif ($rec =~ /^Hit return to continue\.\.\./) {
			eprint 'info', scalar mappd $rec;	# ShowForm commands
		} elsif ($rec =~ /^Accept.*\]: /) {
			eprint 'info', scalar mappd $rec;	# SDResolve*
		} elsif ($rec =~ m!^(File|This|There).* \(y/n\)\? $!) {
			eprint 'info', scalar mappd $rec;	# SDResolve*

		# known exceptions treated as if prefixed
		} elsif ($rec =~ m!^(Resolve aborted\.|EOF reading terminal\.)$!) {	# SDResolve*
			eprint 'error', scalar mappd $rec	if $config{echo} & echoError;
			push @sderror, $rec;

		} else {	# assume prefix
			# lines following 'Source Depot client error:' will also be errors
			$prefix = 'error'	if $rec =~ /^Source Depot client error:$/;
			$rec = mapdp $prefix, $rec;
			goto RETRY;
		}
	}
}


#
# clearwarnerr - Clear any existing warnings and errors.
#
sub clearwarnerr {
	undef @sdwarning;
	undef @sderror;
	undef $sdexit;
}


#
# synthprompt/text/info/warning/error/internal/caller - echo synthesized output
# respecting $config{echo} and (for synthesized warnings/errors, where internal
# and caller cases are considered errors) push onto @sdwarning/error.  I.e.
# send synthesized messages to all appropriate places, as readfilt does for SD-
# emitted ones.  Argument message text is plain; neither prefixed nor dotted.
# Appropriate decoration is added here.  If first argument is a reference,
# referenced integer indicates output prefix level (synthwarning/error only).
# Default level is 0 (matching other synth*).  -1 indicates no message type
# prefix at all; typical of sd client-generated fatal messages.
#
# FUTURE: prefix level support as needed in other than synthwarning/error
# FUTURE: separate clientwarning/error sub instead of synthwarning/error \-1 ?
# FUTURE: support prefixed output through eprint?
#
sub synthprompt {
	eprint 'info', @_;		# unconditional
}
sub synthtext {
	eprint 'text', @_		if $config{echo} & echoText;
}
sub synthinfo {
	eprint 'info', @_		if $config{echo} & echoInfo;
}
sub synthwarning {
	my $lvl = (ref $_[0]) ? ${shift(@_)} : 0;
	eprint 'warning', map { ('... ' x $lvl) . $_ } @_	# <0 behaves like 0; OK
		if $config{echo} & echoWarning;
	my $prefix = ($lvl < 0)  ? ''
			   : ($lvl == 0) ? 'warning: '
			   :               "warning$lvl: ";
	push @sdwarning, map { "$prefix$_" } @_;
}
sub syntherror {
	my $lvl = (ref $_[0]) ? ${shift(@_)} : 0;
	eprint 'error', map { ('... ' x $lvl) . $_ } @_		# <0 behaves like 0; OK
		if $config{echo} & echoError;
	my $prefix = ($lvl < 0)  ? ''
			   : ($lvl == 0) ? 'error: '
			   :               "error$lvl: ";
	push @sderror, map { "$prefix$_" } @_;
}
sub synthinternal {
	eprint 'internal', @_	if $config{echo} & echoInternal;
	push @sderror, map { "internal: $_" } @_;
}
sub synthcaller {
	eprint 'caller', @_		if $config{echo} & echoCaller;
	push @sderror, map { "caller: $_" } @_;
}


#
# FEnsureSD2 - Ensure bin{sd2} exists.  Return 'bin{sd2} now exists and is a
# duplicate of bin{sd}'.  Copy of sd.exe is given a new name in same directory
# -- not changing directories avoids changing semantics when spawning other
# exes, not on the path, assumed to live in the same place as sd.exe.  Note:
# Win32::CopyFile requires perl $] >= 5.006.
#
# Copy is cached (for performance in case of multiple calls, and less file
# system churn, so less chance of failure, and fewer virus scans, and ...).
# Hence, ConfigSD and END are responsible for unlinking bin{sd2} and callers
# should not.  Duplicate test is based only on file size to be quick, and so
# can (barely) conceivably be fooled.  Clear the cache using ConfigSD to
# specify a new (or the existing) value for sdexe.
#
# FUTURE: bin{sd2} name may not be sufficiently unique as same pid on different
# machine, referencing sd.exe from a common location, could use same bin{sd2}.
# Sharing is OK, but there's a race between calls to FEnsureSD and sdpopen when
# sd2 could unexpectedly disappear due to other machine unlinking it.
#
sub FEnsureSD2 {
my($reason) = @_;

	return 1	if -f $bin{sd} && -f $bin{sd2} && -s $bin{sd} == -s $bin{sd2};

	unlink $bin{sd2};
	# FUTURE: fall back to system("copy ...") if $] < 5.006 as it's a cheap way
	# to provide safesync on old perls
	if (! Win32::CopyFile($bin{sd}, $bin{sd2}, 1)) { # fOverwrite
		my $err = Win32::GetLastError();
		$err = Win32::FormatMessage($err);
		synthinternal
			"can't copy $bin{sd} to $bin{sd2} for safe $reason: $err\n";
		return;
	}
	return 1;
}


#
# IndexHashList - Given a reference to a list of hash references, return a hash
# of those hash references, with canonicalized (i.e. lower cased) value of
# specified hash field as key.
#
sub IndexHashList {
my($rlist, $field) = @_;

	my %hash;
	foreach my $rhash (@{$rlist}) {
		my $key = lc $rhash->{$field};
		if (exists $hash{$key}) {
			synthinternal "duplicate key $key in IndexHashList\n";
			return;
		}
		$hash{$key} = $rhash;
	}

	return \%hash;
}


#
# IniSuppressVars - For each of vars that appears set, suppress with an entry
# in private .ini file.  Return string is suitable for use as a pre-command
# option in sdpopen call.  Return undef on failure to create file.  Caller is
# responsible for unlinking fspec{ini} after sdpclose if non-empty return
# string is passed to sdpopen.
#
# SD respects its variables set in user .ini file, sd.ini, environment and
# registry (in that order), and some general variables, which are environment-
# only.  Caller should first attempt to localize away the environment variables
# (both SD-specific and general); if successful, it's cheaper than creating an
# .ini file (and the only way to suppress general variables).  Thereafter, call
# IniSuppressVars, only for SD-specific variables, to ensure these are gone.
# Localization must be done in caller because localized values are restored on
# scope exit and so wouldn't survive into caller.  Multiple .ini files are
# processed left to right, so make returned one last to ensure it overrides all
# (including any ConfigSD-specified ones).
#
# FUTURE: should we override ConfigSD-specified .ini values?
# FUTURE: adding returned string as start of sdpopen cmd is a mildly evil hack
#
sub IniSuppressVars {
my(@vars) = @_;

	my $rset = _SDSet();

	my $sets = '';
	foreach my $var (@vars) {
		$sets .= "$var=\n"	if exists $rset->{$var};
	}

	return ''	if $sets eq '';

	local *FILE;
	if (! open(FILE, "> $fspec{ini}")) {
		synthinternal "can't open $fspec{ini} for write\n";
		return;
	}
	print FILE $sets;
	close FILE;
	return '-i ' . crtquote($fspec{ini});
}


#
# enext - Consider argument text to be an internal error, then next.
#
# FUTURE: message is presumptuous -- error text may not be sd.exe output
# FUTURE: SDFoo callers always include \n; ParseFoo callers never do.  Rather
# than adding \n if missing, consider ParseFoo callers adding it themselves.
#
sub enext {
my(@text) = @_;

	foreach my $text (@text) {
		$text .= "\n"	if $text !~ /\n\z/;
	}
	# sd.exe text will be prefixed; restore to dotted form for inclusion as is
	# in synthesized error, which will add own prefix in appropriate contexts
	synthinternal "unrecognized sd.exe output:\n", mappd @text;
	local $^W = 0;	# suppress 'Exiting subroutine via next'
	#no warnings qw(exiting);	# enable for perl $] >= 5.006
	next;
}


#
# nclnorm - Type check and normalize ncl (changelist#) in place.  Return
# 1/undef on success/failure.  Set sderror in case of failure, too.  default
# indicates what value to normalize nclDefault to.  default undefined indicates
# nclDefault is inappropriate.
#
sub nclnorm (\$;$) {
my($rncl, $default) = @_;

	if (defined $$rncl && $$rncl !~ /^\d+$/) {
		synthcaller "changelist# must be numeric\n";
		return;
	} elsif (! defined $$rncl || $$rncl == nclDefault) {
		if (! defined $default) {
			synthcaller "can't use default changelist\n";
			return;
		} else {
			$$rncl = $default;
		}
	}
	return 1;
}


#
# brnnorm - Type check and normalize brn (branch) in place.  Return 1/undef on
# success/failure.  Set sderror in case of failure, too.  default indicates
# what value to normalize brnDefault to.  default undefined indicates
# brnDefault is inappropriate.  Note that normalized value always gains '-b'
# switch if not the empty string.
#
sub brnnorm (\$;$) {
my($rbrn, $default) = @_;

	if ($$rbrn eq brnDefault) {
		if (! defined $default) {
			synthcaller "can't use default branch\n";
			return;
		} else {
			$$rbrn = $default;
		}
	}

	$$rbrn = '-b ' . crtquote($$rbrn)	if $$rbrn ne '';
	return 1;
}


#
# lblnorm - Type check and normalize lbl (label) in place.  Return 1/undef on
# success/failure.  Set sderror in case of failure, too.  Note that normalized
# value always gains '-l' switch if not the empty string, at least for now.
#
sub lblnorm (\$) {
my($rlbl) = @_;

	if ($$rlbl eq '') {
		synthcaller "must specify label\n";
		return;
	}

	$$rlbl = '-l ' . crtquote($$rlbl);
	return 1;
}


#
# nto1 - Return a single struct (or reference) from the value of a single item
# array reference returned by an SD* call much like %{SDFooN(args)->[0]}.
#
sub nto1 ($) {
my($ref) = @_;

	return	if ! defined $ref;						# distinction between undef
	return	if ref $ref eq 'ARRAY' && @$ref == 0;	#  and empty list lost here

	if (ref $ref ne 'ARRAY' || @$ref != 1) {
		my ($pkg, $file, $line, $sub) = caller(1);
		$sub =~ s/.*:://;	# remove package qualification from sub name
		synthcaller "argument must be single-element array reference\n",
					"(did you mean to call ${sub}N instead of $sub?)\n";
		return;
	}
	$ref = $ref->[0];
	if (ref $ref ne 'HASH') {
		synthinternal "argument's value must be a hash reference\n";
		return;
	}

	return wantarray ? %$ref : $ref;
}


#
# internal - Call exported API without side effects.  Suppress side effects
# with a wrapper as this is less invasive than attempting to prevent generation
# of the side effects to begin with.  Expect never to call one internal-wrapped
# sub from within another, but support it regardless.  sub internal may be
# fragile in other ways and need augmenting if new side effects are discovered
# or implementation of a wrapped export changes.
#
# See notes on 'internal forms' at 'Implementation Notes'.
#
# FUTURE: local $config{echofunc} = $configDef{echofunc}; would route
# unconditional prompts to defechofunc instead of user echofunc.  Worthwhile?
#
sub internal {
my $rfn = shift(@_);

	# use local so original values are automatically restored on return
	local @sdwarning;					# subvert rfn call to clearwarnerr
	local @sderror;
	local $sdexit;

	local $config{echo} = echoNone;		# instead of ConfigSD(echo => echoNone)

	local $fspec{pip} = $fspec{pip};	# avoid clobbering caller's output if
	$fspec{pip} =~ s/^(.*)\./$1_./i;	#  config{pipeless}

	return $rfn->(@_);
}


#
# ShowForm - Display interactive change/client/etc. form.
#
# FUTURE: this is really generic enough to be 'SimpleCmd'.  Replace innards of
# (for example) SDDel* with calls here.
#
sub ShowForm {

	local *PIPE;
	sdpopen(*PIPE, @_) || return;
	my @out = readfilt *PIPE;
	sdpclose *PIPE;

	return	if @out == 0 && $? != 0;
	return \@out;
}


#
# splitqs - Strip any trailing comment and return list of tokens in str split
# on quotes and whitespace more permissively than, but in the spirit of, SD.
#
sub splitqs {
my($str) = @_;

	my @ary;

	# even items are from outside, odd items, inside, quotes.  Any field may be
	# empty.  Trailing empty fields are not stripped due to limit of -1.  Note:
	# negative split limits require perl $] > 5.002.
	my @aryt = split(/"/, $str, -1);

	for (my $i = 0; $i < @aryt; $i += 2) {
		# comments can start only in unquoted (even) regions, and consume
		# rest of region and all subsequent regions
		splice @aryt, $i+1	if $aryt[$i] =~ s/#.*//;

		# leading and trailing empty fields in unquoted (even) regions are
		# stripped (due to special meaning of ' ' in this context, and lack of
		# limit, respectively)
		push @ary, split(' ', $aryt[$i]);

		# keep contents of quoted (odd) regions untouched
		push @ary, $aryt[$i+1]	if $i+1 < @aryt;
	}

	return @ary;
}


#
# ParseFiles - ParseForm callback parses sd change Files lines.  Keep in sync
# with CreateFiles.
#
sub ParseFiles {
my($key, $rvalue) = @_;

	return	if $key ne 'Files';

	my @files;
	foreach my $rec (@$rvalue) {
		# SD requires depotFile not to be quoted, even if it contains spaces,
		# so we need not handle quotes here either.
		next	if $rec =~ /^\s*(#.*)?$/;
		if ($rec =~ /^\s*([^#\@]+?)\s*#\s*([-\w]+)\s*$/) {	# //file # edit
			push @files, { 'depotFile' => $1, 'action' => $2 };
		} elsif ($rec =~ /^\s*([^#\@]+?)\s*(#.*)?$/) {	# //file (# comment)?
			push @files, { 'depotFile' => $1 };
		} else {
			enext $rec;
		}
	}

	return \@files;
}


#
# ParseView - ParseForm callback parses sd client/label View lines.  Keep in
# sync with CreateView.
#
# FUTURE: compare field names with SDAPI when complete
# NOTE: leading '+' is undocumented but supported in SD
#
sub ParseView {
my($key, $rvalue) = @_;

	return	if $key ne 'View' && $key ne 'Reviews';

	my @mappings;
	foreach my $rec (@$rvalue) {
		my @rec = splitqs $rec;
		next		if @rec == 0;
		enext $rec	if @rec != 1 && @rec != 2;
		my $rh = { 'depotSpec' => $rec[0] };
		$rh->{targetSpec} = $rec[1]		if @rec > 1;
		if ($rh->{depotSpec} =~ s/^([-+])//)	{	# 'move' unmap into separate
			$rh->{unmap} = ($1 eq '-');				# field
		}
		push @mappings, $rh;
	}

	return \@mappings;
}


#
# ParseOptions - ParseForm callback parses sd client Options lines.  Keep in
# sync with CreateOptions.
#
# FUTURE: should false options be undef instead of 0?
#
sub ParseOptions {
my($key, $rvalue) = @_;

	return	if $key ne 'Options';

	my (%options, $done1);
	foreach my $rec (@$rvalue) {
		# SD requires option tokens not to be quoted, so we need not handle
		# quotes here either.
		next	if $rec =~ /^\s*(#.*)?$/;
		if (! $done1) {
			foreach my $field (split ' ', $rec) {
				$field =~ /^(no|un)?(.*)$/;
				$options{$2} = defined $1 ? 0 : 1;
			}
			$done1 = 1;
		} else {
			enext $rec;		# there can be only one (line of options)
		}
	}

	return \%options;
}


#
# ParseNames - ParseForm callback parses sd group Subgroups, DomainGroups and
# Users sections and sd proxies ProxyCreds sections.  Keep in sync with
# CreateNames.
#
sub ParseNames {
my($key, $rvalue) = @_;

	return	if $key ne 'Subgroups' && $key ne 'DomainGroups'
		    && $key ne 'Users' && $key ne 'ProxyCreds';

	my @names;
	foreach my $rec (@$rvalue) {
		my @rec = splitqs $rec;
		next		if @rec == 0;
		enext $rec	if @rec != 1;
		push @names, $rec[0];
	}

	return \@names;
}


#
# ParseProtections - ParseForm callback parses sd protect Protections sections.
# Keep in sync with CreateProtections.
#
sub ParseProtections {
my($key, $rvalue) = @_;

	return	if $key ne 'Protections';

	my @protections;
	foreach my $rec (@$rvalue) {
		my @rec = splitqs $rec;
		next		if @rec == 0;
		enext $rec	if @rec != 5;
		my $rh = { 'Mode' => $rec[0], 'Type' => $rec[1], 'Name' => $rec[2],
				   'Host' => $rec[3], 'Path' => $rec[4] };
		if ($rh->{Path} =~ s/^([-+])//)	{	# 'move' unmap into separate field
			$rh->{unmap} = ($1 eq '-');
		}
		push @protections, $rh;
	}

	return \@protections;
}


#
# ParseTypeMap - ParseForm callback parses sd typemap TypeMap lines.  Keep in
# sync with CreateTypeMap.
#
# FUTURE: compare field names with SDAPI when complete
# FUTURE: typemap supports leading -/+ in Path; confirm what it means and
# support if appropriate.  Ensure uniform handling of -/+ in all paths.
#
sub ParseTypeMap {
my($key, $rvalue) = @_;

	return	if $key ne 'TypeMap';

	my @mappings;
	foreach my $rec (@$rvalue) {
		my @rec = splitqs $rec;
		next		if @rec == 0;
		enext $rec	if @rec != 2;
		my $rh = { 'Filetype' => $rec[0], 'Path' => $rec[1] };
		push @mappings, $rh;
	}

	return \@mappings;
}


#
# ParseDefault - ParseForm callback implements default parsing.
#
# FUTURE: should this be ParseDescription, with ParseNames as ParseDefault?
#
sub ParseDefault {
my($key, $rvalue) = @_;

	my $join = join "\n", @$rvalue;
	local $/ = '';
	chomp $join;	# strip trailing empty lines
	return $join;
}


use vars qw(%mpkeycase);
%mpkeycase = (
	# group fields
	maxresults   => 'MaxResults',
	maxscanrows  => 'MaxScanRows',
	domaingroups => 'DomainGroups',
	# proxies fields
	uniqueid     => 'UniqueId',
	proxycreds   => 'ProxyCreds',
	# typemap fields
	typemap      => 'TypeMap',
	# user fields
	fullname     => 'FullName',
	jobview      => 'JobView',
);

#
# keycase - return canonical spelling of standard form record names
#
sub keycase {
my($key) = @_;
	$key = lc $key;
	return (exists $mpkeycase{$key}) ? $mpkeycase{$key} : ucfirst $key;
}


#
# SetFormRecord - insert record defined by lines in rvalue into form in rform.
# rfns is a list of callbacks for parsing records in a form-specific way.
#
# FUTURE: track errors reported by callbacks and incorporate into return value,
# which can then be used by caller to abort parse on first error
# FUTURE: define sets of known field names to allow rejecting unknown ones
#
sub SetFormRecord {
my($rform, $rvalue, @rfns) = @_;

	my $key;

	($key, $rvalue->[0]) = $rvalue->[0] =~ /^(\w+):\s*(.*)$/;
	if (! defined $key) {
		my ($pkg, $file, $line, $sub) = caller(2);
		synthinternal "error parsing form output in $sub\n";
		return;
	}
	shift @$rvalue	if $rvalue->[0] eq '';

	# section names are case-insensitive when creating forms, so be as flexible
	# when parsing them.  Canonical key names match sd form output for least
	# astonishment.
	$key = keycase($key);

	# Array sections (e.g. Reviews, Protections) append to any existing data
	# from a prior occurrence of same section; others report error on second
	# occurrence of same section.  ParseDefault will always return a defined
	# value, so rform->{key} is guaranteed to be set before return.
	foreach my $rfn (@rfns, \&ParseDefault) {
		my $ret = $rfn->($key, $rvalue);
		if (defined $ret) {
			if (! defined $rform->{$key}) {
				$rform->{$key} = $ret;
			} elsif (ref $rform->{$key} eq 'ARRAY') {
				push @{$rform->{$key}}, @$ret;
			} else {
				synthinternal "Too many entries for field '$key'.";
				return;
			}
			last;
		}
	}

	return 1;
}


#
# ParseForm - Read and parse client/change -o style output.  fh is filehandle
# to read from.  rfns is a list of callbacks for parsing records in an fh-
# specific way.  Each rfn returns specialized parsed output or undef for
# records to be handled by another callback.  Records not handled by any
# callback are handled in the default fashion -- as simple scalars, with
# multiple lines joined separated (but not terminated) by \n.  Return form.
# Hybrid API (for internal use but EXPORT_OK) expects caller to clearwarnerr.
#
# A record starts with a line matching ^\w+: and ends before the first line not
# matching ^\s.  Leading blank/comment lines are ignored.  Embedded full-line
# comments (i.e. those starting with a # in column 0) become empty lines.
# The leading \s of other data lines is stripped.  Callbacks are responsible
# for handling embedded comments and whitespace as they see fit.  These
# convoluted rules are an approximation of a rationalization of what SD
# itself seems to do, leaning towards being more permissive than SD with the
# placement of comments.
#
# FUTURE: ParseForm is frequently used with forms not from sd.exe; expect that
# most errors now are bad input, not unexpected fields.  Hence, errors should
# be output, worded and formatted as from (say) sd client -i < form.txt, and
# respect config{echo}, instead of being treated as internal errors.  EditForm
# would be improved, and external callers (e.g. genprot.bat) wouldn't need to
# massage SDError text for a similar effect.  Will need to replace enext and
# synthinternal with syntherror here and in Parse* callbacks, standard and user
# defined.  Bonus: enext can then be removed from EXPORT_OK and simplified.
# Extra credit: track and report line number information like sd.exe.
# FUTURE: perlish idiom would be for ParseForm to handle ParseFormFile/Cmd
# semantics based on type/content of $fh
#
sub ParseForm (*;@) {
my($fh, @rfns) = @_;

	my (@value, %form);
	my $fheader = '\\s*';	# also 'true'
	while (my $rec = readfilt $fh, 'info') {	# FUTURE: why the 'info' tag?
		# skip header comments/whitespace lines
		next	if $fheader && $rec =~ /^info: \s*(#.*)?$/;

		if ($rec =~ /^info: $fheader(\w+:.*)$/) {
			# process accumulated value and start a new one
			SetFormRecord(\%form, \@value, @rfns)	if @value > 0;
			undef @value;
			push @value, $1;	# first line is definition line
		} elsif ($rec =~ /^info: \s(.*)$/) {
			enext $rec	if $fheader;	# should have seen a first line by now
			push @value, $1;	# accumulate continuation line bodies
		} elsif ($rec =~ /^info: (#|$)/) {
			push @value, '';	# full-line comments and empty lines
		} else {				# become empty lines
			enext $rec;
		}

		$fheader = '';	# also 'false'
	}
	# process remaining accumulated value
	SetFormRecord(\%form, \@value, @rfns)	if @value > 0;

	return \%form;
}


#
# ParseFormFile - Open file specified by fspec and parse its contents as a
# form.  Return form/undef on success/failure.  Hybrid API (for internal use
# but EXPORT_OK) expects caller to clearwarnerr.
#
sub ParseFormFile {
my($fspec, @rfns) = @_;

	local *FILE;
	if (! open(FILE, $fspec)) {
		synthinternal "can't open $fspec for read\n";
		return;
	}
	my $rform = ParseForm(*FILE, @rfns);
	close FILE;

	return wantarray ? %$rform : $rform;
}


#
# ParseFormCmd - Spawn command specified by cmd and parse its output as a form.
# Return form/undef on success/failure.  Hybrid API (for internal use but
# EXPORT_OK) expects caller to clearwarnerr.  Because varargs are used to pass
# parsing functions, command-and-arguments must be specified as a single
# string.  Caller is responsible for ensuring that options are separated from
# arguments by '--' and that arguments are quoted with crtquote.
#
sub ParseFormCmd {
my($cmdargs, @rfns) = @_;

	local *PIPE;
	sdpopen(*PIPE, $cmdargs) || return;
	my $rform = ParseForm(*PIPE, @rfns);
	sdpclose *PIPE;

	return	if $? != 0;
	return wantarray ? %$rform : $rform;
}


#
# CreateFiles - CreateForm callback creates sd change Files lines.  Keep in
# sync with ParseFiles.
#
sub CreateFiles {
my($fh, $key, $rvalue) = @_;

	return	if $key ne 'Files';

	foreach my $rhash (@$rvalue) {
		# SD requires depotFile not to be quoted, even if it contains spaces
		# (perhaps handling this as a description-style block?)
		my $action = (exists $rhash->{action})
			? "\t# $rhash->{action}"
			: '';
		print $fh "\t$rhash->{depotFile}$action\n";
	}

	return 1;
}


#
# CreateView - CreateForm callback creates sd client View lines.  Keep in sync
# with ParseView.
#
sub CreateView {
my($fh, $key, $rvalue) = @_;

	return	if $key ne 'View' && $key ne 'Reviews';

	foreach my $rhash (@$rvalue) {
		my $m = $rhash->{unmap} ? '-' : (exists $rhash->{unmap} ? '+' : '');
		my $d = "$m$rhash->{depotSpec}";
		$d = qq/"$d"/	if $d =~ /\s/;
		my $t = '';
		if (exists $rhash->{targetSpec}) {
			$t = $rhash->{targetSpec};
			$t = qq/"$t"/	if $t =~ /\s/;
			$t = " $t";
		}
		print $fh "\t$d$t\n";
	}

	return 1;
}


#
# CreateOptions - CreateForm callback creates sd client Options lines.  Keep in
# sync with ParseOptions.
#
sub CreateOptions {
my($fh, $key, $rvalue) = @_;

	return	if $key ne 'Options';

	my @fields;
	foreach my $field (sort keys %$rvalue) {
		my $prefix =
			$rvalue->{$field} ? '' : ($field eq 'locked' ? 'un' : 'no');
		push @fields, "$prefix$field";
	}
	print $fh "\t", join(' ', @fields), "\n";

	return 1;
}


#
# CreateNames - CreateForm callback creates sd group Subgroups, DomainGroups
# and Users sections and sd proxies ProxyCreds sections.  Keep in sync with
# ParseNames.
#
# FUTURE: should this be merged with CreateDefault?
#
sub CreateNames {
my($fh, $key, $rvalue) = @_;

	return	if $key ne 'Subgroups' && $key ne 'DomainGroups'
		    && $key ne 'Users' && $key ne 'ProxyCreds';

	foreach my $name (@$rvalue) {
		$name = qq/"$name"/		if $name =~ /\s/;
		print $fh "\t$name\n";
	}

	return 1;
}


#
# CreateProtections - CreateForm callback creates sd protect Protections
# sections.  Keep in sync with ParseProtections.
#
sub CreateProtections {
my($fh, $key, $rvalue) = @_;

	return	if $key ne 'Protections';

	foreach my $rhash (@$rvalue) {
		# FUTURE: is there reason to quote Mode/Type/Host?
		my $name = $rhash->{Name};
		$name = qq/"$name"/		if $name =~ /\s/;
		my $m = $rhash->{unmap} ? '-' : (exists $rhash->{unmap} ? '+' : '');
		my $path = "$m$rhash->{Path}";
		$path = qq/"$path"/		if $path =~ /\s/;
		print $fh "\t$rhash->{Mode} $rhash->{Type} $name $rhash->{Host} $path\n";
	}

	return 1;
}


#
# CreateTypeMap - CreateForm callback creates sd typemap TypeMap lines.  Keep
# in sync with ParseTypeMap.
#
sub CreateTypeMap {
my($fh, $key, $rvalue) = @_;

	return	if $key ne 'TypeMap';

	foreach my $rhash (@$rvalue) {
		# FUTURE: is there reason to quote Filetype?
		my $path = $rhash->{Path};
		$path = qq/"$path"/		if $path =~ /\s/;
		print $fh "\t$rhash->{Filetype} $path\n";
	}

	return 1;
}


#
# CreateDefault - CreateForm callback implements default output.
#
sub CreateDefault {
my($fh, $key, $value) = @_;

	if (ref $value ne 'ARRAY') {	# non-arrays
		print $fh "\t", join("\n\t", split(/\n/, $value)), "\n";
	} else {						# arrays
		print $fh "\t$_\n"	foreach @$value;
	}

	return 1;
}


#
# CreateForm - Write client/change -i style input file to filehandle fh.
# Non-arrays are emitted first, followed by arrays.  rfns is a list of
# callbacks for emitting records in a form-specific way.  Each rfn returns
# undef for records to be handled by another callback.  Records not handled by
# any callback are handled in the default way -- where layout is inferred from
# structure of rform:
# - non-array values are split on \n, and emitted starting on same line as key
#   (if room)
# - array values are emitted one per line starting on the next line.
# Return 1 for success.  Hybrid API (for internal use but EXPORT_OK) expects
# caller to clearwarnerr.
#
# FUTURE: perlish idiom would be for CreateForm to handle CreateFormFile
# semantics based on type/content of $fh
# FUTURE: match -o output more closely (principally, order)
# FUTURE: customize header comment for Group, Protection, Proxies, Trigger and
# TypeMap forms
#
sub CreateForm {
my($fh, $rform, @rfns) = @_;

	my ($key, $value);

	# Attempt to determine form type for header comment parsed by sdforms.exe
	my $form = 'Form';
	while (($key, $value) = each %$rform) {		# non-arrays
		next	if ref $value eq 'ARRAY';
		# Change form includes both Change and Client references,
		# so appearance of Client field is only tentative indication
		# of Client form.  Label and Change are definitive, however.
		if ($key eq 'Label' || $key eq 'Change') {
			$form = $key;
			keys %$rform;	# reset iterator for next 'each' loop
			last;
		} elsif ($key eq 'Client') {
			$form = $key;
		}
	}

	print $fh "# A Source Depot $form Specification created by ",
			  __PACKAGE__, ".pm\n\n";

	foreach $key (sort keys %$rform) {			# non-arrays
		$value = $rform->{$key};
		next	if ! defined $value;
		next	if ref $value eq 'ARRAY';
		print $fh "$key:";
		print $fh "\n"	if length $key > 6;
		foreach my $rfn (@rfns, \&CreateDefault) {
			last if defined $rfn->($fh, $key, $value);
		}
		print $fh "\n";
	}
	foreach $key (sort keys %$rform) {			# array references
		$value = $rform->{$key};
		next	if ! defined $value;
		next	if ref $value ne 'ARRAY';
		print $fh "$key:\n";
		foreach my $rfn (@rfns, \&CreateDefault) {
			last if defined $rfn->($fh, $key, $value);
		}
		print $fh "\n";
	}

	return 1;
}


#
# CreateFormFile - Create file specified by fspec and write rform to it.
# Return 1/undef on success/failure.  Hybrid API (for internal use but
# EXPORT_OK) expects caller to clearwarnerr.
#
sub CreateFormFile {
my($fspec, $rform, @rfns) = @_;

	local *FILE;
	if (! open(FILE, "> $fspec")) {
		synthinternal "can't open $fspec for write\n";
		return;
	}

	my $ret = CreateForm(*FILE, $rform, @rfns);
	close FILE;

	return $ret;
}



#
# hashformfile - Generate a hash value for the contents of fspec, expected to
# contain an SD form.  Return hash value, suitable for comparison with others
# using 'eq' on scalar dereference, or undef on failure.
#
# FUTURE: caching essentially entire file is not a space-efficient hash;
# consider using CRC-32 (like zip), MD5 (like SD), SHA-1 (most secure available
# for perl), SHA-256 (most secure) or even duplicating fspec as another file,
# returning duplicate fspec as value which can be compared using CompareFiles
#
sub hashformfile {
my($fspec) = @_;

	local *FILE;
	open(FILE, "< $fspec") || return;
	binmode(FILE);
	my ($data, $len);
	$len = sysread FILE, $data, -s FILE;
	close FILE;
	return	if ! defined $len;

	$data =~ s/[\r\n]*$//;	# sanitize trailing newlines
	return \$data;
}


#
# SetFormError - Report a validation error in a user-edited form, typically
# before a retry call to EditForm.
#
sub SetFormError {
	syntherror @_;
	synthprompt 'Hit return to continue...';
	readline *STDIN;
}


#
# EditForm - Invoke editor for perl-resident form as SDBranch/Change/Client/
# Group/Label/User do for SD server-based forms.  rform is a form (typically
# from preceding SDGetBranch/etc.).  Return value is user-updated form.  Unlike
# SDGet/SetBranch/etc., form must be passed as reference and not actual hash.
# Similarly, form is only returned as a reference.  SDFORMEDITOR value is
# respected to invoke editor.  If return is undef, form edit was aborted.
#
# rhashprev (argument) and second return value (in list context) are state
# information for consistent handling of validation between retries within a
# single call to EditForm and across multiple calls from a single caller.
# Validation beyond syntactic correctness is responsibility of caller.  If
# semantic errors are detected, report them with SetFormError and call EditForm
# again with return values from failing call as arguments.
#
# Arguments beyond rhashprev are lists of subroutine references; equal numbers
# of ParseForm and CreateForm callbacks.  Pass the same ones you would in a
# call to ParseForm and CreateForm for the same form type.
#
# ConfigSD(echo => echoAll) recommended to provide context for any prompts.
#
# FUTURE: consider returning 'CANCEL'/'GIVEUP' as appropriate, eliminating need
# for caller to check SDWarning/Error for specific text to distinguish user
# error cases from system() or sysread() failure.
# FUTURE: hashing requires reading entire form file a second time.  Consider
# hashing while parsing?
# FUTURE: optimize caller-validation case by making caller reponsible for
# unlinking fspec{frm}, or preserve fspec{frm} in rhashprev across calls,
# (leaving unlink in EditForm).  This would eliminate need for recreating
# fspec{frm} when caller validation fails and a retry call to EditForm is made,
# but be sure to consider simultaneously 'active' EditForm retry cycles.
#
sub EditForm {
my $rform = shift(@_);
my $rhashprev = shift(@_);

	clearwarnerr;

	# callbacks must be specified in pairs
	if (@_ % 2 != 0 || @_ == 0) {
		synthcaller
			"even number of functions, > 0 (_n_ create, _n_ parse) required\n";
		return;
	}

	# first half are create callbacks, rest are parse callbacks
	my $nrfns = @_ / 2;
	my @createrfns = @_[0      .. $nrfns-1  ];
	my @parserfns  = @_[$nrfns .. $nrfns*2-1];


	# form editor requires file, not a perl data structure
	return	if ! CreateFormFile($fspec{frm}, $rform, @createrfns);

	my $editcmd = cpquote(SDGetEffective('SDFORMEDITOR')) . ' '
				. crtquote($fspec{frm});

	# extra operations should be mostly hidden from user; use local instead of
	# ConfigSD() so it's automatically restored on return
	local $config{echo} = $config{echo} & ~(echoInfo | echoText);

  RETRY:
	# FUTURE: spawning cmd builtins (attempted as second chance within system,
	# after failing to find an external exe) spuriously sets $!.
	print "EditForm: spawning: $editcmd\n"		if $config{verbose};
	$! = 0;
	system($editcmd);
	if ($!) {	# failed to spawn, not related to spawned program exit value
		syntherror "system: $editcmd: $^E.\n";
		syntherror \-1, "Client side operation(s) failed.  Command aborted.\n";
		unlink $fspec{frm}	if ! $config{verbose};
		return;
	}

	# zero-byte updated form indicates user cancel
	if (-z $fspec{frm}) {
		syntherror \-1, "Client side operation(s) failed.  Command aborted.\n";
		unlink $fspec{frm}	if ! $config{verbose};
		return;
	}

	# inability to hash is unexpected, but possible due to external meddling
	my $rhash = hashformfile($fspec{frm});
	if (! defined $rhash) {
		syntherror \-1, "open for read: $fspec{frm}: $^E.\n";
		syntherror \-1, "Client side operation(s) failed.  Command aborted.\n";
		unlink $fspec{frm}	if ! $config{verbose};
		return;
	}

	# emulate SD: an iteration with no change is reason to quit
	if (defined $rhashprev && $$rhashprev eq $$rhash) {
		synthwarning \-1, "Specification not corrected -- giving up.\n";
		unlink $fspec{frm}	if ! $config{verbose};
		return;
	}

	# retrieve updated form
	$rform = ParseFormFile($fspec{frm}, @parserfns);
	if (@sderror) {
		# errors were emitted appropriately when pushed
		# existing form file is suitable for next iteration
		SetFormError();
		$rhashprev = $rhash;
		goto RETRY;
	}

	# clean up
	unlink $fspec{frm}	if ! $config{verbose};

	return wantarray ? ($rform, $rhash) : $rform;
}


#
# EditChangeForm - Allow user to update a change form in rform, returning
# updated, validated, form or undef on failure to update.
#
# FUTURE: allow caller to specify and return rhashprev to allow yet another
# layer of validation with consistent handling across calls?
# FUTURE: export full family of Edit*Forms with SD server native validation
# semantics
#
sub EditChangeForm {
my($rform) = @_;

	my $rhashprev;

  RETRY:
	($rform, $rhashprev) = EditForm($rform, $rhashprev,
									\&CreateFiles, \&ParseFiles);
	return	if ! defined $rform;

	# semantic validation
	if (! defined $rform->{Description}
	 || $rform->{Description} =~ /^\s*<enter description here>$/i) {
		# FUTURE: include "Error detected at line N.\n".  Will require Parse*
		# to maintain source line number information in parsed form.
		SetFormError("Error in change specification.\n",
					 "Change description missing.  You must enter one.\n");
		goto RETRY;
	}

	return $rform;
}



#
# synthpawarning - synthwarning for failed _p_arse operation in sd_a_liases.ini
# file.  Specify fspec being parsed (undef if not available) and warning text
# for problems encountered.
#
sub synthpawarning {
my($fspec, @warnings) = @_;

	if (defined $fspec) {
		$fspec = Win32::GetFullPathName($fspec);
		synthwarning "Unable to load alias file $fspec.\n";
	}
	synthwarning @warnings;
}


use vars qw(%mpcase);	# map canonical (upper) case names to first-seen case

#
# mapcase - Return first-seen case for section or item within section.  If not
# yet seen, establish passed-in case as first-seen case.  If called with no
# arguments, clear history.  Consider all arguments but last to be 'namespace'
# and last to be item within.  Return value is item in first-seen case in that
# namespace.  The namespace itself is not included in the return value.
#
sub mapcase {
	if (@_ == 0) {
		%mpcase = ();	# clear any previous contents
		return;
	}

	my $key = uc join('::', @_);
	if (! exists $mpcase{$key}) {
		$mpcase{$key} = $_[-1];		# -1 == last argument
	}

	return $mpcase{$key};
}


#
# ParseSDAliasesIni - Read and parse sdaliases.ini file style content.  fh is
# filehandle to read from.  fspec is filename, for reference in error messages,
# if available, otherwise undef.  Item and section names are case-insensitive,
# stored as case first encountered (typically as an item name in the [Aliases]
# section).  [Aliases] is always cased as in this sentence.  Hybrid API (for
# internal use but EXPORT_OK) expects caller to clearwarnerr.  Use a private
# ini parser to conform to SD's quirks; standard CPAN modules don't necessarily
# handle multivalue keys and none seem to handle empty key names as required
# here.
#
#   # using data from sd help inifiles example
#   %aliases = (
#     'Aliases' => {
#        'MyTeam'     => [ 'ourserver:5555', 'ourserver.dns.domain.com:5555' ],
#        'PartnerTeam'=> [ 'theirserver:4000' ],
#     },
#     'MyTeam' => {      # case of 'MyTeam' here will match instance above
#        ''      => [ 'usaproxy:4444' ],
#        'Tokyo' => [ 'tokyoproxy:4444' ],
#     },
#   )
#
#   Return %aliases/undef on success/failure.  Emulating sd.exe behaviour is
#   recommended:
#     ConfigSD(echo => echoAll)             # for informational warnings
#     $raliases = ParseSDAliasesIni(...) {  # parse ini file
#     if (keys %$raliases) {
#        # use results; in case of multiple values in a [Depot] section for a
#        # single location, prefer first: e.g.
#        $proxyport = $raliases->{MyTeam}{Tokyo}[0];
#     } else {
#        # continue without complaint
#        $proxyport = undef;
#     }
#
# NOTE: parsing semantics and algorithm from sd\v3.1\support\aliases.cpp
#
# FUTURE: additional, canonicalized keys for ease of case-insensitive access;
# perhaps include mpcase directly
# FUTURE: keep original source, line numbered so CreateSDAliasesIniFile
# rewrites after modifications perturb text file as little as possible.
# FUTURE: improve on SD by reporting multiple errors and returning what was
# parseable (follow each synthpawarning with 'next' instead of 'return';
# synthpawarning to emit "Unable to load" warning only on first)?
# FUTURE: improve on SD by trimming leading space from section name?  reporting
# garbage beyond ] in section lines?
#
sub ParseSDAliasesIni {
my($fh, $fspec) = @_;

	my %aliases;
	my $cursection;

	mapcase(); 	# clear any previous contents

	while (my $rec = readline($fh)) {
		$rec =~ s/^\s*//;
		next if $rec =~ m!^([#'/;]|$)!;		# skip comment-only and blank lines

		# switch modes based on section headers
		if ($rec =~ /^\[/) {
			if ($rec !~ /]/) {
				synthpawarning $fspec, "Missing end bracket; line $..\n";
				return;
			}

			# trim trailing (but not leading) spaces from section, and ignore
			# text beyond first ], matching SD.
			my ($section) = $rec =~ /^\[(.*?)\s*\]/;

			if (lc $section eq 'aliases') {	# [Aliases] section
				$cursection = 'Aliases';
			} else {						# any other [Depot] section
				# case of [Depot] to match items within [Aliases]
				$section = mapcase('Aliases', $section);
				if (exists $aliases{Aliases}->{$section}) {
					$cursection = $section;
				} else {
					synthpawarning $fspec, "First time seeing '$section'; line $..\n";
					return;
				}
			}

			next;
		}

		if (! defined $cursection) {
			synthpawarning $fspec, "Non-comment line found outside of a section; line $..\n";
			return;
		}
		my ($item, $value) = split(/=/, $rec, 2);
		if (! defined $value) {
			synthpawarning $fspec, "Invalid line (no equal sign); line $..\n";
			return;
		}

		# strip item and value of all surrounding whitespace
		$item =~ s/\s*$//;
		$value =~ s/^\s*//;
		$value =~ s/\s*$//;
		# change case of item to that first seen
		$item = mapcase($cursection, $item);

		# add item/value pair to current section, keeping multiple values, in
		# order encountered, for repeated items
		push @{$aliases{$cursection}->{$item}}, $value;
	}

	return \%aliases;
}


#
# ParseSDAliasesIniFile - Open file specified by fspec and parse its contents
# as an sdaliases-style ini.  Return aliases/undef on success/failure.
# For symmetry with ParseFormFile (hybrid API for internal use but EXPORT_OK),
# expects caller to clearwarnerr.
#
# FUTURE: mechanism (in SDGetEffective?) to find file according to search rules
# in sd help inifiles; include found path in %aliases.
#
sub ParseSDAliasesIniFile {
my($fspec) = @_;

	local *FILE;
	if (! open(FILE, $fspec)) {
		# error is caller:, not internal: because no internal references
		synthcaller "can't open $fspec for read\n";
		return;
	}
	my $raliases = ParseSDAliasesIni(*FILE, $fspec);
	close FILE;

	return wantarray ? %$raliases : $raliases;
}


# CreateSDAliasesIni comparison function to sort Aliases section first
sub aliasesfirst {
	my $A = lc $a;
	my $B = lc $b;
	return  0	if $A eq $B;
	return -1	if $A eq 'aliases';
	return  1	if $B eq 'aliases';
	return $A cmp $B;
}

#
# CreateSDAliasesIni - Write sdaliases.ini-style file to filehandle fh.  Return
# 1 for success.
#
# FUTURE: add syntactic validation (e.g. that there are not multiple [Depots]
# differing only in case)
# FUTURE: add semantic validation (e.g. that each [Depot] is represented in
# [Aliases])
#
sub CreateSDAliasesIni {
my($fh, $raliases) = @_;

	# FUTURE: emit "A Source Depot ini file created by __PACKAGE__.pm" header?
	foreach my $key (sort aliasesfirst keys %{$raliases}) {
		print $fh "[$key]\n";
		foreach my $key2 (sort { lc $a cmp lc $b } keys %{$raliases->{$key}}) {
			my $rvalues = $raliases->{$key}{$key2};
			foreach my $value (@$rvalues) {
				print $fh "$key2=$value\n";
			}
		}
		print $fh "\n";
	}

	return 1;
}


#
# CreateSDAliasesIniFile - Create file specified by fspec and write raliases
# to it.  Return 1/undef on success/failure.  For symmetry with ParseFormFile
# (hybrid API for internal use but EXPORT_OK), expects caller to clearwarnerr.
#
sub CreateSDAliasesIniFile {
my($fspec, $raliases) = @_;

	local *FILE;
	if (! open(FILE, "> $fspec")) {
		# error is caller:, not internal: because no internal references
		synthcaller "can't open $fspec for write\n";
		return;
	}

	my $ret = CreateSDAliasesIni(*FILE, $raliases);
	close FILE;

	return $ret;
}



#
# endir - Ensure dir ends in platform-appropriate slash to allow direct
# concatenation of filenames.
#
# FUTURE: use File::Spec?
#
sub endir {
my($dir) = @_;
	$dir .= '\\'	if $dir ne '' && $dir !~ m![:\\/]$!;
	return $dir;
}
sub endir_unix {	# dynamically selected if appropriate in InitSD
my($dir) = @_;
	$dir .= '/'		if $dir ne '' && $dir !~ m!/$!;
	return $dir;
}


#
# InitSD - Ensure non-constant package globals are initialized.  May be called
# multiple times with no harm.  Passing force will cause unconditional
# re-initialization, restoring all configurable options to their defaults.
# Return whether any significant work was done.  Adding configurable options
# typically requires changes to InitSD (to set defaults) and to ConfigSD (to
# override).
#
sub InitSD (;$) {	# find existing callers who may be passing options
my($force) = @_;

	# all internal errors are stored in sderror
	# those including 'caller:' indicate coding (or user data) errors,
	# those including 'internal:' indicate SD.pm errors
	clearwarnerr;

	if (! $finitsd || $force) {		# first time or forced only

		# select platform; one variable each for clarity when referenced
		$fwin = $^O =~ /^MSWin(32|64)$/;
		$funix = ! $fwin;	# including $^O eq 'darwin' (MacOSX) and 'unix'

		# select platform-specific implementations
		if ($funix) {
			no strict 'refs';	# allow symbol table manipulation
			local $^W = 0;		# suppress 'Subroutine %s redefined'
			foreach my $fn (qw(crtquote cpquote endir)) {
				*$fn = \&{$fn . '_unix'};
			}
		}

		# environmental sanity
		my $binarch;
		if ($fwin && defined $ENV{SPOROOT}) {
			$binarch = "$ENV{SPOROOT}\\bin\\";
			$binarch .= "x86\\"					# sd.exe moved 'up'
				if ! -f "${binarch}\\sd.exe";	#  in dev14
		}
		$binarch = ''	if ! defined $binarch;

		# FUTURE: open(FOO, "[<>] $fspec{???}") will fail in pathological cases
		# where $ENV{TEMP} begins with spaces; 3-argument open would solve
		# this, but would require perl $] >= 5.006
		# FUTURE: use File::Temp?  File::Spec::tmpdir?
		my $temp;
		my @ptemps = $fwin
			? ($ENV{TEMP})
			: ($ENV{TMPDIR}, '/tmp');
		foreach my $ptemp (@ptemps) {
			if (defined $ptemp && -d $ptemp) {
				$temp = $ptemp;
				last;
			}
		}
		if (! defined $temp) {
			# warn __PACKAGE__ . ".pm: %TEMP% not defined or not a valid directory\n";
			$temp = '';
		}
		$temp = endir($temp);

		# all configurable options are in config
		%config = (
			batchfunc	=>	undef,
			binarch		=>	$binarch,
			binmode		=>	0,
			client		=>	undef,
			dir			=>	undef,
			echo		=>	echoNone,
			echofunc	=>	\&defechofunc,
			host		=>	undef,
			ini			=>	undef,
			itemfunc	=>	undef,
			maxresults	=>	undef,
			password	=>	undef,
			pipeless	=>	0,
			port		=>	undef,
			proxy		=>	undef,
			safesync	=>	0,
			sdexe		=>	$fwin ? 'sd.exe' : 'sd',
			temp		=>	$temp,
			user		=>	undef,
			verbose		=>	defined $ENV{OVERBOSE},
		);

		# keep default values for config options so they can be restored in
		# case of ConfigSD('foo' => undef)
		%configDef = %config;

		# all referenced tools are in bin
		# values may contain spaces; quote if appropriate when referenced
		%bin = (
			sd		=>	"$config{binarch}$config{sdexe}",
			sd2		=>	"$config{binarch}sd$$.exe",		# created on demand
		);
		$bin{sd2} =~ s/^(.*)\./$1_./  if $$ == 20;	# avoid Office-private copy

		# all forms are written to fspec{frm}
		# argument lists too long for cmd.exe are written to fspec{arg}
		# ini files to suppress options are written to fspec{ini}
		# command output is written to/read from fspec{pip} if config{pipeless}
		# values may contain spaces; quote if appropriate when referenced
		foreach my $key (qw(frm arg pip ini)) {
			$fspec{$key} = "$config{temp}sdpm$$.$key";
		}

		$finitsd = 1;
		return 1;
	}

	return;
}



#
# ConfigSD - Configure specified SD options.  Only those options specified are
# affected by a call to ConfigSD.  Specifying undef as the value for an option
# restores the default.  Return previous set of options.  Adding options
# typically requires changes to InitSD (to set defaults) and to ConfigSD (to
# override).
#
# Options:
#   batchfunc=> \&mybatch    - force multiple sd.exe invocations, each with no
#                              more than 128 arguments, calling batchfunc
#                              between (not after) them; useful for providing
#                              feedback to caller and reducing depot load (by
#                              sleeping) $VERSION 2.44 to 2.53 PROVIDED MORE
#                              LIMITED batchdelay; OLD BEHAVIOUR CAN BE
#                              OBTAINED WITH batchfunc => sub { sleep 10 }
#   binarch  => 'd:\\bin'    - directory containing sd.exe
#   binmode  => 1            - sd.exe return text is processed as binary,
#                              allowing additional characters (notably ^Z)
#                              in returned text to be handled.  Text-mode
#                              processing still occurs for line endings.
#                              EXPERIMENTAL BEHAVIOUR MAY CHANGE.
#   client   => 'CLIENT'     - client name (overrides sd.ini, etc.)
#   dir      => 'd:\\client' - assumed current directory (overrides real cd)
#   echo     => echoText | echoInfo | echoWarning | echoError | echoInternal |
#               echoCaller | echoStd | echoAll
#                            - stdout echos sd text/info/warning/error/internal
#                              error/caller error/standard set/all output
#   echofunc => \&myecho     - caller-provided function handles echo output
#                              (expect arguments like print; echofunc may call
#                              echotype() to determine or change output type)
#                              AS OF $VERSION 2.61, MUST BE PREPARED FOR
#                              MULTIPLE LINES AT ONCE.
#   host     => 'MACHINE'    - host machine (overrides sd.ini, etc.)
#   ini      => 'd:\\MY.INI' - settings file (overrides sd.ini)
#   itemfunc => \&myitem     - caller-provided function handles output an item
#                              at a time for supported 'Display list of' subs;
#                              currently SDChanges, SDClients, SDOpened[N],
#                              SD[Branch][Sync|Flush]*
#                              EXPERIMENTAL INTERFACE MAY CHANGE.
#   maxresults=> 50000       - set maxresults (to value smaller than default)
#   password => 'itgrules'   - user password (overrides logged-on credentials)
#   pipeless => 1            - sd.exe output is written to temp file rather
#                              than piped to perl.  Avoids intermediate cmd.exe
#                              processes but uses temporary directory space.
#                              Allows current directoty to be a UNC path.
#                              Inherently incompatible with potentially
#                              interactive commands.
#   port     => 'DEPOT:4000' - server port (overrides sd.ini, etc.)
#   proxy    => 'PROXY:7000' - proxy port (overrides sd.ini, etc.)
#   safesync => 1            - sync (and resolve) operations make effort to
#                              protect themselves against file-in-use problems
#                              on attempts to sync (and resolve) sd.exe, but
#                              may still fail
#   sdexe    => 'sd.exe'     - filename of sd.exe
#   temp     => 'd:\\mytemp' - directory for temporary files
#   user     => 'DOMAIN\\user'
#                            - user name (overrides logged-on credentials)
#   verbose  => 1            - print debugging text
#
# NOTE: echo may not be supportable using SDAPI
#
# FUTURE: warn if directory doesn't exist for dir, file doesn't exist for ini?
# FUTURE: SD supports multiple ini files in series, SD.pm only one
#
sub ConfigSD {
my $roptions = rshifthash(@_);

	die __PACKAGE__ . ".pm: ConfigSD: InitSD not called\n"	if ! $finitsd;

	foreach my $key (keys %$roptions) {
		warn __PACKAGE__ . ".pm: ConfigSD: unrecognized option '$key' ignored\n"
			if ! exists $config{$key};
	}

	my %configSav = %config;

	# directories
	foreach my $key (qw(binarch temp)) {
		if (exists $roptions->{$key}) {
			my $dir = $roptions->{$key};
			if (defined $dir && $dir ne '') {
				# make dir suitable for concatenating with file
				$dir = endir($dir);
				warn __PACKAGE__ .
					".pm: ConfigSD: $key argument not a valid directory\n"
						if ! -d $dir;
			}
			$config{$key} = defined $dir
				? $dir
				: $configDef{$key};
		}
	}

	# callbacks
	foreach my $key (qw(batchfunc echofunc itemfunc)) {
		if (exists $roptions->{$key}) {
			my $rfunc = $roptions->{$key};
			if (! defined $rfunc) {
				$config{$key} = $configDef{$key};
			} elsif (ref $rfunc eq 'CODE') {
				$config{$key} = $roptions->{$key};
			} else {
				warn __PACKAGE__ .
					".pm: ConfigSD: $key argument not a code reference, ignoring\n";
			}
		}
	}

	# numerics
	foreach my $key (qw(maxresults)) {
		if (exists $roptions->{$key}) {
			my $value = $roptions->{$key};
			if (! defined $value) {
				$config{$key} = $configDef{$key};
			} elsif ($value =~ /^\d+$/) {
				$config{$key} = $roptions->{$key};
			} else {
				warn __PACKAGE__ .
					".pm: ConfigSD: $key argument not numeric, ignoring\n";
			}
		}
	}

	# strings and booleans
	my @keys = qw(binmode client dir echo host ini password
				  pipeless port proxy safesync sdexe user verbose);
	foreach my $key (@keys) {
		if (exists $roptions->{$key}) {
			$config{$key} = defined $roptions->{$key}
				? $roptions->{$key}
				: $configDef{$key};
		}
	}

	# refresh internal values dependent on config settings
	if (exists $roptions->{binarch} || exists $roptions->{sdexe}) {
		$bin{sd}  = "$config{binarch}$config{sdexe}";
		unlink $bin{sd2}	if -f $bin{sd2};		# if safesync ever used
		$bin{sd2} = "$config{binarch}sd$$.exe";		# created on demand
		$bin{sd2} =~ s/^(.*)\./$1_./  if $$ == 20;	# avoid Office-private copy
	}

	if (exists $roptions->{temp}) {
		foreach my $key (qw(frm arg pip ini)) {
			$fspec{$key} = "$config{temp}sdpm$$.$key";
		}
	}

	return wantarray ? %configSav : \%configSav;
}



#
# Standard exports - map directly to SD commands.  Function descriptions are
# short reminders about syntax and otherwise, specific to perl implementation;
# see sd help command for more detailed info.
#

#
# SD*Branch - Create or edit a branch specification and its view.
#

#
# sd branch [-f] name
# SDBranch([\'-f',] 'name')
#
#   Return name/undef on success/failure.  ConfigSD(echo => echoAll)
#   recommended to provide context for any prompts.
#
sub SDBranch {
my $opts = shiftopts(@_);
my($name) = @_;

	clearwarnerr;
	my $rout = ShowForm(opt 'interactive', "branch $opts", $name);

	return	if ! defined $rout;
	return $1	if @$rout == 1 && $rout->[0] =~ /^info: Branch (.*) (sav|not chang)ed\.$/;
	return;
}


#
# sd branch -o name
# SDGetBranch('name')
#
#   %branch = (
#     'Branch' => 'branch',
#     ...		# other scalar fields
#     'Options' => {
#       'locked'   => 1,
#     },
#     'View' => [
#       { 'depotSpec'  => '//depot/dev/...',		# NOTE: SD.pm invention
#         'targetSpec' => '//depot/pts/...',		# NOTE: SD.pm invention
#         'unmap'      => 1 },	# if file is not mapped
#       ...
#     ]
#   )
#
#   Return %branch/undef on success/failure.
#
sub SDGetBranch {
my $name = crtquote(@_);

	clearwarnerr;
	return ParseFormCmd("branch -o -- $name", \&ParseOptions, \&ParseView);
}


#
# sd branch -i [-f] < branchfspec
# SDSetBranch([\'-f',] [\]%branch)
#
#   %branch formatted as described at SDGetBranch.
#
#   Return name/undef on success/failure.
#
sub SDSetBranch {
my $opts = shiftopts(@_);
my $rbranch = rshifthash(@_);

	clearwarnerr;
	return	if ! CreateFormFile($fspec{frm}, $rbranch, \&CreateOptions, \&CreateView);

	local *PIPE;
	sdpopen(*PIPE, opt "<$fspec{frm}", "branch -i $opts") || return;
	my @out = readfilt *PIPE;
	sdpclose *PIPE;
	unlink $fspec{frm}	if ! $config{verbose};

	return	if $? != 0;
	return $1	if @out == 1 && $out[0] =~ /^info: Branch (.+) (sav|not chang)ed\.$/;
	return;
}


#
# SDNewBranch - Create a new branch, with specified name, description, options
# and view.  Name must be specified.  Use a default description if none is
# specified.  Use SD default options if no option reference specified.  Create
# branch empty if no view specified.  Specify options as hash reference, and
# view as array reference, as described at SDGetBranch.  Alternatively, view
# may be specified as a list of depotSpec/targetSpec pairs.  When using pairs,
# unmaps cannot be specified.
#
# SDNewBranch([\'-f',] 'name'[, 'Description'[, $roptions[, $rview]]])
# SDNewBranch([\'-f',] 'name'[, 'Description'[, { locked => 1 }[,
#             'depotSpec', 'targetSpec'[, ...]]]])
#
#   Return name/undef on success/failure.
#
# FUTURE: copying ref arguments acknowledges caller owns and detects wrong
# types earlier, but is otherwise unnecessary here; also, view is only copied
# one layer deep
#
sub SDNewBranch {
my $opts = shiftopts(@_);
my($name, $description, $roptions, @view) = @_;

	# FUTURE: use 'Created by DOMAIN\user.' to match SD default?
	my $rbranch = {
		Branch => $name,
		Description => (defined $description)
			? $description
			: 'Created by ' . __PACKAGE__ . '.pm.'
	};

	$rbranch->{Options} = { %$roptions }	if defined $roptions;	# copy

	if (@view == 0) {
		# no view
	} elsif (@view == 1 && ref $view[0]) {
		$rbranch->{View} = [ @{$view[0]} ];		# shallow copy
	} elsif (@view % 2 == 0) {
		while (@view) {
			push @{$rbranch->{View}}, { depotSpec  => shift(@view),
										targetSpec => shift(@view) };
		}
	} else {
		synthcaller "even number of depot/targetSpecs required\n";
		return;
	}

	my @args = ($rbranch);
	unshift @args, \$opts	if $opts ne '';

	return SDSetBranch(@args);
}


#
# sd branch -d [-f] name
# SDDelBranch([\'-f',] 'name')
#
#   Return name/undef on success/failure.
#
sub SDDelBranch {
my $opts = shiftopts(@_);
my($name) = @_;

	clearwarnerr;

	local *PIPE;
	sdpopen(*PIPE, "branch -d $opts", $name) || return;
	my @out = readfilt *PIPE;
	sdpclose *PIPE;

	return	if $? != 0;
	return $1	if @out == 1 && $out[0] =~ /^info: Branch (.*) deleted\.$/;
	return;
}


#
# SDBranches - Display list of defined branches.
#
# sd branches [-l -r -w] [file]
# SDBranches([\'-l -r -w',] [file])
#
#   @branches = (
#     \%branch1,	# subset of structure described at SDGetBranch
#     \%branch2,
#     ...
#   )
#
#   Return @branches/undef on success/failure.
#
sub SDBranches {
my $opts = shiftopts(@_);
my @file = @_;

	clearwarnerr;

	my @branches;
	local *PIPE;
	sdpopen(*PIPE, "branches $opts", @file) || return;
	while (my $rec = readfilt *PIPE) {
		enext $rec	if $rec !~ m!^info: Branch (\S+) ($redatime) '(.*)'$!;
		push @branches, { 'Branch' => $1, 'Access' => $2, 'Description' => $3 };
	}
	sdpclose *PIPE;

	return	if @branches == 0 && $? != 0;
	return wantarray ? @branches : \@branches;
}



#
# SD*Change - Create or edit a changelist description.
#

#
# sd change [-D -f] [changelist#]
# SDChange([\'-D -f',] [$ncl])
#
# sd change -C description
# SDChange([\'-C description'])
#
#   Return ncl/undef on success/failure.  ConfigSD(echo => echoAll)
#   recommended to provide context for any prompts.
#
# NOTE: '-D' option requires SD server >= 3.7
#
sub SDChange {
my $opts = shiftopts(@_);
my($ncl) = @_;

	clearwarnerr;
	nclnorm($ncl, '') || return;

	my $rout = ShowForm(opt 'interactive', "change $opts", $ncl);

	return	if ! defined $rout;
	return $1	if @$rout == 1 && $rout->[0] =~ /^info: Change (\d+) (creat|updat)ed/;
	return;
}


#
# sd change -o [-D] [changelist#]
# SDGetChange([\'-D',] [$ncl])
#
#   %change = (
#     'Change'      => 12345,	# or 'new'
#     'Client'      => 'MYCLIENTNAME',
#     'Date'        => '2001/05/07 09:25:24',
#     'Description' => 'text description of change'
#     'Status'      => 'submitted',
#     'User'        => 'MYDOMAIN\\myalias',
#     'Files' => [
#       { 'depotFile' => '//depot/dev/src/code.c',
#         'action'    => 'edit',
#         # following only in SDDescribe
#         'rev'       => 23,
#         # following only in SDDescribe without -s
#         'type'      => 'text',
#         'diff'      => ["5c5\n", "< old\n", "---\n", "> new\n"]
#       },
#       ...
#     ]
#   )
#
#   Return %change/undef on success/failure.
#
# NOTE: '-D' option requires SD server >= 3.7
# FUTURE: parse Files, Jobs info further
#
sub SDGetChange {
my $opts = shiftopts(@_);
my($ncl) = @_;

	clearwarnerr;
	nclnorm($ncl, '') || return;
	return ParseFormCmd("change -o $opts -- $ncl", \&ParseFiles);
}


#
# sd change -i [-D -f] < changefspec
# SDSetChange([\'-D -f',] [\]%change)
#
#   %change formatted as described at SDGetChange.
#
#   Return changelist#/undef on success/failure.
#
# NOTE: '-D' option requires SD server >= 3.7
#
sub SDSetChange {
my $opts = shiftopts(@_);
my $rchange = rshifthash(@_);

	clearwarnerr;

	# NOTE: In SD 1.7, an existing Status field may not be sent back to server;
	# in SD 3.0, it must be sent back to server (other versions not verified
	# one way or the other).  Enable 'delete' line as necessary when working
	# against an old server.
	#delete $rchange->{Status};
	return	if ! CreateFormFile($fspec{frm}, $rchange, \&CreateFiles);

	local *PIPE;
	sdpopen(*PIPE, opt "<$fspec{frm}", "change -i $opts") || return;
	my @out = readfilt *PIPE;
	sdpclose *PIPE;
	unlink $fspec{frm}	if ! $config{verbose};

	return	if $? != 0;
	return $1	if @out == 1 && $out[0] =~ /^info: Change (\d+) (creat|updat)ed/;
	return;
}


#
# SDNewChange - Create a new change, with specified description and files.  Use
# a default description if none specified.  Create change empty if no files
# specified.  ARGUMENT MEANINGS CHANGED WITH $VERSION 0.94 OF SD.PM.  Adjust
# old code with arguments.  No-argument semantics are unchanged.
#
# SDNewChange([\'-D -f',] ['Description', ['file'[, ...]]])
#
#   Return changelist#/undef on success/failure.
#
# NOTE: '-D' option requires SD server >= 3.7
#
sub SDNewChange {
my $opts = shiftopts(@_);
my($description, @files) = @_;

	# FUTURE: use '<enter description here>' to prevent submission with no
	# real description
	my $rchange = {
		Change		=> 'new',
		Description => (defined $description)
			? $description
			: '<created by ' . __PACKAGE__ . '.pm>'
	};

	foreach my $file (@files) {
		push @{$rchange->{Files}}, { 'depotFile' => $file };
	}

	my @args = ($rchange);
	unshift @args, \$opts	if $opts ne '';

	return SDSetChange(@args);
}


#
# sd change -d [-f] changelist#
# SDDelChange([\'-f',] $ncl)
#
#   Return changelist#/undef on success/failure.
#
sub SDDelChange {
my $opts = shiftopts(@_);
my($ncl) = @_;

	clearwarnerr;
	nclnorm($ncl) || return;

	local *PIPE;
	sdpopen(*PIPE, "change -d $opts", $ncl) || return;
	my @out = readfilt *PIPE;
	sdpclose *PIPE;

	return	if $? != 0;
	return $1	if @out == 1 && $out[0] =~ /^info: Change (\d+) deleted\.$/;
	return;
}


#
# SDChanges - Display list of pending and submitted changelists.
#
# sd changes [-A -c client -e -i -l -m [skip,]count -r -s status -u user]
#            [file[revRange] ...]
# SDChanges([\'-e -c client -i -l -m [skip,]count -r -s status -u user',]
#           ['file[revRange]', ...])
#
#   @changes = (
#     \%change1,	# subset of structure described at SDGetChange
#     \%change2,
#     ...
#   )
#
#   Return @changes/undef on success/failure.  If config{itemfunc}, items are
#   returned through callback, and @changes is empty.
#
# NOTE: '-c client' option requires SD server >= 3.6
# NOTE: In SD.pm, field names match sd change -o, not SDAPI (i.e. proper case
# not lower case, Description, not desc).
# FUTURE: handle output from -A option
#
sub SDChanges {
my $opts = shiftopts(@_);
my @files = @_;

	clearwarnerr;

	my ($rchange, @changes);

	my $rfnitem = defined $config{itemfunc}		? $config{itemfunc}
				: defined wantarray				? sub { push @changes, @_ }
				:								  sub {};

	local *PIPE;
	sdpopen(*PIPE, "changes $opts", @files) || return;
	while (my $rec = readfilt *PIPE) {
		# Change line indicates start of record
		if ($rec =~ m!^info: Change (\d+) on ($redatime) by $reduc2( \*pending\*)?(?: '(.*)')?$!) {
			if (defined $rchange) {
				$rchange->{Description} = ''	if ! defined $rchange->{Description};
				chomp $rchange->{Description};
				$rfnitem->($rchange);
			}
			undef $rchange;
			@{$rchange}{qw(Change Date User Client Description)} =
				($1, $2, $3, $4, $6);
			$rchange->{Status} = defined $5 ? 'pending' : 'submitted';
		} elsif ($rec =~ m!^info: $!) {
			next;	# blank lines separate Changes from long descriptions
		} elsif ($rec =~ m!^info: \t(.*)$!) {
			$rchange->{Description} .= "$1\n";
		} else {	# unreached
			enext $rec;
		}

	}
	sdpclose *PIPE;
	# handle any partial record
	if (defined $rchange) {
		$rchange->{Description} = ''	if ! defined $rchange->{Description};
		chomp $rchange->{Description};
		$rfnitem->($rchange);
	}

	return	if @changes == 0 && $? != 0;
	return wantarray ? @changes : \@changes;
}



#
# SD*Counter - Display, set, or delete a counter.
#

#
# sd counter name
# SDGetCounter('name')
#
#   Return counter value/undef on success/failure.
#
sub SDGetCounter {
my($name) = @_;

	clearwarnerr;

	local *PIPE;
	sdpopen(*PIPE, "counter", $name) || return;
	my @out = readfilt *PIPE;
	sdpclose *PIPE;

	return	if $? != 0;
	return $1	if @out == 1 && $out[0] =~ /^info: (\d+)$/;
	return;
}


#
# sd counter name value
# SDSetCounter('name', value)
#
#   Return name/undef on success/failure.
#
sub SDSetCounter {
my($name, $value) = @_;

	clearwarnerr;

	local *PIPE;
	sdpopen(*PIPE, "counter", $name, $value) || return;
	my @out = readfilt *PIPE;
	sdpclose *PIPE;

	return	if $? != 0;
	return $1	if @out == 1 && $out[0] =~ /^info: Counter (.+) set\.$/;
	return;
}


#
# sd counter -d name
# SDDelCounter('name')
#
#   Return name/undef on success/failure.
#
sub SDDelCounter {
my($name) = @_;

	clearwarnerr;

	local *PIPE;
	sdpopen(*PIPE, "counter -d", $name) || return;
	my @out = readfilt *PIPE;
	sdpclose *PIPE;

	return	if $? != 0;
	return $1	if @out == 1 && $out[0] =~ /^info: Counter (.+) deleted\.$/;
	return;
}



#
# SDCounters - Display list of known counters.
#
# sd counters
# SDCounters()
#
#   %counters = (
#     'CHANGE'      => 123456,
#     'USERCOUNTER' => 234,
#     ...
#   )
#
#   Return %counters/undef on success/failure.
#
# NOTE: In SD.pm, counter names are guaranteed to be upper-case; in sd.exe user
# case is preserved.
#
sub SDCounters {

	clearwarnerr;

	my %counters;
	local *PIPE;
	sdpopen(*PIPE, "counters") || return;
	while (my $rec = readfilt *PIPE) {
		enext $rec	if $rec !~ /^info: (.*?) = (\d+)$/;
		$counters{"\U$1\E"} = $2;
	}
	sdpclose *PIPE;

	return	if keys %counters == 0 && $? != 0;
	return wantarray ? %counters : \%counters;
}



#
# SD*Client - Create or edit a client specification and its view.
#

#
# sd client [-f -t template] [name]
# SDClient([\'-f -t template',] ['name'])
#
#   Return 1/undef on success/failure.  ConfigSD(echo => echoAll)
#   recommended to provide context for any prompts.
#
sub SDClient {
my $opts = shiftopts(@_);
my($name) = @_;

	clearwarnerr;
	my $rout = ShowForm(opt 'interactive', "client $opts", $name);

	return	if ! defined $rout;
	return $1	if @$rout == 1 && $rout->[0] =~ /^info: Client (.+) (sav|not chang)ed\.$/;
	return;
}


#
# sd client -o [-t template] [name]
# SDGetClient([\'-t template',] ['name'])
#
#   %client = (
#     'Client' => 'MYCLIENTNAME',
#     ...		# other scalar fields
#     'Options' => {
#       'allwrite' => 0,
#       'clobber'  => 0,	# values shown
#       'compress' => 0,	# here match sd
#       'crlf'     => 1,	# defaults
#       'locked'   => 1,
#       'modtime'  => 0,
#       'rmdir'    => 1,
#     },
#     'View' => [
#       { 'depotSpec'  => '//depot/dev/...',		# NOTE: SD.pm invention
#         'targetSpec' => '//CLIENT/dev/...' },		# NOTE: SD.pm invention
#       { 'depotSpec'  => '//depot/dev/intl/...',
#         'targetSpec' => '//CLIENT/dev/intl/...'
#         'unmap'      => 1 },	# if file is not mapped
#       ...
#     ]
#   )
#
#   Return %client/undef on success/failure.
#
sub SDGetClient {
my $opts = shiftopts(@_);
my $name = crtquote(@_);

	clearwarnerr;
	return ParseFormCmd("client -o $opts -- $name", \&ParseOptions, \&ParseView);
}


#
# sd client -i [-f] < clientfspec
# SDSetClient([\'-f',] [\]%client)
#
#   %client formatted as described at SDGetClient.
#
#   Return name/undef on success/failure.
#
sub SDSetClient {
my $opts = shiftopts(@_);
my $rclient = rshifthash(@_);

	clearwarnerr;
	return	if ! CreateFormFile($fspec{frm}, $rclient, \&CreateOptions, \&CreateView);

	local *PIPE;
	sdpopen(*PIPE, opt "<$fspec{frm}", "client -i $opts") || return;
	my @out = readfilt *PIPE;
	sdpclose *PIPE;
	unlink $fspec{frm}	if ! $config{verbose};

	return	if $? != 0;
	return $1	if @out == 1 && $out[0] =~ /^info: Client (.+) (sav|not chang)ed\.$/;
	return;
}


#
# sd client -d [-f] name
# SDDelClient([\'-f',] 'name')
#
#   Return name/undef on success/failure.
#
sub SDDelClient {
my $opts = shiftopts(@_);
my($name) = @_;

	clearwarnerr;

	local *PIPE;
	sdpopen(*PIPE, "client -d $opts", $name) || return;
	my @out = readfilt *PIPE;
	sdpclose *PIPE;

	return	if $? != 0;
	return $1	if @out == 1 && $out[0] =~ /^info: Client (.*) deleted\.$/;
	return;
}


#
# SDClients - Display list of clients.
#
# sd clients [-d date[,date] -u user -w] [file]
# SDClients([\'-d date[,date] -u user -w',] ['file'])
#
#   @clients = (
#     \%client1,	# subset of structure described at SDGetClient
#     \%client2,
#     ...
#   )
#
#   Return @clients/undef on success/failure.  If config{itemfunc}, items are
#   returned through callback, and @clients is empty.
#
# FUTURE: use -ztag=1 to gain Owner field.  Must deal with unambiguously
# parsing lines of multiline descriptions that might look like subsequent
# fields with old servers (SD server 3.1 and beyond at least prepend such lines
# with an unambiguous tab), and reporting dates in backwards compatible
# fashion.  Applies also to SDBranches, SDLabels and (someday) SDJobs.
#
sub SDClients {
my $opts = shiftopts(@_);
my @files = @_;

	clearwarnerr;

	my @clients;

	my $rfnitem = defined $config{itemfunc}		? $config{itemfunc}
				: defined wantarray				? sub { push @clients, @_ }
				:								  sub {};

	local *PIPE;
	sdpopen(*PIPE, "clients $opts", @files) || return;
	while (my $rec = readfilt *PIPE) {
		enext $rec	if $rec !~ m!^info: Client (\S+) ($redatime) root (.*?) (host (.*) )?'(.*)'$!;
		my $rh = { 'Client' => $1, 'Access' => $2, 'Root' => $3,
				   'Description' => $6 };
		$rh->{Host} = $5	if defined $5;
		$rfnitem->($rh);
	}
	sdpclose *PIPE;

	return	if @clients == 0 && $? != 0;
	return wantarray ? @clients : \@clients;
}



#
# SDDescribe[N] - Display a changelist description
#
# sd describe [-A -d<flag> -D -s] changelist# ...
# SDDescribeN([\'-d<flag> -D -s',] 'changelist#' [, ...])
#
#   @changes = (
#     \%change1,  # as described at SDGetChange
#     \%change2,
#     ...
#   )
#
#   Return @changes/undef on success/failure.
#
# SDDescribe([\'-d<flag> -D -s',] 'changelist#')
#
#   Return %change/undef on success/failure.
#
# NOTE: Non-numeric change numbers, 'package' status, and branch:NN+ format
# revisions are experimental extensions to allow parsing output of sdp.bat
# (assuming  ConfigSD(binarch => 'd:\\sdp\\dir', sdexe => 'sdp.bat')  ) as well
# as standard sd.exe, and subject to change.
#
# NOTE: '-D' option requires SD server >= 3.7
# FUTURE: handle output from -A option
#
sub SDDescribeN {
my $opts = shiftopts(@_);
my @changenums = @_;

	clearwarnerr;

	my ($rchange, @changes, $rfiles, $file, $fsnb);
	my $mode;
	local *PIPE;
	sdpopen(*PIPE, "describe $opts", @changenums) || return;
	# REVIEW: some prefixed diff lines can look like Change lines (and will be
	# misconstrued) in diff styles other than default
	while (my $rec = readfilt *PIPE) {

		# Change line indicates start of record (description mode)
		if ($rec =~ /^text: Change (.+?) by $reduc2 on ($redatime)(?: \*(pending|package)\*)?$/) {
			if (defined $rchange) {
				$rchange->{Description} = ''	if ! exists $rchange->{Description};
				chomp $rchange->{Description};
				push @changes, $rchange;
			}
			undef $rchange;
			@{$rchange}{qw(Change User Client Date)} = ($1, $2, $3, $4);
			$rchange->{Status} = defined $5 ? $5 : 'submitted';
			$mode = 0;
			undef $rfiles;
			undef $file;
			undef $fsnb;

		# select other modes  FUTURE: prefer eq to =~ ?
		} elsif ($rec =~ /^text: Affected files \.\.\.$/) {
			$mode = 1;
		} elsif ($rec =~ /^text: Differences \.\.\.$/) {
			$mode = 2;
			$rfiles = IndexHashList($rchange->{Files}, 'depotFile');
			$fsnb = 1;

		# handle content as appropriate for mode
		} elsif ($mode == 0) {	# description

			if ($rec =~ /^text: \t(.*)$/) {
				$rchange->{Description} .= "$1\n";
			} elsif ($rec !~ /^text: $/) {	# skip blank lines
				enext $rec;
			}

		} elsif ($mode == 1) {	# affected files

			if ($rec =~ /^info1: (.*)#((?:.+?:)??\d+\+?) (.*)$/) {
				push @{$rchange->{Files}},
					{ 'depotFile' => $1, 'rev' => $2, 'action' => $3 };
			} elsif ($rec !~ /^text: $/) {	# skip blank lines
				enext $rec;
			}

		} elsif ($mode == 2) {	# differences

			if ($fsnb) {	# skip next line if blank
				# fsnb set after encountering 'Differences' and '==== file'
				undef $fsnb;
				next	if $rec =~ /^text: $/;
			}

			# ==== line indicates start of sub-record
			if ($rec =~ m!^text: ==== (.*?)#(\d+) \((\w+(\+\w+)?)(/\w+(\+\w+)?)?\) ====$!) {
				# trim last blank line from previous file
				pop @{$rfiles->{$file}{diff}}	if defined $file;
				$file = lc $1;	# match IndexHashList key canonicalization
				# FUTURE: assert $rfiles->{$file}{rev} eq $2;
				# FUTURE: preserve previous type in case of type change
				$rfiles->{$file}{type} = $3;
				$rfiles->{$file}{diff} = [];
				$fsnb = 1;
			} elsif ($rec =~ /^text: (.*)$/) {	# keep surviving blank lines
				push @{$rfiles->{$file}{diff}}, $1;
			} else {
				enext $rec;
			}

		} else {	# unreached
			enext $rec;
		}
	}
	sdpclose *PIPE;
	# handle any partial record
	if (defined $rchange) {
		$rchange->{Description} = ''	if ! exists $rchange->{Description};
		chomp $rchange->{Description};
		push @changes, $rchange;
	}

	return  if @changes == 0 && $? != 0;
	return wantarray ? @changes : \@changes;
}
sub SDDescribe { return nto1 SDDescribeN(@_); }



#
# SDDiff[N] - Display diff of client file with depot file.
#
# sd diff [-d<flag> -f -s<flag> -t] [-c changelist#] [file[rev] ...]
# SDDiffN([\'-d<flag> -f -s<flag> -t -c changelist#',] ['file[rev]'][, ...])
#
#   @diffs = (
#     \%diff1,	# as described below
#     \%diff2,
#     ...
#   )
#
#   Return @diffs/undef on success/failure.
#
# SDDiff([\'-d<flag> -f -s<flag> -t -c changelist#',] 'file[rev]')
#
#   %diff = {
#     'depotFile' => '//depot/dev/src/code.c',
#     'depotRev'  => 4,									# FUTURE: haveRev?
#     'localFile' => 'd:\\Office\\dev\\src\\code.c',
#     'diff'      => ["5c5", "< old", "---", "> new" ...]
#   }
#
#   Return %diff/undef on success/failure.  Depending on options, not all
#   fields will exist.
#
# NOTE: 'diff' field text does not include newlines
# FUTURE: parse expected errors
#   /^(F|(.*) - f)ile\(s\) not opened on this client\.$/
#
sub SDDiffN {
my $opts = shiftopts(@_);
my @files = @_;

	clearwarnerr;

	# sd diff respects SD[U]DIFF (SD-specific) and DIFF (general) variables.
	# Suppress any user configuration of diff tool to ensure we get expected
	# text output.  See sd help variables for reference.  See IniSuppressVars
	# for suppression mechanism details.
	# FUTURE: ConfigSD setting to allow use of ambient values (use goto to skip
	# suppression logic)?  Current behaviour is correct default for generally
	# non-interactive reporting command.
	local ($ENV{SDDIFF}, $ENV{SDUDIFF}, $ENV{DIFF});
	my $iniarg = IniSuppressVars('SDDIFF', 'SDUDIFF');
	return	if ! defined $iniarg;

	my ($rdiff, @diffs);
	local *PIPE;
	sdpopen(*PIPE, "$iniarg diff $opts", @files) || return;
	# REVIEW: unprefixed diff lines can look like they have prefixes (and will
	# be misconstrued) in diff styles other than default
	while (my $rec = readfilt *PIPE, 'text') {	# diffs as 'text' matches diff2
		# ==== line indicates start of record
		if ($rec =~ /^info: ==== (.*?)#(\d+) - (.*) ====( \((.*)\))?$/) {
			push @diffs, $rdiff		if defined $rdiff;
			undef $rdiff;
			@{$rdiff}{qw(depotFile depotRev localFile)} = ($1, $2, $3);
			$rdiff->{depotType} = $5	if defined $5;
			next;
		}

		# no ==== line indicates -s<flag> summary (localFile only)
		if (! defined $rdiff) {
			$rec =~ /^info: (.*)$/;
			$rdiff->{localFile} = $1;
			push @diffs, $rdiff;
			undef $rdiff;
			next;
		}

		enext $rec	if $rec !~ /^text: (.*)$/;
		push @{$rdiff->{diff}}, $1;
	}
	sdpclose *PIPE;
	unlink $fspec{ini}	if $iniarg ne '' && ! $config{verbose};
	# handle any partial record
	push @diffs, $rdiff		if defined $rdiff;

	return	if @diffs == 0 && $? != 0;
	return wantarray ? @diffs : \@diffs;
}
sub SDDiff { return nto1 SDDiffN(@_); }



#
# SDDiff2[N] - Display diff of two depot files.
#
# sd diff2 [-d<flag> -q -r -t] file1 file2
# SDDiff2N([\'-d<flag> -q -r -t',] 'file1', 'file2')
#
#   @diffs = (
#     \%diff1,	# as described below
#     \%diff2,
#     ...
#   )
#
#   Return @diffs/undef on success/failure.
#
# SDDiff2([\'-d<flag> -q -r -t',] 'file1', 'file2')
#
#   %diff = {
#     'how'            => 'content',
#     'depotFileLeft'  => '//depot/dev/src/code.c',
#     'depotRevLeft'   => 4,
#     'depotTypeLeft'  => 'text',
#     'depotFileRight' => '//depot/dev/src/code.c',
#     'depotRevRight'  => 5,
#     'depotTypeRight' => 'text',
#     'diff'           => ["5c5\n", "< old\n", "---\n", "> new\n"]
#   }
#
#   Return %diff/undef on success/failure.  Depending on options, not all
#   fields will exist.
#
# FUTURE: parse expected errors
#   /^==== <none> - //depot/dev/src/code.c#4 ====$/
#
sub SDDiff2N {
my $opts = shiftopts(@_);
my @files = @_;

	clearwarnerr;

	my ($rdiff, @diffs);
	local *PIPE;
	sdpopen(*PIPE, "diff2 $opts", @files) || return;
	while (my $rec = readfilt *PIPE) {
		# ==== line indicates start of record
		if ($rec =~ /^info: ==== (?:(.*?)#(\d+)(?: \((.*?)\))?|<none>) - (?:(.*?)#(\d+)(?: \((.*?)\))?|<none>) ====(?: (.*))?$/) {
			push @diffs, $rdiff		if defined $rdiff;
			undef $rdiff;
			@{$rdiff}{qw(depotFileLeft depotRevLeft)} = ($1, $2) if defined $1;
			$rdiff->{depotTypeLeft} = $3 if defined $3;
			@{$rdiff}{qw(depotFileRight depotRevRight)} = ($4, $5) if defined $4;
			$rdiff->{depotTypeRight} = $6 if defined $6;
			$rdiff->{how} = $7 if defined $7;
			next;
		}

		next	if $rec =~ /^info: \(\.\.\. files differ \.\.\.\)$/;
		enext $rec	if $rec !~ /^text: (.*)$/;
		push @{$rdiff->{diff}}, $1;
	}
	sdpclose *PIPE;
	# handle any partial record
	push @diffs, $rdiff		if defined $rdiff;

	return	if @diffs == 0 && $? != 0;
	return wantarray ? @diffs : \@diffs;
}
sub SDDiff2 { return nto1 SDDiff2N(@_); }


#
# SDDiffSummary - Parse -ds summary diffs form SDDiff2, SDDiff2 or SDDescribe.
#
#   \%summary = {
#     'chunksAdd'           => 3,
#     'chunksDeleted'       => 0,
#     'chunksChanged'       => 1,
#     'linesAdd'            => 7,
#     'linesDeleted'        => 0,
#     'linesChangedAdd'     => 5,
#     'linesChangedDeleted' => 5,
#   }
#
#   Return %summary/undef on success/failure.
#
# FUTURE: consider whether to return partial results
#
sub SDDiffSummary {
my($rdiff) = @_;

	clearwarnerr;

	my %summary;
	foreach my $rec (@$rdiff) {
		if ($rec =~ /^(add|deleted) (\d+) chunks (\d+) lines$/) {
			my $key = ucfirst $1;
			@summary{"chunks$key", "lines$key"} = ($2, $3);
		} elsif ($rec =~ m!^changed (\d+) chunks (\d+) / (\d+) lines$!) {
			@summary{qw(chunksChanged linesChangedAdd linesChangedDeleted)} =
				 ($1, $2, $3);
		} else {
			enext $rec;
		}
	}

	return	if keys %summary < 7;
	return wantarray ? %summary : \%summary;
}



#
# SDDirs - List subdirectories of a given depot directory.
#
# sd dirs [-C -D -H] dir[revRange] ...
# SDDirs([\'-C -D -H',] 'dir[revRange]'[, ...])
#
#   @dirs = (
#     'dir1',
#     'dir2',
#     ...
#   )
#
#   Return @dirs/undef on success/failure.
#
# FUTURE: SDDirs is a mistake; should be named SDDirsN (with SDDirs an
# nto1-based wrapper) to match SDFiles pattern.
#
sub SDDirs {
my $opts = shiftopts(@_);
my @indirs = @_;

	clearwarnerr;

	my @dirs;
	local *PIPE;
	sdpopen(*PIPE, "dirs $opts", @indirs) || return;
	while (my $rec = readfilt *PIPE) {
		enext $rec	if $rec !~ m!^info: (.+)$!;
		push @dirs, $1;
	}
	sdpclose *PIPE;

	return	if @dirs == 0 && $? != 0;
	return wantarray ? @dirs : \@dirs;
}



#
# OpenFilesN - SDEdit/Add/DeleteN implementation.  Keep in sync with SDReopenN.
#
# NOTE: on Windows, 'also opened by' is reported as a warning, on Unix/MacOSX
# it's info.  SD.pm translates info form to warning.
# FUTURE: parse expected errors
#   /(.*) - file\(s\) not on client\.$/
#   /(.*) - missing, unable to determine file type/
#
sub OpenFilesN {
my $command = shift(@_);
my $opts = shiftopts(@_);
my $ncl = shift(@_);
my @files = @_;

	clearwarnerr;
	nclnorm($ncl, 'default') || return;

	my @open;
	local *PIPE;
	sdpopen(*PIPE, "$command -c $ncl $opts", @files) || return;
	while (my $rec = readfilt *PIPE) {
		if ($rec =~ /^info: (.*)#(\d+) -( currently)? opened for (\w+)( \(\w+\))?$/) {
			push @open, { 'depotFile' => $1, 'haveRev' => $2, 'action' => $4 };
		} elsif ($rec =~ /^info1: (.* - also opened by $reduc2)$/) {
			synthwarning \1, "$1\n";
		} else {
			enext $rec;
		}
	}
	sdpclose *PIPE;

	return	if @open == 0 && $? != 0;
	return wantarray ? @open : \@open;
}


#
# SDEdit[N]   - Open an existing file for edit.
# SDAdd[N]    - Open a new file to add it to the depot.
# SDDelete[N] - Open an existing file to delete it from the depot.
#
# sd edit [-c changelist# -n -t type -y] file ...
# SDEditN([\'-n -t type -y',] $ncl, 'file'[, ...])
#
# sd add [-c changelist# -f -n -t type] file ...
# SDAddN([\'-f -n -t type',] $ncl, 'file'[, ...])
#
# sd delete [-c changelist# -n -y] file ...
# SDDeleteN([\'-n -y',] $ncl, 'file'[, ...])
#
#   @open = (
#     \%open1,	# as described below
#     \%open2,
#     ...
#   )
#
#   Return @open/undef on success/failure.
#
# SDEdit([\'-n -t type -y',] $ncl, 'file')
# SDAdd([\'-f -n -t type',] $ncl, 'file')
# SDDelete([\'-n -y',] $ncl, 'file')
#
#   %open = {
#     'depotFile' => '//depot/dev/src/code.c',
#     'action'    => 'edit',	# or 'add' or 'delete'
#     'haveRev'   => 4		# 1 for action => 'add'	# FUTURE: actually workRev
#   }
#
#   Return %open (subset of structure described at SDFstat)/undef on
#   success/failure.
#
# A changelist# is always required; specify nclDefault to use default
# changelist.
#
sub SDEditN   { return      OpenFilesN('edit',   @_); }
sub SDAddN    { return      OpenFilesN('add',    @_); }
sub SDDeleteN { return      OpenFilesN('delete', @_); }
sub SDEdit    { return nto1 OpenFilesN('edit',   @_); }
sub SDAdd     { return nto1 OpenFilesN('add',    @_); }
sub SDDelete  { return nto1 OpenFilesN('delete', @_); }



#
# SDFileLog[N] - List revision history of files.
#
# sd filelog [-d<flag> -i -l -m [skip,]count -t -u] file[revRange] ...
# SDFileLogN([\'-d<flag> -i -l -m [skip,]count -t -u',] 'file[revRange]'[,...])
#
#   @filelogs = (
#     \%filelog1,	# as described below
#     \%filelog2,
#     ...
#   )
#
#   Return @filelogs/undef on success/failure.
#
# SDFileLog([\'-d<flag> -i -l -m [skip,]count -t',] 'file[revRange]')
#
#   %filelog = (
#     'depotFile' => '//depot/dev/src/code.c',
#     'changes'   => [
#        \%change1,	# as described below
#        \%change2,
#        ...
#     ],
#   )
#
#   %change = (
#     'rev'    => 23,
#     'change' => 12345,
#     'action' => 'edit',
#     'desc'   => 'First 32 characters of description',
#     'time'   => '2001/05/07 09:25:24',
#     'user'   => 'MYDOMAIN\\myalias',
#     'client' => 'MYCLIENTNAME',
#     'type'   => 'text',
#     'integrate' => [
#        \%integrate1,  # as described below
#        \%integrate2,
#        ...
#     ],
#     # fields as described at SDDiff2 if -d provided
#   )
#
#   %integrate = (
#     'depotFile' => '//depot/dev/src/code.c#4',
#     'action'    => 'merge into' # or copy/branch/etc. variants matched below
#     'undone'    => 1,    # if integration operation was later undone
#   )
#
#   Return %filelog/undef on success/failure.
#
# FUTURE: handle output from -l option
# FUTURE: handle integration history (info2:) according to SDAPI with
# how, file, srev and erev fields instead of depotFile and action (affects
# TagSD.pm)
# FUTURE: share diff-handling code with SDDiff2N
#
sub SDFileLogN {
my $opts = shiftopts(@_);
my @files = @_;

	clearwarnerr;

	my @filelogs;
	my $rfilelog;
	my $rchange;

	local *PIPE;
	sdpopen(*PIPE, "filelog $opts", @files) || return;
	while (my $rec = readfilt *PIPE) {
		if ($rec =~ m!^info: (//.*)$!) {
			# new filelog
			push @{$rfilelog->{changes}}, $rchange		if defined $rchange;
			undef $rchange;
			push @filelogs, $rfilelog		if defined $rfilelog;
			undef $rfilelog;
			$rfilelog->{depotFile} = $1;
		} elsif ($rec =~ /^info1: #(\d+) change (\d+) ([-\w]+) on ($redatime) by $reduc2 \((\w+(\+\w+)?)\) '(.*)'$/) {
			# new change in existing filelog
			push @{$rfilelog->{changes}}, $rchange		if defined $rchange;
			undef $rchange;
			@{$rchange}{qw(rev change action time user client type desc)} =
				($1, $2, $3, $4, $5, $6, $7, $9);
		} elsif ($rec =~ /^info: ==== (.*?)#(\d+) \((.*?)\) - (.*?)#(\d+) \((.*?)\) ==== (.*)$/) {
			# ==== line indicates start of diff, here just made part of change
			@{$rchange}{qw(depotFileLeft depotRevLeft depotTypeLeft)} =
				($1, $2, $3);
			@{$rchange}{qw(depotFileRight depotRevRight depotTypeRight)} =
				($4, $5, $6);
			$rchange->{how} = $7;
		} elsif ($rec =~ /^text: (.*)$/) {
			push @{$rchange->{diff}}, $1;
		} elsif ($rec =~ /^info: \(\.\.\. files differ \.\.\.\)$/) {
			next;	# binary diff
		} elsif ($rec =~ /^info2:( \*undone\*)? (merge from|merge into|branch from|branch into|copy from|copy into|ignored by|ignored|delete from|delete into|edit into|add into) (.*)$/) {
			# integration history
			my $rintegrate = { action => $2, depotFile => $3 };
			$rintegrate->{undone} = 1	if defined $1;
			push @{$rchange->{integrate}}, $rintegrate;
		} else {
			enext $rec;
		}
	}
	sdpclose *PIPE;
	# handle any partial record
	push @{$rfilelog->{changes}}, $rchange		if defined $rchange;
	push @filelogs, $rfilelog	if defined $rfilelog;

	return	if @filelogs == 0 && $? != 0;
	return wantarray ? @filelogs : \@filelogs;
}
sub SDFileLog { return nto1 SDFileLogN(@_); }



#
# SDFiles[N] - List files in the depot
#
# sd files [ -d ] file[revRange] ...
# SDFilesN([\'-d',] 'file[revRange]'[, ...])
#
#   @files = (
#     \%file1,	# as described below
#     \%file2,
#     ...
#   )
#
#   Return @files/undef on success/failure.
#
# SDFiles([\'-d',] 'file[revRange]')
#
#   %file = (
#     'depotFile' => '//depot/dev/src/code.c',
#     'depotRev'  => 3,
#     'action'    => 'edit',
#     'change'    => 33,
#     'type'      => 'text',
#   )
#
#   Return %file/undef on success/failure.
#
sub SDFilesN {
my $opts = shiftopts(@_);
my @infiles = @_;

	clearwarnerr;

	my @files;
	local *PIPE;
	sdpopen(*PIPE, "files $opts", @infiles) || return;
	while (my $rec = readfilt *PIPE) {
		enext $rec	if $rec !~ m!^info: (.*)#(\d+) - ([-\w]+) change (\d+) \((.*)\)$!;
		push @files, { 'depotFile' => $1, 'depotRev' => $2, 'action' => $3,
					   'change' => $4, 'type' => $5 };
	}
	sdpclose *PIPE;

	return	if @files == 0 && $? != 0;
	return wantarray ? @files : \@files;
}
sub SDFiles { return nto1 SDFilesN(@_); }



#
# SDFstat[N] - Dump file info.
#
# sd fstat [-c changelist#] [-C -H -L -P -s -W] file[rev] ...
# SDFstatN([\'-c changelist# -C -H -L -P -s -W',] 'file[rev]'[, ...])
#
#   @files = (
#     \%file1,	# as described below
#     \%file2,
#     ...
#   )
#
#   Return @files/undef on success/failure.
#
# SDFstat([\'-c changelist# -C -H -L -P -s -W',] 'file[rev]')
#
#   %file = (
#     'depotFile'  => '//depot/dev/src/code.c',
#     'clientFile' => '//CLIENT/dev/src/code.c',
#     'localFile'  => 'd:\\Office\\dev\\src\\code.c',
#     'action'     => 'edit',
#     'change'     => 'default',
#     'headRev'    => 8,
#     'haveRev'    => 8,
#     'otherOpens' => [									# NOTE: SD.pm invention
#       { 'otherUser'   => 'SOMEDOMAIN\\somealias',		# NOTE: SD.pm invention
#         'otherClient' => 'SOMECLIENTNAME',			# NOTE: SD.pm invention
#         'otherAction' => 'edit' },	# or 'add' or 'delete'
#       { 'otherUser'   => 'SOMEDOMAIN\\someotheralias',
#         'otherClient' => 'SOMEOTHERCLIENT',
#         'otherAction' => 'edit' },
#       ...
#     ]
#     ...		# other scalar fields
#   )
#
#   Return %file/undef on success/failure.  Various functions take/return
#   subsets of this structure.
#
#   These functions are fairly expensive; avoid calling them.
#
# NOTE: In SD.pm, clientFile is always in depot syntax, localFile is always
# in local syntax.  sd.exe may put localFile into clientFile, and not provide
# localFile.  For otherOpens, sd.exe provides a username@client, which SD.pm
# splits into otherUser and otherClient.
#
# NOTE: SDFstat('filerepointedtobuildlabtree') (no 'N') will fail because sd
# fstat returns (at least) two records.  sd edit filerepointedtobuildlabtree
# can result in three records.  In the presence of such files, even files not
# repointed to the build lab tree can generate multiple records.  Worse, the
# data may not be accurate in multiple record cases; there is no reliable way
# to merge the records and guarantee correct results because the root cause is
# a bad join in SD.  A future version of SD may fix this behaviour.  Until
# then, at least, avoid SDFstat for potentially repointed files.
#
# FUTURE: provide otherOpens->[n]->{otherOpen} = username@client ?
#
sub SDFstatN {
my $opts = shiftopts(@_);
my @infiles = @_;

	clearwarnerr;

	my ($rfile, @files);
	local *PIPE;
	sdpopen(*PIPE, "fstat $opts", @infiles) || return;
	while (my $rec = readfilt *PIPE) {
		# empty line indicates end of record
		if ($rec =~ /^info:\s*$/ && defined $rfile) {
			push @files, $rfile;
			undef $rfile;
		} elsif ($rec =~ /^info1: (\w+) (.*)$/) {
			$rfile->{$1} = $2;
			# without -P, clientFile field is really localFile syntax
			if ($1 eq 'clientFile' && $rfile->{clientFile} !~ m!^//!) {
				$rfile->{localFile} = $rfile->{clientFile};
				delete $rfile->{clientFile};
			}
		} elsif ($rec =~ /^info1: (\w+)$/) {
			$rfile->{$1} = 1;
		} elsif ($rec =~ /^info2:/) {
			# GetVarX
			if ($rec =~ /^info2: (otherOpen)(\d+) $reduc2$/) {
				$rfile->{otherOpens}->[$2]->{otherUser} = $3;
				$rfile->{otherOpens}->[$2]->{otherClient} = $4;
			} elsif ($rec =~ /^info2: (otherAction)(\d+) ([-\w]+)$/) {
				$rfile->{otherOpens}->[$2]->{$1} = $3;
			} elsif ($rec =~ /^info2: (otherExclusive)(\d+)$/) {
				$rfile->{otherOpens}->[$2]->{$1} = 1;

			# GetVar
			} elsif ($rec =~ /^info2: (otherOpen) (\d+)$/) {
				$rfile->{$1} = $2;
			} elsif ($rec =~ /^info2: (otherLock)$/) {
				$rfile->{$1} = 1;
			} else {
				enext $rec;
			}
		} else {
			enext $rec;
		}
	}
	sdpclose *PIPE;
	# handle any partial record
	push @files, $rfile		if defined $rfile;

	return	if @files == 0 && $? != 0;
	return wantarray ? @files : \@files;
}
sub SDFstat { return nto1 SDFstatN(@_); }



#
# SD*Group - Change members of user group.
#

#
# sd group -o name
# SDGetGroup('name')
#
#   %group = (
#     'Group'      => 'mygroup',
#     'MaxResults' => 'unlimited',
#     'MaxScanRows'=> 'unlimited',
#     'Subgroups' => [
#         'subgroup1',
#         'subgroup2',
#         ...
#     ],
#     'Users' => [
#         'user1',
#         'user2',
#         ...
#     ],
#   )
#
#   Return %group/undef on success/failure.
#
sub SDGetGroup {
my $name = crtquote(@_);

	clearwarnerr;
	return ParseFormCmd("group -o -- $name", \&ParseNames);
}


#
# sd group -d name
# SDDelGroup('name')
#
#   Return name/undef on success/failure.
#
sub SDDelGroup {
my($name) = @_;

	clearwarnerr;

	local *PIPE;
	sdpopen(*PIPE, "group -d", $name) || return;
	my @out = readfilt *PIPE;
	sdpclose *PIPE;

	return	if $? != 0;
	return $1	if @out == 1 && $out[0] =~ /^info: Group (.*) deleted\.$/;
	return;
}


#
# SDGroups - List groups (of users).
#
# sd groups
# SDGroups()
#
#   @groups = (
#     'group1',
#     'group2',
#     ...
#   )
#
#   Return @groups/undef on success/failure.
#
# FUTURE: document and handle output from new-for-2.7 -t, -g, -m options and
# user arg
#
sub SDGroups {

	clearwarnerr;

	my @groups;
	local *PIPE;
	sdpopen(*PIPE, "groups") || return;
	while (my $rec = readfilt *PIPE) {
		enext $rec	if $rec !~ m!^info: (\S+)$!;
		push @groups, $1;
	}
	sdpclose *PIPE;

	return	if @groups == 0 && $? != 0;
	return wantarray ? @groups : \@groups;
}



#
# SDHave[N] - List revisions last synced.
#
# sd have [file[revRange] ...]
# SDHaveN(['file[revRange]', ...])
#
#   @have = (
#     \%have1,	# as described below
#     \%have2,
#     ...
#   )
#
#   Return @have/undef on success/failure.
#
# SDHave('file')
#
#   %have = {
#     'depotFile'  => '//depot/dev/src/code.c',
#     'clientFile' => '//CLIENT/dev/src/code.c',
#     'localFile'  => 'd:\\Office\\dev\\src\\code.c',
#     'haveRev'    => 4
#     'type'      => 'text',
#   }
#
#   Return %have (subset of structure described at SDFstat)/undef on
#   success/failure.
#
# NOTE: with -ztag=1, unknownRev is a field in %have, without, it's a warning;
# provide both here
# FUTURE: parse expected errors
#   /^(F|(.*) - f)ile\(s\) not on( this)? client\.$/
#
sub SDHaveN {
my @files = @_;

	clearwarnerr;

	my ($rhave, @have);
	local *PIPE;
	sdpopen(*PIPE, opt 'ztag', "have", @files) || return;
	while (my $rec = readfilt *PIPE) {
		# empty line indicates end of record ...
		if ($rec =~ /^info:\s*$/ && defined $rhave) {
			push @have, $rhave;
			undef $rhave;
		} elsif ($rec =~ /^info1: (\w+)(?: (.*))?$/) {
			if (exists $rhave->{$1}) {	# ... except on Unix with -s -ztag
				push @have, $rhave;
				undef $rhave;
			}
			$rhave->{$1} = defined $2 ? $2 : 1;
			if ($1 eq 'unknownRev') {
				synthwarning \1,
				  "$rhave->{depotFile} - server may not have accurate information about local revision\n";
			}
		} else {
			enext $rec;
		}
	}
	sdpclose *PIPE;
	# handle any partial record
	push @have, $rhave		if defined $rhave;

	return	if @have == 0 && $? != 0;
	return wantarray ? @have : \@have;
}
sub SDHave { return nto1 SDHaveN(@_); }



#
# DoInfo - SDInfo/AdminInfo implementation.
#
sub DoInfo {
my $command = shift(@_);

	clearwarnerr;

	my %info;
	local *PIPE;
	sdpopen(*PIPE, $command) || return;
	while (my $rec = readfilt *PIPE) {
		if ($rec =~ /^info: (.*?): (.*)$/) {
			$info{$1} = $2;
		} elsif ($rec =~ /^info: (Compression is( not)? enabled between the proxy and server\(s\)\.)$/) {
			# proxy-specific output
			$info{'Compress To Server'} = $1;
			$info{CompressToServer} = ! defined $2 ? 1 : 0;
		} elsif ($rec =~ /^info: (Compression is (dis)?allowed between the proxy and client\(s\)\.)$/) {
			# proxy-specific output
			$info{'Compress To Client'} = $1;
			$info{AllowCompressToClient} = ! defined $2 ? 1 : 0;
		} elsif ($rec =~ /^info: Client unknown\.$/) {
			# skip
		} elsif ($rec =~ /^text: (.*?): (.*)$/) {
			$info{$1} = $2;		# InfoBoilerplateFile text, formatted to match
		} elsif ($rec =~ /^text: /) {
			# skip InfoBoilerplateFile text not formatted to match
		} else {
			enext $rec;
		}
	}
	sdpclose *PIPE;

	return	if keys %info == 0 && $? != 0;
	return wantarray ? %info : \%info;
}


#
# SD[Admin]Info - Return client/server information.
#
# sd info [-s]
# SDInfo()
#
# sd admin info
# SDAdminInfo()
#
#   %info = (
#     'Client root'       => 'd:\\Office',
#     'Current directory' => 'd:\\Office\\dev\\lib\\perl\\office',
#     'Server version'    => 'SDS 1.60.2606.0 (NT X86)',
#     ...		# other scalar fields
#   )
#
#   Return %info/undef on success/failure.
#
# NOTE: CompressToServer/AllowCompressToClient and equivalent friendly settings
# are experimental SD.pm inventions and subject to change.
# FUTURE: allow and handle output from -s option?
# FUTURE: collect non-matching lines as InfoBoilerplateFile?
#
sub SDInfo      { return DoInfo('info',       @_); }
sub SDAdminInfo { return DoInfo('admin info', @_); }



#
# SDIntegrate - Schedule integrations from one file to another.
#
# sd integrate [-c changelist# options] fromFile/toFile[revRange] ...
# SDIntegrateN([\'options',] $ncl, 'fromFile/toFile[revRange]'[, ...])
#
#   @integrate = (
#     \%integrate1,	# as described below
#     \%integrate2,
#     ...
#   )
#
#   Return @integrate/undef on success/failure.
#
# SDIntegrate([\'options',] $ncl, 'fromFile[revRange]', 'toFile')
#
#   %integrate = {
#     'toFile'    => 'd:\\Office\\dev\\src\\copyofcode.c',
#     'rev'       => 5,
#     'fromFile'  => '//depot/dev/src/code.c',
#     'how'       => 'integrate',	# or 'branch/sync'
#     'srev'      => 1,
#     'erev'      => 23,
#   }
#
#   Return %integrate/undef on success/failure.
#
# FUTURE: should ' from' be included in 'how' field to match SDAPI structured
# mode for sd integrated/resolved?
# FUTURE: parse expected errors
#   /(.*) - file\(s\) not in client view\.$/
#   /(.*) - no target file\(s\) in both client and branch view\./
#
sub SDIntegrateN {
my $opts = shiftopts(@_);
my $ncl = shift(@_);
my @files = @_;

	clearwarnerr;
	nclnorm($ncl, 'default') || return;

	my @int;
	local *PIPE;
	sdpopen(*PIPE, "integrate -c $ncl $opts", @files) || return;
	while (my $rec = readfilt *PIPE) {
		enext $rec
			if $rec !~ m!^info: (.*)#(\d+) - (branch/sync|sync/delete|sync/integrate|branch|integrate|delete) from (//.+?)(#(\d+)(,#(\d+))?)$!;
		push @int, { 'toFile' => $1, 'rev'      => $2,
					 'how'    => $3, 'fromFile' => $4,
					 'srev'   => $6, 'erev'     => defined $8 ? $8 : $6 };
	}
	sdpclose *PIPE;

	return	if @int == 0 && $? != 0;
	return wantarray ? @int : \@int;
}
sub SDIntegrate { return nto1 SDIntegrateN(@_); }



#
# SDIntegrated - Show integrations that have been submitted.
#
# sd integrated [-u] [-s] [-b branch -r] file[revRange] ...
# SDIntegratedN([\'options',] 'file[revRange]'[, ...])
#
#   @integrated = (
#     \%integrated1,	# as described below
#     \%integrated2,
#     ...
#   )
#
#   Return @integrated/undef on success/failure.
#
# SDIntegrated([\'options',] 'file[revRange]')
#
#   %integrated = {
#     'toFile'    => 'd:\\Office\\dev\\src\\copyofcode.c',
#     'rev'       => 5,
#     'fromFile'  => '//depot/dev/src/code.c',
#     'how'       => 'merge from' # or copy/branch/etc. variants matched below
#     'srev'      => 1,
#     'erev'      => 23,
#   }
#
#   Return %integrated/undef on success/failure.
#
sub SDIntegratedN {
my $opts = shiftopts(@_);
my @files = @_;

	clearwarnerr;

	my @int;
	local *PIPE;
	sdpopen(*PIPE, "integrated $opts", @files) || return;
	while (my $rec = readfilt *PIPE) {
		enext $rec
			if $rec !~ m!^info: (.*)#(\d+) - (merge from|merge into|branch from|branch into|copy from|copy into|ignored by|ignored|delete from|delete into|edit into|add into) (//.+?)(#(\d+)(,#(\d+))?)$!;
		push @int, { 'toFile' => $1, 'rev'      => $2,
					 'how'    => $3, 'fromFile' => $4,
					 'srev'   => $6, 'erev'     => defined $8 ? $8 : $6 };
	}
	sdpclose *PIPE;

	return	if @int == 0 && $? != 0;
	return wantarray ? @int : \@int;
}
sub SDIntegrated { return nto1 SDIntegratedN(@_); }



#
# SD*Label - Create or edit a label specification and its view.
#

#
# sd label [-f -t template] [name]
# SDLabel([\'-f -t template',] ['name'])
#
#   Return 1/undef on success/failure.  ConfigSD(echo => echoAll)
#   recommended to provide context for any prompts.
#
sub SDLabel {
my $opts = shiftopts(@_);
my($name) = @_;

	clearwarnerr;
	my $rout = ShowForm(opt 'interactive', "label $opts", $name);

	return	if ! defined $rout;
	return $1	if @$rout == 1 && $rout->[0] =~ /^info: Label (.+) (sav|not chang)ed\.$/;
	return;
}


#
# sd label -o [-t template] name
# SDGetLabel([\'-t template',] 'name')
#
#   %label = (
#     'Label' => 'latest',
#     ...		# other scalar fields
#     'Options' => {
#       'locked' => 1
#     },
#     'View' => [
#       { 'depotSpec'  => '//depot/dev/...' },		# NOTE: SD.pm invention
#       ...
#     ]
#   )
#
#   Return %label/undef on success/failure.
#
sub SDGetLabel {
my $opts = shiftopts(@_);
my $name = crtquote(@_);

	clearwarnerr;
	return ParseFormCmd("label -o $opts -- $name", \&ParseOptions, \&ParseView);
}



#
# sd label -i < labelfspec
# SDSetLabel([\'-f',] [\]%label)
#
#   %label formatted as described at SDGetLabel.
#
#   Return label/undef on success/failure.
#
sub SDSetLabel {
my $opts = shiftopts(@_);
my $rlabel = rshifthash(@_);

	clearwarnerr;
	return	if ! CreateFormFile($fspec{frm}, $rlabel, \&CreateOptions, \&CreateView);

	local *PIPE;
	sdpopen(*PIPE, opt "<$fspec{frm}", "label -i $opts") || return;
	my @out = readfilt *PIPE;
	sdpclose *PIPE;
	unlink $fspec{frm}	if ! $config{verbose};

	return	if $? != 0;
	return $1	if @out == 1 && $out[0] =~ /^info: Label (.+) (sav|not chang)ed\.$/;
	return;
}


#
# sd label -d [-f] name
# SDDelLabel([\'-f',] 'name')
#
#   Return name/undef on success/failure.
#
sub SDDelLabel {
my $opts = shiftopts(@_);
my($name) = @_;

	clearwarnerr;

	local *PIPE;
	sdpopen(*PIPE, "label -d $opts", $name) || return;
	my @out = readfilt *PIPE;
	sdpclose *PIPE;

	return	if $? != 0;
	return $1	if @out == 1 && $out[0] =~ /^info: Label (.*) deleted\.$/;
	return;
}



#
# sd labelsync [-a -d -n] -l label [file[revRange] ...]
# SDLabelSync([\'-a -d -n',] $label, 'file[revRange]')
#
#   %labelsync = (
#     'depotFile' => '//depot/dev/src/code.c',
#     'action'    => 'updated'	# or 'added' or 'deleted' or unavailable
#     'haveRev'   => 4
#   )
#
#   Return %labelsync/undef on success/failure.
#
# FUTURE: parse expected errors
#   /^(F|(.*) - f)ile\(s\) not on client\.$/
#
sub SDLabelSync {
my $opts = shiftopts(@_);
my $label = shift(@_);
my @filerevs = @_;

	clearwarnerr;
	lblnorm($label) || return;

	my @labelsync;
	local *PIPE;
	sdpopen(*PIPE, "labelsync $label $opts", @filerevs) || return;
	while (my $rec = readfilt *PIPE) {
		if ($rec =~ /^info: (.*)#(\d+) - (.*ed)$/) {
			push @labelsync, { 'depotFile' => $1, 'haveRev' => $2,
							   'action' => $3 };
		} elsif ($rec =~ /^info: (.*)#(\d+) - /) {
			push @labelsync, { 'depotFile' => $1, 'haveRev' => $2 };
		} else {
			enext $rec;
		}
	}
	sdpclose *PIPE;

	return	if @labelsync == 0 && $? != 0;
	return wantarray ? @labelsync : \@labelsync;
}



#
# SDLabels - Display list of defined labels.
#
# sd labels [-d date[,date] -u] [file[revRange]]
# SDLabels([\'-d date[,date] -u'] ['file[revRange]'])
#
#   @labels = (
#     \%label1,	# subset of structure described at SDGetLabel
#     \%label2,
#     ...
#   )
#
#   Return @labels/undef on success/failure.
#
sub SDLabels {
my $opts = shiftopts(@_);
my @files = @_;

	clearwarnerr;
	my $datimetype = $opts =~ /-u/ ? 'Update' : 'Access';

	my @labels;
	local *PIPE;
	sdpopen(*PIPE, "labels $opts", @files) || return;
	while (my $rec = readfilt *PIPE) {
		enext $rec	if $rec !~ m!^info: Label (\S+) ($redatime) '(.*)'$!;
		push @labels, { 'Label' => $1, $datimetype => $2, 'Description' => $3 };
	}
	sdpclose *PIPE;

	return	if @labels == 0 && $? != 0;
	return wantarray ? @labels : \@labels;
}



#
# SDOpened[N] - Display list of files opened for pending changelist.
#
# sd opened [-a -c changelist# -l -u user] [file ...]
# SDOpenedN([\"-a -c $ncl -l -u user",] ['file', ...])
#
#   @opened = (
#     \%opened1,	# as described below
#     \%opened2,
#     ...
#   )
#
#   Return @opened/undef on success/failure.  If config{itemfunc}, items are
#   returned through callback, and @opened is empty.
#
# SDOpened([\"-a -c $ncl -l -u user",] 'file')
#
#   %opened = {
#     'depotFile' => '//depot/dev/src/code.c',
#     'haveRev'   => 4,
#     'action'    => 'edit',
#     'change'    => 12345,					# or 'default'
#     'user'      => 'MYDOMAIN\\myalias',	# optional
#     'client'    => 'MYCLIENTNAME',		# optional
#     'ourLock'   => 1,						# only exists if locked
#   }
#
#   Return %opened (subset of structure described at SDFstat)/undef on
#   success/failure.
#
# NOTE: In SD.pm, depotFile is always in depot syntax, localFile is always in
# local syntax.  sd.exe may put localFile into depotFile, and not provide
# localFile.  This is not an issue with -ztag=1 output.
# NOTE: haveRev is actually workRev for files that have been implicitly synced
# by sd submit.
#
# FUTURE: parse expected errors
#   /^(F|(.*) - f)ile\(s\) not opened on this client\.$/
#   /^(F|(.*) - f)ile\(s\) not opened in that changelist\.$/   (2.0)
#   /^(F|(.*) - f)ile\(s\) not opened anywhere\.$/
#
sub SDOpenedN {
my $opts = shiftopts(@_);
my @files = @_;

	clearwarnerr;

	my ($ropened, @opened);

	my $rfnitem = defined $config{itemfunc}		? $config{itemfunc}
				: defined wantarray				? sub { push @opened, @_ }
				:								  sub {};

	local *PIPE;
	sdpopen(*PIPE, opt 'ztag', "opened $opts", @files) || return;
	while (my $rec = readfilt *PIPE) {
		# empty line indicates end of record ...
		if ($rec =~ /^info:\s*$/ && defined $ropened) {
			$rfnitem->($ropened);
			undef $ropened;
		} elsif ($rec =~ /^info1: (\w+)(?: (.*))?$/) {
			if (exists $ropened->{$1}) {	# ... except on Unix with -s -ztag
				$rfnitem->($ropened);
				undef $ropened;
			}
			$ropened->{$1} = defined $2 ? $2 : 1;
			# haveRev for backwards compatibility with SD.pm < 1.03
			# (should be workRev, if anything)
			# known users: ohome\lab\chkstat.bat
			if ($1 eq 'rev') {
				$ropened->{haveRev} = $2;
			}
		} else {
			enext $rec;
		}
	}
	sdpclose *PIPE;
	# handle any partial record
	$rfnitem->($ropened)	if defined $ropened;

	return	if @opened == 0 && $? != 0;
	return wantarray ? @opened : \@opened;
}
sub SDOpened { return nto1 SDOpenedN(@_); }


#
# SDOpenedEx[N] - Display list of files opened for pending changelist,
#                 augmented with localFile and integration source information.
#                 NOTE: SD.pm invention
#
# SDOpenedExN([\"-c $ncl",] ['file', ...])
#
#   @openedex = (
#     \%openedex1,	# as described below
#     \%openedex2,
#     ...
#   )
#
#   Return @openedex/undef on success/failure.
#
# SDOpenedEx([\"-c $ncl",] 'file')
#
#   %openedex = {
#     'depotFile' => '//depot/dev/src/code.c',
#     'localFile' => 'd:\\Office\\dev\\src\\code.c',	# always exists here
#     'haveRev'   => 4,									#  (vs. only with -l)
#     'action'    => 'edit',
#     'change'    => 12345,					# or 'default'
#     'user'      => 'MYDOMAIN\\myalias',	# optional
#     'client'    => 'MYCLIENTNAME',		# optional
#     'ourLock'   => 1,						# only exists if locked
#     'integrates' => [
#       {
#         'fromFile' => '//depot/dev/src/sourceofcode.c',
#         'how' => 'merge from' },	# or 'branch from' or 'copy from'
#         'srev' => '1',			# or 'ignored' or 'delete from'
#         'erev' => '23',
#       ...
#     ],
#     'syncs' => [
#       {
#         'fromFile' => '//depot/dev/src/code.c',		# same as depotFile
#         'how' => 'merge from' },	# or 'copy from' or 'ignored'
#         'srev' => '1',
#         'erev' => '23',
#       ...
#     ],
#   }
#
#   Return %openedex (structure described at SDOpened, augmented with subsets
#   of structure described at SDResolved)/undef on success/failure.  There can
#   be multiple resolves for integrations and syncs for each opened file.  Use
#   the presence of 'integrates' and 'syncs' sections in addition to the value
#   of the 'action' field to determine the complete(?) set of operations on
#   each opened file.
#
# See relevant SDOpenedN and SDResolvedN NOTE and FUTURE comments, and text on
# 'macro functions' at 'Implementation Notes'.
#
# FUTURE: validate that all opened-for-integrate files have matching resolves,
# because we can?  The reverse check is not necessary.  Generally, caller
# should ensure no pending resolves.
#
sub SDOpenedExN {
my $opts = shiftopts(@_);
my @files = @_;

	clearwarnerr;

	if ($opts =~ /-[au]/) {
		synthcaller "SDOpenedEx[N] cannot support \\'-a' or \\'-u' option\n";
		return;
	} elsif ($opts !~ /-l/) {
		# always use -l, but allow explicitly specifying it too.  -l provides
		# one more useful field for free, but more importantly, allows directly
		# (without needing SDWhere to convert depotFile to localFile) linking
		# records returned by SDResolved and SDOpened
		$opts = "-l $opts";
	}

	# fetch standard 'opened' info
	my $ropenedn = SDOpenedN(\$opts, @files);
	return	if ! defined $ropenedn;

	# accumulate warnings and errors from all operations
	my @sdwarningacc = @sdwarning;		my @sderroracc = @sderror;

	# suppress text and info from extra operations; use local instead of
	# ConfigSD() so original value is automatically restored on return
	local $config{echo} = $config{echo} & (echoWarning | echoError);

	# don't echo expected, harmless, warnings from extra operations
	my $echofuncSav = $config{echofunc};
	local $config{echofunc} = sub {
		$echofuncSav->(grep { $_ !~ /^No file\(s\) resolved\.$/ } @_);
	};

	# fetch standard 'resolved' info
	my $rresolvedn = SDResolvedN();		# don't restrict files; we want all

	# don't collect expected, harmless warnings; match echofunc set
	push @sdwarningacc,
			 grep { $_ !~ /^warning: No file\(s\) resolved\.$/ } @sdwarning;
	push @sderroracc, @sderror;

	goto RETURN_UNDEF	if @sderror;
	goto RETURN_OPENED	if ! defined $rresolvedn || @$rresolvedn == 0;

	# index ropenedn (will directly augment @sderror) for lookup by localFile
	clearwarnerr;
	my $ropenedni = IndexHashList($ropenedn, 'localFile');
	push @sdwarningacc, @sdwarning;		push @sderroracc, @sderror;
	goto RETURN_UNDEF	if @sderror;

	# link each integration source (from SDResolvedN) with its destination (if
	# selected by SDOpenedN)
	foreach my $rresolved (@$rresolvedn) {
		my $ropened = $ropenedni->{lc $rresolved->{toFile}};
		next	if ! defined $ropened;	# resolved set can include stuff from
										# 'outside' requested opened records
		my $key = (lc $rresolved->{fromFile} eq lc $ropened->{depotFile})
			? 'syncs'
			: 'integrates';
		push @{$ropened->{$key}},
			{ 'fromFile' => $rresolved->{fromFile},
			  'how'      => $rresolved->{how},
			  'srev'     => $rresolved->{srev},
			  'erev'     => $rresolved->{erev} };
	}

  RETURN_OPENED:
	@sdwarning = @sdwarningacc;
	@sderror = @sderroracc;
	return wantarray ? @$ropenedn : $ropenedn;

  RETURN_UNDEF:
	@sdwarning = @sdwarningacc;
	@sderror = @sderroracc;
	return;
}
sub SDOpenedEx { return nto1 SDOpenedExN(@_); }



#
# SDPrint[File][N] - Retrieve a depot file to the standard output (or file).
#
# sd print [-q] file[revRange] ...
# SDPrintN([\'-q',] 'file[revRange]'[, ...])
#
#   @print = (
#     \%print1,	# as described below
#     \%print2,
#     ...
#   )
#
#   Return @print/undef on success/failure.
#
# SDPrint('file[revRange]')
#
#   %print = {
#     'depotFile' => '//depot/dev/src/code.c',
#     'depotRev'  => 23,
#     'change'    => 12345,
#     'type'      => 'text',
#     'action'    => 'edit',
#     'text'      => ["line1", "line2" ...],  # not for SDPrintFile
#   }
#
#   Return %print/undef on success/failure.
#
# NOTE: 'text' field text does not include newlines (FUTURE: should it?)
# NOTE: when using -q flag, %print will contain only a single 'text' field,
# containing content of all files printed.  Use -q only when this effect is
# desired, and file status is not needed.  Otherwise, simply ignore the
# returned fields instead of suppressing them with -q.
# NOTE: Do not use -o flag; prefer SDPrintFile to print to a file.
# NOTE: printing non-text files will result in mangled content in 'text' field
# due to stdout text-mode conversions.  Print to a file with SDPrintFile.
# FUTURE: unmangled non-text file support with SDPrintFile to, and slurp from,
# a temporary file?
#
# sd print [-q] -o localFile file[revRange]
# SDPrintFile('localFile', 'file[revRange]')
#
#   Return %print (as for SDPrint, minus 'text')/undef on success/failure.
#
# NOTE: when using -q flag, %print can be empty despite success.  Do not use -q
# with SDPrintFile; simply ignore the returned fields instead of suppressing
# them.
#
sub SDPrintN {
my $opts = shiftopts(@_);
my @files = @_;

	clearwarnerr;

	my ($rprint, @prints);
	local *PIPE;
	sdpopen(*PIPE, "print $opts", @files) || return;
	while (my $rec = readfilt *PIPE, 'text') {
		# info: line as from sd files indicates start of record
		if ($rec =~ m!^info: (.*)#(\d+) - ([-\w]+) change (\d+) \((.*)\)$!) {
			push @prints, $rprint	if defined $rprint;
			undef $rprint;
			@{$rprint}{qw(depotFile depotRev action change type)} =
				($1, $2, $3, $4, $5);
			$rprint->{text} = [];	# ensure field exists for 0-byte files
			next;
		}

		enext $rec	if $rec !~ /^text: (.*)$/;
		push @{$rprint->{text}}, $1;
	}
	sdpclose *PIPE;
	# handle any partial record
	push @prints, $rprint	if defined $rprint;

	return	if @prints == 0 && $? != 0;
	return wantarray ? @prints : \@prints;
}
sub SDPrint     { return nto1 SDPrintN(@_); }
sub SDPrintFile {
	my $opts = '-o ' . crtquote($_[0]);
	return nto1 SDPrintN(\$opts, $_[1]);
}



#
# SDProtections[Access] - View protection information for a user.
#
# sd protections -a access -u user [-h host] [file]
# SDProtectionsAccess([\'-h host',] $acc, $user, ['file'])
#
#   @view = (
#       { 'depotSpec'  => '//depot/dev/intl/...',
#         'unmap'      => 1 },	# if access to pattern is denied
#       ...
#   )
#
#   Return @view/undef on success/failure.
#
# FUTURE: sub SDProtections for first form of sd protections command
# FUTURE: consider access a supported type, with acc* constants and sub accnorm
# to type check and normalize in place (analogous to brnnorm for branches)
#
sub SDProtectionsAccess {
my $opts = shiftopts(@_);
my $acc = crtquote shift(@_);
my $user = crtquote shift(@_);
my @files = @_;

	clearwarnerr;

	my @mappings;
	local *PIPE;
	sdpopen(*PIPE, "protections -a $acc -u $user $opts", @files) || return;
	while (my $rec = readfilt *PIPE) {
		enext $rec	if $rec !~ m!^info: ([-+])?(//.*)$!;
		my $rh = { 'depotSpec' => $2 };
		$rh->{unmap} = ($1 eq '-')	if defined $1;
		push @mappings, $rh;
	}
	sdpclose *PIPE;

	return	if @mappings == 0 && $? != 0;
	return wantarray ? @mappings : \@mappings;
}



#
# SD*Proxies - Modify list of approved proxies.
#

#
# sd proxies
# SDProxies()
#
#   Return 1/undef on success/failure.  ConfigSD(echo => echoAll)
#   recommended to provide context for any prompts.
#
sub SDProxies {
	clearwarnerr;
	my $rout = ShowForm(opt 'interactive', 'proxies');

	return	if ! defined $rout;
	return 1	if @$rout == 1 && $rout->[0] =~ /^info: Proxies (sav|not chang)ed\.$/;
	return;
}


#
# sd proxies -o
# SDGetProxies()
#
#   %proxies = (
#     'UniqueId' => 'server.service',	# for example
#     'ProxyCreds' => [
#         'DOMAIN\\machine$',
#         ...
#     ]
#   )
#
#   Return %proxies/undef on success/failure.
#
sub SDGetProxies {
	clearwarnerr;
	return ParseFormCmd('proxies -o', \&ParseNames);
}


#
# sd proxies -i < proxytable
# SDSetProxies([\]%proxies)
#
#   %proxies formatted as described at SDGetProxies.
#
#   Return 1/undef on success/failure.
#
sub SDSetProxies {
my $rproxies = rshifthash(@_);

	clearwarnerr;
	return	if ! CreateFormFile($fspec{frm}, $rproxies, \&CreateNames);

	local *PIPE;
	sdpopen(*PIPE, opt "<$fspec{frm}", "proxies -i") || return;
	my @out = readfilt *PIPE;
	sdpclose *PIPE;
	unlink $fspec{frm}	if ! $config{verbose};

	return	if $? != 0;
	return 1	if @out == 1 && $out[0] =~ /^info: Proxies (sav|not chang)ed\.$/;
	return;
}



#
# PurgeFilesN - SDPurgeBin/ObliterateN implementation.
#
# FUTURE: parse expected errors
#   /(.*) - can't purge head rev, skipping$/
#   /^Would delete (\d) integration (\d) revision .* record\(s\)\.$/
#   /^This was report mode.  Use -y to remove files\.$/
#
sub PurgeFilesN {
my $command = shift(@_);
my $opts = shiftopts(@_);
my @files = @_;

	clearwarnerr;

	my @purge;
	local *PIPE;
	sdpopen(*PIPE, "$command $opts", @files) || return;
	while (my $rec = readfilt *PIPE) {
		if ($rec =~ /^info: (.*)#(\d+) - (purged)$/) {
			push @purge, { 'depotFile' => $1, 'depotRev' => $2, 'action' => $3 };
		} elsif ($rec =~ /^info: (.*)#(\d+) - (copy from|repoint to) (.+) ([\d\.]+)$/) {
			push @purge, { 'depotFile' => $1, 'depotRev' => $2, 'action' => $3,
						   'lbrFile' => $4, 'lbrRev' => $5 };
		} else {
			enext $rec;
		}
	}
	sdpclose *PIPE;

	return	if @purge == 0 && $? != 0;
	return wantarray ? @purge : \@purge;
}


#
# SDPurgeBin[N]   - Remove binary file revisions, to reduce server disk usage.
# SDObliterate[N] - Remove files and their history from the depot.
#
# sd purgebin [-h -y -z] file[revRange] ...
# SDPurgeBinN([\'-h -y -z',] 'file[revRange]'[, ...])
#
# sd obliterate [-b branch -r -h -y -z] file ...
# SDObliterateN([\'-b branch -r -h -y -z',] 'file'[, ...])
#
#   @purge = (
#     \%purge1,	# as described below
#     \%purge2,
#     ...
#   )
#
#   Return @purge/undef on success/failure.
#
# SDPurgeBin([\'-h -y -z',] 'file[revRange]')
# SDObliterate([\'-b branch -r -h -y -z',] 'file')
#
#   %purge = {
#     'depotFile' => '//depot/dev/src/code.c',
#     'depotRev'  => 3,
#     'action'    => 'purged',	# or 'copy from' or 'repoint to'
#     'lbrFile'   => '//depot/dev/src/sourceofcode.c'	# only for 'copy from'
#     'lbrRev'    => '1.234',							#  and 'repoint to'
#   }
#
#   Return %purge/undef on success/failure.  Note that in 'copy from' and
#   'repoint to' records, depotFile and lbrFile (and corresponding Revs) can
#   refer to files not specified as input, as undoing lazy copies affects other
#   files.
#
# NOTE: 'obliterate -b branch' and '-r' options require SD server >= 3.7
#
sub SDPurgeBinN   { return      PurgeFilesN('purgebin',   @_); }
sub SDObliterateN { return      PurgeFilesN('obliterate', @_); }
sub SDPurgeBin    { return nto1 PurgeFilesN('purgebin',   @_); }
sub SDObliterate  { return nto1 PurgeFilesN('obliterate', @_); }



#
# SDReopen[N] - Change the type or changelist number of an opened file.  Keep
# in sync with OpenFilesN.
#
# sd reopen [-c changelist#] [-t type] file ...
# SDReopenN([\'-t type',] $ncl, 'file'[, ...])
#
#   @open = (
#     \%open1,	# as described below
#     \%open2,
#     ...
#   )
#
#   Return @open/undef on success/failure.
#
# SDReopen([\'-t type',] $ncl, 'file')
#
#   %open = {
#     'depotFile' => '//depot/dev/src/code.c',
#     'haveRev'   => 4
#   }
#
#   Return %open (subset of structure described at SDFstat)/undef on
#   success/failure.
#
# A changelist# is always required; specify nclDefault to use default
# changelist.
#
# FUTURE: collect change when available
# FUTURE: parse expected errors
#   /(.*) - file\(s\) not opened on this client\.$/
#
sub SDReopenN {
my $opts = shiftopts(@_);
my $ncl = shift(@_);
my @files = @_;

	clearwarnerr;
	nclnorm($ncl, 'default') || return;

	my @open;
	local *PIPE;
	sdpopen(*PIPE, "reopen -c $ncl $opts", @files) || return;
	while (my $rec = readfilt *PIPE) {
		enext $rec
			if $rec !~ /^info: (.*)#(\d+) - (nothing changed|reopened;)/;
		push @open, { 'depotFile' => $1, 'haveRev' => $2 };
	}
	sdpclose *PIPE;

	return	if @open == 0 && $? != 0;
	return wantarray ? @open : \@open;
}
sub SDReopen { return nto1 SDReopenN(@_); }



#
# ResolveFilesN - Resolve/Resolve3 implementation.
#
# FUTURE: omit partial records from return value on [s]kip and [q]uit commands
# FUTURE: support more SDAPI ISDResolveUser field names/semantics:
#   - include undo/undone field if it exists in SDAPI
#   - derive depotBase[Rev] (3-way, consider cross-branch cases)
#   - fetch depotYours[Rev] with SDHave, type with SDFiles
#   - after merge, localYours has been replaced by localMerged
#   - after merge, localBase (3-way), localTheirs no longer exist
# FUTURE: parse expected errors (SDResolveWarnings?)
#   /^(N|(.*) - n)o file\(s\) to resolve\.$/
#   /^Must resolve manually\.$/
#   /^Yours file and Theirs file both have changes; must resolve manually\.$/
#   /(.*) - resolve skipped\.$/
#
sub ResolveFilesN {
my $command = shift(@_);
my $opts = shiftopts(@_);
my @files = @_;

	clearwarnerr;

	# Get sdpopen to use sd2 for safesync.  Use local $bin{sd} instead of
	# ConfigSD(sdexe => 'foo') because local is automatically restored on scope
	# exit, which is function return if not within nested braces.
	local $bin{sd} = $bin{sd2}	if $config{safesync} && $command eq 'resolve'
								   && FEnsureSD2('resolve');

	my ($rresolve, @resolve);
	local *PIPE;
	# FUTURE: Consider being interactive iff resolving without -a* flag, if
	# all other cases can be proven non-interactive?
	sdpopen(*PIPE, opt 'interactive', "$command $opts", @files) || return;
	# REVIEW: unprefixed diff lines can look like they have prefixes (and will
	# be misconstrued) in diff styles other than default
	while (my $rec = readfilt *PIPE, 'text') {
		# fspec - merging/resolving line indicates start of record
		if ($rec =~ m!^info: (.+) - (merging|resolving)( \*undo\*)? (//.+?)(#(\d+)(,#(\d+))?)$!) {
			push @resolve, $rresolve	if defined $rresolve;
			undef $rresolve;
			@{$rresolve}{qw(depotTheirs depotTheirsRev depotTheirsRevRange localMerged)} =
				($4, (defined $8 ? $8 : $6), $5, $1);
		} elsif ($rec =~ /^info: Diff chunks: (\d+) yours \+ (\d+) theirs \+ (\d+) both \+ (\d+) conflicting$/) {
			@{$rresolve}{qw(chunksYours chunksTheirs chunksBoth chunksConflict)} =
				($1, $2, $3, $4);
		} elsif ($rec =~ /^info: Diff chunks: (\d+) between yours and theirs \(no common base\)$/) {
			$rresolve->{chunksConflict} = $1;
		} elsif ($rec =~ m!^info: (//.+) - (merge from|copy from|ignored) (//.*)$!) {
			$rresolve->{action} = $2;
			$rresolve->{action} =~ s/ from$//;
		} elsif ($rec =~ m!^info: (.+) - vs (//.+)$!) {
			next;
		} elsif ($rec =~ m!^info: (.+) - (merged|copied (theirs|yours))\.$!) {
			$rresolve->{action} = $2;	# resolve3 only messages
			$rresolve->{action} =~ s/merged$/merge/;
			$rresolve->{action} =~ s/copied/copy/;
		} elsif ($rec =~ m!^info: Yours file and Theirs file are identical\.$!) {
			next;	# binary merge only message
		} elsif ($rec =~ m!^info: (Yours|Theirs) file has no changes\.$!) {
			next;	# no changes in one or other file, no merge
		} elsif ($rec =~ m!^text: !) {
			next;	# expected to be help text from [?] command
		} else {
			enext $rec;
		}
	}
	sdpclose *PIPE;
	# END will	unlink $bin{sd2}	if -f $bin{sd2};
	# handle any partial record
	push @resolve, $rresolve	if defined $rresolve;

	return	if @resolve == 0 && $? != 0;
	return wantarray ? @resolve : \@resolve;
}


#
# SDResolve[2|3][N] - Merge open files with other revisions or files.
#
# sd resolve [-a<flag> -d<flag> -f -n -ob -ot -t -v] [file ...]
# SDResolveN([\'-a<flag> -d<flag> -f -n -ob -ot -t -v',] ['file', ...])
#
#   @resolve = (
#     \%resolve1,	# as described below
#     \%resolve2,
#     ...
#   )
#
#   Return @resolve/undef on success/failure.
#
# SDResolve([\'-a<flag> -d<flag> -f -n -ob -ot -t -v',] 'file')
#
#   %resolve = {
#     'depotTheirs'    => '//depot/dev/src/code.c',	# NOTE: SDAPI includes #rev
#     'depotTheirsRev' => 6,						# in depotTheirs
#     'depotTheirsRevRange' => '#4,#6',				# NOTE: experimental
#     'localMerged'    => 'd:\\Office\\dev\\src\\code.c',
#     'chunksYours'    => 4,
#     'chunksTheirs'   => 3,						# chunks* only exist for
#     'chunksBoth'     => 0,						# 3-way text merges
#     'chunksConflict' => 1,
#     'action'         => 'merge',					# or 'copy' or 'ignored'
#   }												# or not defined if skipped
#
#   Return %resolve/undef on success/failure.  ConfigSD(echo => echoAll)
#   recommended to provide context for any prompts.
#
# SDResolve2([\'-a<flag> -d<flag> -t -v',] 'theirs', 'yours', 'merged')
# SDResolve3([\'-a<flag> -d<flag> -t -v',] 'base', 'theirs', 'yours', 'merged')
#
#   %resolve = {
#     'chunksYours'    => 4,						# chunks* only exist for
#     'chunksTheirs'   => 3,						# 3-way text merges;
#     'chunksBoth'     => 0,						# chunksConflict for 2-way
#     'chunksConflict' => 1,						# text merges
#     'action'         => 'merge',					# or 'copy theirs' or 'copy
#   }												# yours' or not defined if
#													# skipped/aborted
#
#   Return %resolve/undef on success/failure.  ConfigSD(echo => echoAll)
#   recommended to provide context for any prompts.  Prefer SDResolve3Ex over
#   SDResolve[2|3] to allow detecting errors in all cases.
#
#   REVIEW: sd.exe resolve3 with -at/-ay flags prints nothing to collect and
#   parse, so ResolveFilesN returns empty list even on success.  nto1 then
#   loses distinction between undef and empty list, so caller cannot detect
#   errors.  Port SDResolve3Ex workaround to ResolveFilesN?
#
# Check SDWarning() and SDError() as well as return value for details:
# - ! defined return  (true failure or SDResolve[2|3] with no-output -at/-ay)
# - SDError() contains 'Resolve aborted.'  (user quit)
# - SDWarning() contains '<file> - resolve skipped.'  (user skip)
# - $return->{action}  (true success)
#
# NOTE: no SDResolve2N or SDResolve3N -- resolve3 only ever handles one merge
#
sub SDResolveN  { return      ResolveFilesN('resolve',     @_); }
sub SDResolve   { return nto1 ResolveFilesN('resolve',     @_); }
sub SDResolve2  { return nto1 ResolveFilesN('resolve3 -2', @_); }
sub SDResolve3  { return nto1 ResolveFilesN('resolve3',    @_); }


#
# autoopt - Return effective -a? option (without the option delimiter '-') for
# an sd resolve option string.  Note that -an is returned as empty string,
# reflecting default (and more common) usage.
#
# FUTURE: accurate handling of bad options (e.g. legacy -ai appears to be
# equivalent to -an, unknown -ax appears to be equvalent to -am)
#
sub autoopt {
	my ($auto) = $_[0] =~ /-(a[nmfsty]?)/;	# first wins, matching SD
	$auto = '' if ! defined $auto || $auto eq 'an';
	return $auto;
}


#
# synthfcerror - syntherror for failed _f_ile (typically open) operations in
# the style of sd _c_lient output (including Win32-level error text).  Specify
# attempted operation and filenames (which will be expanded to full fspecs).
# synthfcerror will fetch Win32-level GetLastError value for inclusion in
# output.  As this value can change if additional operations are attempted
# before calling synthfcerror, you may fetch the error value yourself and
# specify your cached value with an optional initial reference argument to
# synthfcerror.  To avoid confusion with real sd client output, include package
# name in output.  Note: Win32::GetFullPathName requires perl $] >= 5.006.
#
# FUTURE: sd.exe doesn't expand to full fspecs; why should we?  Why not let
# caller do so when appropriate?
# FUTURE: Is $^E suitable replacement for Win32::GetLastError/FormatMessage?
# One difference: $^E does not include message-ending period, whereas
# FormatMessage does.
#
sub synthfcerror {
my $err = shiftopts(@_);
my($op, @files) = @_;

	$err = Win32::GetLastError()	if $err eq '';
	$err = Win32::FormatMessage($err);
	foreach my $file (@files) {
		$file = Win32::GetFullPathName($file);
	}
	my $files = join ', ', @files;
	syntherror \-1, "Source Depot client error:\n",
					"\t" . __PACKAGE__ . ".pm: $op: $files: $err\n";
}


#
# DeleteFile - Delete a file, with sd client-style error reporting.  Return
# 'file no longer exists'.
#
# FUTURE: write access is not truly equivalent to delete access; whole test is
# somewhat sleazy hack.  Opportunistically use DeleteFile through
# Win32API::File?
#
sub DeleteFile {
my($file) = @_;

	my $err;

	if (! -e $file) {				# easy early out
		return 1;
	} elsif (-f $file && -w $file) {# unchecked unlink won't respect read-only
		if (unlink $file) {
			return 1;
		} else {
			$err = Win32::GetLastError();	# prefer over $! to mimic SD
		}
	} else {						# exists but not a file, or not writeable
		local *FILE;					# try writing to get error.  Expect
		open(FILE, ">> $file");			# Win32-level failure.  Append (and
		$err = Win32::GetLastError();	# close) to avoid damage in unlikely
		close FILE;						# case open does succeed.
	}

	# $err set by failed unlink or (probably failed) open
	synthfcerror \$err, 'open for write', $file;
	return;
}


# farhs is bitmask if available.  fdoneattrapis ensures we try getting bitmask
# only once.
use vars qw($fdoneattrapis $farhs);


#
# getattrapis - Emulate use Win32::File at runtime if available (so there's no
# hard dependency on that module).  Return bitmask for read-only, hidden and
# system bits (admittedly specialized value needed by CopyFile), or undef if
# not available.
#
sub getattrapis {
	my $farhs;
	local $SIG{__DIE__};	# prevent __DIE__ being called during eval
	if (eval { require Win32::File }) {
		eval { import Win32::File qw(:DEFAULT GetAttributes SetAttributes) };
		eval "\$farhs = READONLY | HIDDEN | SYSTEM";
	}
	return $farhs;
}


#
# CopyFile - Copy a file, with sd client-style error reporting and sd resolve3-
# style handling of attributes (read-only, hidden and system cleared).  Return
# 'file was copied'.  Note: Win32::CopyFile requires perl $] >= 5.006.
#
sub CopyFile {
my($from, $to) = @_;

	if (! Win32::CopyFile($from, $to, 1)) {	# fOverwrite
		synthfcerror 'file copy', $from, $to;
		return;
	}

	if (! $fdoneattrapis) {
		$farhs = getattrapis;
		$fdoneattrapis = 1;
	}
	if (defined $farhs) {
		my $fa;
		if (GetAttributes($to, $fa) && $fa & $farhs) {
			$fa &= ~$farhs;
			SetAttributes($to, $fa);
		}
		return 1;
	}

	chmod 0777, $to;	# best effort to at least clear read-only attribute
	return 1;
}


#
# CompareFiles - Compare two binary files.  Return 0 if files are identical,
# 1 if file contents differ and -1 on error.
#
sub CompareFiles {
my($file1, $file2) = @_;

	# early out based on file size
	my $size1 = -s $file1;
	if (! defined $size1) {
		synthfcerror 'file stat', $file1;
		return -1;
	}
	my $size2 = -s $file2;
	if (! defined $size2) {
		synthfcerror 'file stat', $file2;
		return -1;
	}

	return 1 if $size1 != $size2;

	# compare actual file contents
	local *FILE1;
	if (! open(FILE1, $file1)) {
		synthfcerror 'open for read', $file1;
		return -1;
	}
	local *FILE2;
	if (! open(FILE2, $file2)) {
		synthfcerror 'open for read', $file2;
		close FILE1;
		return -1;
	}
	binmode(FILE1);
	binmode(FILE2);

	my $ret;
	my ($data1, $len1, $data2, $len2);
	while (! defined $ret) {
		$len1 = sysread FILE1, $data1, 16384;	# 16K is arbitrary
		$len2 = sysread FILE2, $data2, 16384;
		if (! defined $len1) {
			synthfcerror 'file read', $file1;
			$ret = -1;	# error
		} elsif (! defined $len2) {
			synthfcerror 'file read', $file2;
			$ret = -1;	# error
		} elsif ($data1 ne $data2) {	# $len1 ne $len2 tested implicitly
			$ret = 1;	# different
		} elsif ($len1 == 0) {	# $len1 == $len2 implied by $data1 eq $data2
			$ret = 0;	# same
		} # else same so far
	}

	close FILE1;
	close FILE2;
	return $ret;
}


#
# Resolve2BaseHelp - Help text for Resolve2Base h/? command.  Keep in sync with
# Resolve2Base behaviour.  Text is output using synthtext, but not preserved in
# return values (mimicing readfilt-called-from-ResolveFiles handling of text:
# SD output).  Note: negative split limits require perl $] > 5.002.
#
sub Resolve2BaseHelp {
my($fhaveTheirs) = @_;

	my ($thelp, $yhelp) = $fhaveTheirs
		? ('', ' (i.e. delete wins)')
		: (' (i.e. delete wins)', '');

	synthtext map { "$_\n" } split /\n/, <<EOT, -1;
Two-way resolve options:

    Accept:
            at              Keep their file${thelp}.
            ay              Keep your file${yhelp}.

    Misc:
            s               Skip this file.
            h               Print this help message.
            q               Quit the resolve operation.
EOT
}


#
# Resolve2Base - Implement resolve2-style interview for two-file cases
# involving base file and one of theirs and yours files.  Such cases involve no
# line-level merging, only file selection.  Hence, options and help here mimic
# sd resolve3 -2 (SDResolve2) binary resolve case.
#
# Output uses synth* except for prompts which are unconditionally echoed (as in
# readfilt).  Input is from stdin (matching sdpopen *PIPE, \'interactive' in
# ResolveFiles) and case-sensitive (like SD) but does not ignore extra trailing
# characters (unlike SD).
#
# Return %resolve/undef on success/failure.  See notes at SDResolveN concerning
# use of ConfigSD(), SDWarning() and SDError() for full details.  On successful
# resolve, %resolve contains only 'action' field.  Unlike SDResolve2, %resolve
# will not be empty on success when using -at/-ay flags.
#
# FUTURE: support d (diff) and et/ey (edit) subcommands
# FUTURE: consider "This overrides your changes: confirm accept (y/n)? " for
# followup to 'at' response?
# FUTURE: -axxx means -am to SD, not -a; perhaps incompatibility for undefined
# behaviours is OK
#
sub Resolve2Base {
my $opts = shiftopts(@_);
my($base, $have, $merged, $fhaveTheirs) = @_;

	clearwarnerr;

	# For Resolve2Base to extend resolve2, recognized options must match those
	# known to resolve2: -a<flag> (automatic mode), -d<flag> (diff format), -t
	# (force textual line-level merge) and -v (force change markers for all
	# diffs).  -d cannot apply here because diffing is not supported.  -t and
	# -v do not apply here, and various -a variants become synonymous, because
	# there is no line-level merging.

	# See sd help resolve for details on regular resolve flag definitions for
	# comparison with the semantics mapped to.  Here, 'merge' applies when base
	# and have are the same file (i.e. ! $fdiffer).  The third, missing, file
	# is considered to be the only one changed and 'wins' in automatic merges.
	# 'conflict' applies when base and have are not the same file (i.e.
	# $fdiffer).  Both have and the third, missing, file are considered to be
	# changed, and there is no winner; manual resolution is needed.

	#  flag         merge      conflict
	#  ----         -----      --------
	#  none/-an     prompt     prompt     default behaviour
	#  -a           automatic  prompt
	#  -as/-am/-af  automatic  skip       differences are line-level and N/A
	#  -at          automatic  automatic  selecting theirs
	#  -ay          automatic  automatic  selecting yours

	my $auto = autoopt($opts);			# essentially, first wins
	$auto = 'as' if $auto =~ /a[mf]/;	# equivalent only in this context

	# Determine messages, default, and automatic response based on available
	# files and (when not completely determined by 'absolute' 'at' or 'ay'
	# command line flag), whether they differ
	#  warning/info messages: describe file relationships whenever not using
	#    'absolute' command line flags
	#  default: offer [x] at prompts; suggestion matches -as behaviour
	#  auto: convert command line flag to interactive response (applicable to
	#    'a' and 'as' cases with differing behaviour for merge and conflict;
	#    '', 'at' and 'ay' are unchanged)

	# compare files only if acceptance behaviour not pre-determined; otherwise,
	# arbitrarily consider them different since it doesn't matter
	my $fdiffer = $auto =~ /a[ty]/ || CompareFiles($base, $have);
	return	if $fdiffer < 0;	# compare error

	my ($cfile, $dfile) = $fhaveTheirs
		? ('Theirs', 'Yours')
		: ('Yours', 'Theirs');
	my $default;

	if ($fdiffer) {		# conflict
		synthwarning \-1,
		  "$cfile file has changes and $dfile file has been deleted; must resolve manually.\n"
			if $auto !~ /a[ty]/;
		$default = 's';
		if ($auto eq 'a') {
			$auto = '';	# prompt
		} elsif ($auto eq 'as') {
			$auto = 's';
		}
	} else {			# merge
		synthinfo "$cfile file has no changes and $dfile file has been deleted.\n"
			if $auto !~ /a[ty]/;
		$default = $fhaveTheirs ? 'ay' : 'at';
		if ($auto eq 'a' || $auto eq 'as') {
			$auto = $default;
		}
	}

	synthwarning \-1, "Deleted file resolve.\n"		if $auto !~ /a[ty]/;

	my $rresolve;

	while (1) {
		my $in;
		if ($auto eq '') {
			synthprompt "Accept (at/ay) Skip (s) Help (?) [$default]: ";
			$in = readline *STDIN;
			goto EOF	if ! defined $in;	# handle ^Z
			chomp $in;
			$in = $default	if $in eq '';
		} else {
			$in = $auto;	# all auto values guaranteed not to loop
		}

		# switch on $in and do stuff
		if ($in eq 'at') {
			if ($fhaveTheirs) {
				if (CopyFile($have, $merged)) {
					$rresolve = { action => 'copy theirs' };
				}
			} else {	# have yours -> theirs == undef -> merged to be deleted
				if (DeleteFile($merged)) {
					$rresolve = { action => 'delete' };
				}
			}
			last;
		} elsif ($in eq 'ay') {
			if ($fhaveTheirs) {	# -> yours == undef -> merged to be deleted
				if (DeleteFile($merged)) {
					$rresolve = { action => 'delete' };
				}
			} else {	# have yours
				if (CopyFile($have, $merged)) {
					$rresolve = { action => 'copy yours' };
				}
			}
			last;
		} elsif ($in eq 's') {
			synthwarning "$merged - resolve skipped.\n";
			unlink $merged;		# mimic SD
			last;
		} elsif ($in eq 'q') {
		  EOF:
			syntherror \-1, "Resolve aborted.\n";
			syntherror \-1, "EOF reading terminal.\n"	if ! defined $in;
			unlink $merged;		# mimic SD
			last;
		} elsif ($in eq 'h' or $in eq '?') {
			Resolve2BaseHelp($fhaveTheirs);
		} else {
			syntherror "Unknown flag.  Try ? for help.\n";
		}
		# FUTURE: assert $auto eq '';
	}

	return	if ! defined $rresolve;
	return wantarray ? %$rresolve : $rresolve;
}


#
# SDResolve3Ex - Merge any subset of base/theirs/yours files, performing
#                file (existence/non-existence), revision (contents same/
#                different) and line level merging.  NOTE: SD.pm invention
#
# SDResolve3Ex([\'-a<flag> -d<flag> -t -v',] 'base','theirs','yours','merged')
#
#   %resolve formatted as described at SDResolveN.
#
#   Return %resolve/undef on success/failure.  See notes at SDResolve[2|3][N]
#   concerning use of ConfigSD(), SDWarning() and SDError() for full details.
#   Unlike SDResolve2/3, %resolve will not be undef on success when using
#   -at/-ay flags.
#
# Unify the behaviour of resolve3, resolve2 and integrate -d for deleted files
# with a single resolve3-style interview for all cases.  Specify values for
# base, theirs, yours and merged files as for resolve3.  Specify undef for any
# input file to indicate a missing file (i.e. to consider the deletion of that
# file as a change to be resolved).  merged contains results of resolve.
# Any existing output (merged) file will be clobbered.  A missing merged file
# indicates either an early exit (skip or quit entered at resolve prompt), or
# a successful merge, the result of which is a deleted file.
#
# See sd help resolve3, resolve and integrate (especially the -d and -i flags)
# for more background.
#
# FUTURE: consider setting action => 'SKIP'/'ABORT' as appropriate, eliminating
# need for caller to check SDWarning()/SDError() for specific text.
# FUTURE: when inferring action, CompareFiles to be certain?
# FUTURE: analogous mechanism for resolving filetypes (compare with integrate
# -t and -tf)
#
sub SDResolve3Ex {
my $opts = shiftopts(@_);
my($base, $theirs, $yours, $merged) = @_;

	clearwarnerr;

	# merged must be defined; file existence handled by resolve handlers
	# ([SD]Resolve[23][Base]) and inline Copy/DeleteFile below
	if (! defined $merged) {
		synthcaller "merged file must be specified\n";
		return;
	}

	my $rresolve;

	# consider all combinations of present/absent input files, by number of
	# present files
	# - 3 of 3
	if (defined $base && defined $theirs && defined $yours) {
		my $auto = autoopt($opts);
		unlink $merged	if $auto =~ /a[ty]/; # ensure -f sees SDResolve3 effect
		$rresolve = SDResolve3(\$opts, $base, $theirs, $yours, $merged);
		if (! defined $rresolve && $auto =~ /a[ty]/ && -f $merged) {
			# infer action; there was no output to collect and parse
			my $file = $auto eq 'at' ? 'theirs' : 'yours';
			$rresolve = { action => "copy $file" };
		}
	}

	# - any 2 of 3
	# for cases not covered by sd resolve2 (i.e. when one of the two files is
	# the base file), emulate a resolve interview.  SD handles this at
	# integrate time with sd integrate -d.
	elsif (defined $theirs && defined $yours) {
		my $auto = autoopt($opts);
		unlink $merged	if $auto =~ /a[ty]/; # ensure -f sees SDResolve2 effect
		$rresolve = SDResolve2(\$opts, $theirs, $yours, $merged);
		if (! defined $rresolve && $auto =~ /a[ty]/ && -f $merged) {
			# infer action; there was no output to collect and parse
			my $file = $auto eq 'at' ? 'theirs' : 'yours';
			$rresolve = { action => "copy $file" };
		}
	} elsif (defined $base && defined $theirs) {
		return Resolve2Base(\$opts, $base, $theirs, $merged, 1); # fhaveTheirs
	} elsif (defined $base && defined $yours) {
		return Resolve2Base(\$opts, $base, $yours, $merged, 0); # ! fhaveTheirs
	}														# (i.e. have yours)

	# - any 1 of 3
	# base file only suggests keeping theirs (or equivalently yours); either of
	# yours and theirs suggests keeping the one that exists
	# FUTURE: is interview appropriate?  Would need to consider autoopt($opts).
	elsif (defined $base) {	# yours == theirs == undef -> merged to be deleted
		if (DeleteFile($merged)) {
			$rresolve = { action => 'delete' };
		}
	} elsif (defined $theirs) {
		if (CopyFile($theirs, $merged)) {
			$rresolve = { action => 'copy theirs' };
		}
	} elsif (defined $yours) {
		if (CopyFile($yours, $merged)) {
			$rresolve = { action => 'copy yours' };
		}
	}

	# - 0 of 3
	else {	# base == yours == theirs == undef -> merged to be deleted
		if (DeleteFile($merged)) {
			$rresolve = { action => 'delete' };
		}
	}

	return	if ! defined $rresolve;
	return wantarray ? %$rresolve : $rresolve;
}


#
# SDResolved[N] - Show files that have been merged but not submitted.
#
# sd resolved [file[revRange] ...]
# SDResolvedN(['file[revRange]', ...])
#
#   @resolved = (
#     \%resolved1,	# as described below
#     \%resolved2,
#     ...
#   )
#
#   Return @resolved/undef on success/failure.
#
# SDResolved('file[revRange]')
#
#   %resolved = {
#     'toFile'    => 'd:\\Office\\dev\\src\\copyofcode.c',
#     'fromFile'  => '//depot/dev/src/code.c',
#     'how'       => 'merge from',	# or 'branch from' or 'copy from'
#     'srev'      => 1,				# or 'ignored' or 'delete from'
#     'erev'      => 23,
#   }
#
#   Return %resolved (subset of structure described at SDIntegrate)/undef on
#   success/failure.
#
# FUTURE: parse expected errors
#   /^(N|(.*) - n)o file\(s\) resolved\.$/
#
sub SDResolvedN {
my @files = @_;

	clearwarnerr;

	my ($rresolved, @resolved);
	local *PIPE;
	sdpopen(*PIPE, opt 'ztag', "resolved", @files) || return;
	while (my $rec = readfilt *PIPE) {
		# empty line indicates end of record ...
		if ($rec =~ /^info:\s*$/ && defined $rresolved) {
			push @resolved, $rresolved;
			undef $rresolved;
		} elsif ($rec =~ /^info1: (\w+)(?: (.*))?$/) {
			if (defined $rresolved->{$1}) {	# ... except on Unix with -s -ztag
				push @resolved, $rresolved;
				undef $rresolved;
			}
			$rresolved->{$1} = defined $2 ? $2 : 1;
		} else {
			enext $rec;
		}
	}
	sdpclose *PIPE;
	# handle any partial record
	push @resolved, $rresolved	if defined $rresolved;

	return	if @resolved == 0 && $? != 0;
	return wantarray ? @resolved : \@resolved;
}
sub SDResolved { return nto1 SDResolvedN(@_); }



#
# SDRevert[N] - Discard changes from an opened file.
#
# sd revert [-a -c changelist# -d -f -n] file ...
# SDRevertN([\"-a -c $ncl -d -f -n",] 'file'[, ...])
#
#   @revert = (
#     \%revert1,	# as described below
#     \%revert2,
#     ...
#   )
#
#   Return @revert/undef on success/failure.
#
# SDRevert([\"-a -c $ncl -d -f -n",] 'file')
#
#   %revert = {
#     'depotFile' => '//depot/dev/src/code.c',
#     'haveRev'   => 4,
#     'action'    => 'edit'
#   }
#
#   Return %revert (subset of structure described at SDFstat)/undef on
#   success/failure.
#
# NOTE: '-d', '-n' options require SD server, client >= 2.7
# FUTURE: return lock and revert type status?
# FUTURE: parse expected errors
#   /(.*) - file\(s\) not opened on this client\.$/
#
sub SDRevertN {
my $opts = shiftopts(@_);
my @files = @_;

	clearwarnerr;

	my @revert;
	local *PIPE;
	sdpopen(*PIPE, "revert $opts", @files) || return;
	while (my $rec = readfilt *PIPE) {
		enext $rec
			if $rec !~ /^info: (.*)#(\d+|none|virtual) - was (.*),( unlocked and)? (abandoned|reverted|cleared)$/;
		push @revert, { 'depotFile' => $1, 'haveRev' => $2, 'action' => $3 };
	}
	sdpclose *PIPE;

	return	if @revert == 0 && $? != 0;
	return wantarray ? @revert : \@revert;
}
sub SDRevert { return nto1 SDRevertN(@_); }



#
# SDReview - List and track changelists (for the review daemon).
#
# sd review [-c changelist#] [-t counter]
# SDReview([\'-c ncl -t counter'])
#
#   @reviews = (
#     \%review1,  # as described below
#     \%review2,
#     ...
#   )
#
#   %review = (
#     'Change'      => 12345,
#     'User'        => 'MYDOMAIN\\myalias',
#     'Email'       => 'myalias',       # default 'MYDOMAIN\\myalias@machine'
#     'FullName'    => 'My Real Name',  # default 'MYDOMAIN\\myalias'
#   )
#
#   Return @reviews/undef on success/failure.
#
sub SDReview {
my $opts = shiftopts(@_);

	clearwarnerr;

	my @reviews;
	local *PIPE;
	sdpopen(*PIPE, "review $opts") || return;
	while (my $rec = readfilt *PIPE) {
		enext $rec	if $rec !~ m!^info: Change (\d+) ($redu) <(.*)> \((.*)\)$!;
		push @reviews, { 'Change' => $1, 'User' => $2, 'Email' => $3,
						 'FullName' => $4 };
	}
	sdpclose *PIPE;

	return	if @reviews == 0 && $? != 0;
	return wantarray ? @reviews : \@reviews;
}


#
# SDReviews - Show what users are subscribed to review files.
#
# sd reviews [-c changelist#] [file ...]
# SDReviews([\'-c ncl'], ['file', ...])
#
#   @reviews = (
#     \%review1,	# subset of structure described at SDReview
#     \%review2,
#     ...
#   )
#
#   Return @reviews/undef on success/failure.
#
sub SDReviews {
my $opts = shiftopts(@_);
my @files = @_;

	clearwarnerr;

	my @reviews;
	local *PIPE;
	sdpopen(*PIPE, "reviews $opts", @files) || return;
	while (my $rec = readfilt *PIPE) {
		enext $rec	if $rec !~ m!^info: ($redu) <(.*)> \((.*)\)$!;
		push @reviews, { 'User' => $1, 'Email' => $2, 'FullName' => $3 };
	}
	sdpclose *PIPE;

	return	if @reviews == 0 && $? != 0;
	return wantarray ? @reviews : \@reviews;
}



#
# SDSubmit - Submit open files to the depot
#
# submit [-u user [-l client]] [-i|-c changelist#|-C description] [-D] [file]
#
# SDSubmit([\'[-u user [-l client]] [-i|-c changelist#|-C description] [-D]',]
#          ['file'])
#
#   Returns the change number that was successfully submitted on success.
#   Returns undef on error (meaning that the change was not submitted).
#   On error, call SDSubmitError() and/or SDSubmitWarning() to get more
#   details.
#
# NOTE: '-D' option requires SD server >= 3.7
# FUTURE: for symmetry with SDEdit and utility, require a changelist argument,
# perhaps as a separate sub
#
sub SDSubmit {
my $opts = shiftopts(@_);
my @files = @_;

	clearwarnerr;
	my $fvalid = 1;
	my $change;

	local *PIPE;
	# REVIEW: PIPE should be \'interactive' for 'Hit return to continue...'
	# message (like all potentially interactive form handlers) but sd submit
	# output is proportional to number of files in changelist, so character-
	# oriented reading may become unreasonably slow.  Consider being
	# interactive iff submitting from default changelist, if all other cases
	# can be proven non-interactive?
	sdpopen(*PIPE, "submit $opts", @files) || return;
	while (my $rec = readfilt *PIPE) {
		next if $rec =~ /^info: Change \d+ created with \d+ open file(s)?.\s*$/;
		next if $rec =~ /^info: Locking \d+ file(s)? \.\.\.\s*$/;
		next if $rec =~ m!^info: [-\w]+ //.*#\d+\s*!;
		next if $rec =~ /^info: Submitting change (.*)\.\s*$/;
		next if $rec =~ /^info: .*#\d+ - refreshing$/;
		if (!defined($change)
		    && ($rec =~ /^info: Change (\d+) submitted\.\s*$/
		        || $rec =~ /^info: Change \d+ renamed change (\d+) and submitted\.\s*$/)) {
			$change = $1;
			next;
		}
		$fvalid = 0;
		enext $rec;
	}
	sdpclose *PIPE;

	return	if ! $fvalid || ! defined $change;
	return $change;
}


#
# SDSubmitError - Parse error text from SDSubmit.
#
# @error = SDError(\'-s');
# SDSubmitError(@error);
#   or
# SDSubmitError();    # SDError(\'-s') as argument implied
#
#   \%error = {
#     'Description' => "text description of the error",
#     'Change' => 23,	# from SDSubmit error text (may not be defined)
#   }
#
#   Return %error/undef on success/failure.
#
sub SDSubmitError {
my(@error) = @_;

	@error = @sderror	if ! @error;
	clearwarnerr;

	my $fvalid = 1;
	my %error;
	foreach my $rec (@error) {
		$error{Description} = ''	if ! exists $error{Description};
		$error{Description} .= $rec;
		next if $rec =~ /^error: Out of date files must be resolved or reverted\.\s*$/;
		next if $rec =~ /^error: Merges still pending -- use 'sd resolve' to merge files\.\s*$/;
		if ($rec =~ /^error: Submit failed -- fix problems above then use 'sd submit -c (\d+)'\.\s*$/) {
			$error{Change} = $1;
			next;
		}
		next if $rec =~ /^error: No files to submit from the default changelist\.\s*$/;
		next if $rec =~ /^error: Change (\d+) unknown\.\s*$/;
		next if $rec =~ /^error: Client side operations?\(s\) failed.  Command aborted\.\s*$/;
		$fvalid = 0;
		enext $rec;
	}

	return	if ! $fvalid;
	return wantarray ? %error : \%error;
}


#
# SDSubmitWarning - Parse warning text from SDSubmit.
#
# @warning = SDWarning(\'-s');
# SDSubmitWarning(@warning);
#   or
# SDSubmitWarning();    # SDWarning(\'-s') as argument implied
#
#   \%warning = {
#     'Description' => "text description of the error",
#     'Changes' => [
#         'pendingchangenumber1',
#         'pendingchangenumber2',
#         ...
#     ],
#     'Files' => [
#         'resolvefile1',
#         'resolvefile2',
#         ...
#     ],
#   }
#
#   Return %warning/undef on success/failure.
#
sub SDSubmitWarning {
my(@warning) = @_;

	@warning = @sdwarning	if ! @warning;
	clearwarnerr;

	my $fvalid = 1;
	my %warning;
	foreach my $rec (@warning) {
		$warning{Description} = ''	if ! exists $warning{Description};
		$warning{Description} .= $rec;
		if ($rec =~ /^warning: Use 'sd submit -c (\d+)' to submit file\(s\) in pending change (\d+)\.\s*$/) {
			enext $rec if $1 != $2;
			push @{$warning{Changes}}, $1;
			next;
		}
		if ($rec =~ m!^warning: (//.*) - must resolve before submitting\s*$!
		    || $rec =~ m!^warning1: (//.*) - must resolve (\#\d+,?)+\s*$!
		    || $rec =~ m!^warning: .* - must resolve (//.*)\#\d+\s*$!) {
			push @{$warning{Files}}, $1 if ! inlist($1, @{$warning{Files}});
			next;
		}
		$fvalid = 0;
		enext $rec;
	}

	return	if ! $fvalid;
	return wantarray ? %warning : \%warning;
}



#
# [Branch]SyncN - SDBranchSync/Sync/BranchFlush/FlushN implementation.
#
sub BranchSyncN {
my $command = shift(@_);
my $opts = shiftopts(@_);
my $brn = shift(@_);
my @filerevs = @_;

	clearwarnerr;
	brnnorm($brn, '') || return;

	# Get sdpopen to use sd2 for safesync.  Use local $bin{sd} instead of
	# ConfigSD(sdexe => 'foo') because local is automatically restored on scope
	# exit, which is function return if not within nested braces.
	local $bin{sd} = $bin{sd2}	if $config{safesync} && FEnsureSD2('sync');

	my @sync;

	my $rfnitem = defined $config{itemfunc}		? $config{itemfunc}
				: defined wantarray				? sub { push @sync, @_ }
				:								  sub {};

	local *PIPE;
	sdpopen(*PIPE, "$command $brn $opts", @filerevs) || return;
	while (my $rec = readfilt *PIPE) {
		if ($rec =~ /^info: (.*)#(\d+) - (updating|refreshing|replacing|deleted as|added as) (.*)$/) {
			my $rh = { 'depotFile' => $1, 'haveRev' => $2,
					   'action' => $3, 'localFile' => $4 };
			$rh->{action} =~ s/ as$//;
			$rfnitem->($rh);
		} elsif ($rec =~ /^info: (.*)#(\d+) - /) {
			$rfnitem->( { 'depotFile' => $1, 'haveRev' => $2 } );
		} else {
			enext $rec;
		}
	}
	sdpclose *PIPE;
	# END will	unlink $bin{sd2}	if -f $bin{sd2};

	return	if @sync == 0 && $? != 0;
	return wantarray ? @sync : \@sync;
}

sub SyncN {
my $command = shift(@_);
my $opts = shiftopts(@_);

	# insert brnDefault into argument list
	unshift @_, brnDefault;
	unshift @_, \$opts	if $opts ne '';
	unshift @_, $command;
	return BranchSyncN(@_);
}

#
# SD[Branch]Sync[N] - Synchronize the client with its view of the depot.
# SD[Branch]Flush[N] - Fake an 'sd sync' by not moving files.
#
# sd sync [-f -n -i -w] [file[revRange] ...]
# SDSyncN([\'-f -n -i -w',] ['file[revRange]', ...])
#
# sd flush [-f -n -i -w] [file[revRange] ...]
# SDFlushN([\'-f -n -i -w',] ['file[revRange]', ...])
#
# sd sync -b branch [-f -n -i -r -w] [file[revRange] ...]
# SDBranchSyncN([\'-f -n -i -r -w',] $brn, ['file[revRange]', ...])
#
# sd flush -b branch [-f -n -i -r -w] [file[revRange] ...]
# SDBranchFlushN([\'-f -n -i -r -w',] $brn, ['file[revRange]', ...])
#
#   @sync = (
#     \%sync1,	# as described below
#     \%sync2,
#     ...
#   )
#
#   Return @sync/undef on success/failure.
#
# SDSync([\'-f -n -i -w',] 'file[revRange]')
# SDFlush([\'-f -n -i -w',] 'file[revRange]')
# SDBranchSync([\'-f -n -i -r -w',] $brn, 'file[revRange]')
# SDBranchFlush([\'-f -n -i -r -w',] $brn, 'file[revRange]')
#
#   %sync = (
#     'depotFile' => '//depot/dev/src/code.c',
#     'localFile' => 'd:\\Office\\dev\\src\\code.c',	# not always available
#     'action'    => 'updating'	# or 'added' or 'deleted' or unavailable
#     'haveRev'   => 4
#   )
#
#   Return %sync/undef on success/failure.
#
# NOTE: '-w' option requires SD server, client >= 2.7
# FUTURE: parse expected errors
#   /^(F|(.*) - f)ile\(s\) up-to-date\.$/
#   /(.*) - no such file\(s\)\.$/
#   /(.*) - must resolve #\d+(,#\d+)? before submitting\.$/
#
sub SDSyncN        { return      SyncN('sync',  @_);       }
sub SDFlushN       { return      SyncN('flush', @_);       }
sub SDBranchSyncN  { return      BranchSyncN('sync',  @_); }
sub SDBranchFlushN { return      BranchSyncN('flush', @_); }
sub SDSync         { return nto1 SyncN('sync',  @_);       }
sub SDFlush        { return nto1 SyncN('flush', @_);       }
sub SDBranchSync   { return nto1 BranchSyncN('sync',  @_); }
sub SDBranchFlush  { return nto1 BranchSyncN('flush', @_); }



#
# SD*TypeMap - Modify the file name-to-type mapping table.
#

#
# sd typemap
# SDTypeMap()
#
#   Return 1/undef on success/failure.  ConfigSD(echo => echoAll)
#   recommended to provide context for any prompts.
#
sub SDTypeMap {
	clearwarnerr;
	my $rout = ShowForm(opt 'interactive', 'typemap');

	return	if ! defined $rout;
	return 1	if @$rout == 1 && $rout->[0] =~ /^info: Typemap (sav|not chang)ed\.$/;
	return;
}


#
# sd typemap -o
# SDGetTypeMap()
#
#   @typemap = (
#       { 'Filetype'  => 'text',	# or 'unicode' or 'binary' or 'none'
#         'Path'      => '//depot/*/src/*.ext' },
#       ...
#   )
#
#   Return %typemap/undef on success/failure.
#
sub SDGetTypeMap {
	clearwarnerr;
	return ParseFormCmd('typemap -o', \&ParseTypeMap);
}


#
# sd typemap -i < typemaptable
# SDSetTypeMap([\]%typemap)
#
#   %typemap formatted as described at SDGetTypeMap.
#
#   Return 1/undef on success/failure.
#
sub SDSetTypeMap {
my $rtypemap = rshifthash(@_);

	clearwarnerr;
	return	if ! CreateFormFile($fspec{frm}, $rtypemap, \&CreateTypeMap);

	local *PIPE;
	sdpopen(*PIPE, opt "<$fspec{frm}", "typemap -i") || return;
	my @out = readfilt *PIPE;
	sdpclose *PIPE;
	unlink $fspec{frm}	if ! $config{verbose};

	return	if $? != 0;
	return 1	if @out == 1 && $out[0] =~ /^info: Typemap (sav|not chang)ed\.$/;
	return;
}



#
# SDUnlock[N] - Release a locked file but leave open.
#
# sd unlock [-c changelist# -f] [file ...]
# SDUnlockN([\"-c $ncl -f",] ['file', ...])
#
#   @unlocked = (
#     \%unlocked1,	# as described below
#     \%unlocked2,
#     ...
#   )
#
#   Return @unlocked/undef on success/failure.
#
# SDUnlock([\"-c $ncl -f",] 'file')
#
#   %unlocked = {
#     'depotFile' => '//depot/dev/src/code.c',
#     'action'    => 'unlocking',	# or 'already unlocked'
#   }
#
#   Return %unlocked/undef on success/failure.
#
sub SDUnlockN {
my $opts = shiftopts(@_);
my @files = @_;

	clearwarnerr;

	my @unlocked;
	local *PIPE;
	sdpopen(*PIPE, "unlock $opts", @files) || return;
	while (my $rec = readfilt *PIPE) {
		enext $rec
			if $rec !~ m!^info: (.*) - (unlocking|already unlocked)$!;
		push @unlocked, { 'depotFile' => $1, 'action' => $2 };
	}
	sdpclose *PIPE;

	return	if @unlocked == 0 && $? != 0;
	return wantarray ? @unlocked : \@unlocked;
}
sub SDUnlock { return nto1 SDUnlockN(@_); }



#
# SD*User - Create or edit a user specification.
#

#
# sd user [-f] [name]
# SDUser([\'-f',] ['name'])
#
#   Return 1/undef on success/failure.  ConfigSD(echo => echoAll)
#   recommended to provide context for any prompts.
#
sub SDUser {
my $opts = shiftopts(@_);
my($name) = @_;

	clearwarnerr;
	my $rout = ShowForm(opt 'interactive', "user $opts", $name);

	return	if ! defined $rout;
	return $1	if @$rout == 1 && $rout->[0] =~ /^info: User (.+) (sav|not chang)ed\.$/;
	return;
}


#
# sd user -o [name]
# SDGetUser(['name'])
#
#   %user = (
#     'User'        => 'MYDOMAIN\\myalias',
#     'Email'       => 'myalias',       # default 'MYDOMAIN\\myalias@machine'
#     'Update'      => '2004/02/06 00:02:36',
#     'Access'      => '2004/02/06 00:03:58',
#     'FullName'    => 'My Real Name',  # default 'MYDOMAIN\\myalias'
#     'Password'    => '******',
#     'Reviews' => [
#       { 'depotSpec'  => '//depot/dev/...' },
#       ...
#     ]
#   )
#
#   Return %user/undef on success/failure.
#
# FUTURE: parse JobView info further
#
sub SDGetUser {
my $name = crtquote(@_);

	clearwarnerr;
	return ParseFormCmd("user -o -- $name", \&ParseView);
}


#
# sd user -i [-f] < userfspec
# SDSetUser([\'-f',] [\]%user)
#
#   %user formatted as described at SDGetUser.
#
#   Return name/undef on success/failure.
#
sub SDSetUser {
my $opts = shiftopts(@_);
my $ruser = rshifthash(@_);

	clearwarnerr;
	return	if ! CreateFormFile($fspec{frm}, $ruser, \&CreateView);

	local *PIPE;
	sdpopen(*PIPE, opt "<$fspec{frm}", "user -i $opts") || return;
	my @out = readfilt *PIPE;
	sdpclose *PIPE;
	unlink $fspec{frm}	if ! $config{verbose};

	return	if $? != 0;
	return $1	if @out == 1 && $out[0] =~ /^info: User (.+) (sav|not chang)ed\.$/;
	return;
}


#
# sd user -d [-f] name
# SDDelUser([\'-f',] 'name')
#
#   Return name/undef on success/failure.
#
sub SDDelUser {
my $opts = shiftopts(@_);
my($name) = @_;

	clearwarnerr;

	local *PIPE;
	sdpopen(*PIPE, "user -d $opts", $name) || return;
	my @out = readfilt *PIPE;
	sdpclose *PIPE;

	return	if $? != 0;
	return $1	if @out == 1 && $out[0] =~ /^info: User (.*) deleted\.$/;
	return;
}


#
# SDUsers - Display list of known users.
#
# sd users [-d date -p] [user ...]
# SDUsersN([\'-d date -p',] ['user', ...])
#
#   @users = (
#     \%user1,	# as described below
#     \%user2,
#     ...
#   )
#
#   Return @users/undef on success/failure.
#
# SDUsers([\'-d date -p',] 'user')
#
#   %user = (
#     'User'        => 'MYDOMAIN\\myalias',
#     'Email'       => 'myalias',       # default 'MYDOMAIN\\myalias@machine'
#     'FullName'    => 'My Real Name',  # default 'MYDOMAIN\\myalias'
#     'Access'      => '2001/05/07 09:25:24',
#     'Password'    => 'NTSECURITY',    # or '******', but only if using -p
#   )
#
#   Return %user/undef on success/failure.
#
# FUTURE: SDUsersN is a mistake; should only be SDUsers (with SDUsersN
# semantics) to match SDBranches/Changes/Clients patterns.
#
sub SDUsersN {
my $opts = shiftopts(@_);
my @inusers = @_;

	clearwarnerr;

	my @users;
	local *PIPE;
	sdpopen(*PIPE, "users $opts", @inusers) || return;
	while (my $rec = readfilt *PIPE) {
		enext $rec	if $rec !~ m!^info: ($redu) <(.*)> \((.*)\) accessed ($redatime)( (NTSECURITY|\*+))?$!;
		my $rh = { 'User' => $1, 'Email' => $2, 'FullName' => $3,
				   'Access' => $4 };
		$rh->{Password} = $6	if defined $6;
		push @users, $rh;
	}
	sdpclose *PIPE;

	return	if @users == 0 && $? != 0;
	return wantarray ? @users : \@users;
}
sub SDUsers { return nto1 SDUsersN(@_); }



#
# SDVerify[N] -- Verify that the server archives are intact.
#
# sd verify [-q -l -r -u -v -m] file[revRange] ...
# SDVerifyN([\'-q -l -r -u -v -m',] 'file[revRange]'[, ...])
#
#   @files = (
#     \%file1,	# as described below
#     \%file2,
#     ...
#   )
#
#   Return @files/undef on success/failure.
#
# SDVerify([\'-q -l -r -u -v -m',] 'file[revRange]')
#
#   %file = (
#     'depotFile' => '//depot/dev/src/code.c',
#     'depotRev'  => 3,
#     'action'    => 'edit',
#     'change'    => 33,
#     'type'      => 'text',
#   )
#
#   Return %file/undef on success/failure.
#
# WITH $VERSION 2.60 hash FIELD IS MORE ACCURATELY RENAMED AS hashCalc, WITH A
# NEW hash FIELD REFLECTING DB STORED HASH AVAILABLE IN SD 3.6.
# FUTURE: share implementation with SDFilesN?
# FUTURE: BAD! and MISSING! output is only in warnings, so will never be parsed
# into @files.  Treat warnings as info here?
#
sub SDVerifyN {
my $opts = shiftopts(@_);
my @infiles = @_;

	clearwarnerr;

	my @files;
	local *PIPE;
	sdpopen(*PIPE, "verify $opts", @infiles) || return;
	while (my $rec = readfilt *PIPE) {
		enext $rec	if $rec !~ m/^info: (.*)#(\d+) - ([-\w]+) change (\d+) \((.*)\)(?: ([\dA-F]+))? ([\dA-F]+)(?: (OK|BAD!|MISSING!))?$/;
		my $rh = { depotFile => $1, depotRev => $2, action   => $3,
				   change    => $4, type     => $5, hashCalc => $7 };
		$rh->{hash}   = $6 	if defined $6;
		$rh->{status} = $8 	if defined $8;
		push @files, $rh;
	}
	sdpclose *PIPE;

	return	if @files == 0 && $? != 0;
	return wantarray ? @files : \@files;
}
sub SDVerify { return nto1 SDVerifyN(@_); }



#
# SDWhere[N] - Show how file names map through the client view.
#
# sd where [file ...]
# SDWhereN(['file', ...])
#
#   @files = (
#     \%file1,	# as described below
#     \%file2,
#     ...
#   )
#
#   Return @files/undef on success/failure.
#
# SDWhere('file')
#
#   %file = (
#     'depotFile'  => '//depot/dev/src/code.c',
#     'clientFile' => '//CLIENT/dev/src/code.c',
#     'localFile'  => 'd:\\Office\\dev\\src\\code.c',
#     'unmap'      => 1		# if file is not mapped
#     # deprecated fields (enabled on request)
#     'path'       => $file{localFile}
#   )
#
#   Return %file (super/subset of structure described at SDFstat)/undef on
#   success/failure.  File represents selective mapping if it exists, or
#   exclusionary mapping if not.
#
# NOTE: In SD.pm, the name localFile is substituted for path, used in sd.exe.
# NOTE: sd where //depot/root doesn't work as expected, and trailing slashes
# cause grief too.
#
sub SDWhereN {
my @infiles = @_;

	clearwarnerr;

	my ($rfile, @files);
	local *PIPE;
	sdpopen(*PIPE, "where -Ttag", @infiles) || return;
	while (my $rec = readfilt *PIPE) {
		# empty line indicates end of record
		if ($rec =~ /^info:\s*$/ && defined $rfile) {
			push @files, $rfile;
			undef $rfile;
			next;
		}

		enext $rec	if $rec !~ /^info1: (\w+)/;
		next if $1 eq 'tag';
		if ($1 eq 'unmap') {
			$rfile->{$1} = 1;
			next;
		}
		enext $rec	if $rec !~ /^info1: (\w+) (.+)$/;
		if ($1 eq 'path') {
			$rfile->{localFile} = $2;
			next;
		}
		$rfile->{$1} = $2;
	}
	sdpclose *PIPE;
	# handle any partial record
	push @files, $rfile		if defined $rfile;

	return	if @files == 0 && $? != 0;
	return wantarray ? @files : \@files;
}
sub SDWhere {
	# SD returns all mappings; all but last are typically marked as unmap, so
	# final one is usually applicable.  Hence, remove extras and return only
	# the last.  NOTE: '+' mappings in client can result in multiple relevant
	# non-unmap mappings, at least one of which will be discarded by SDWhere.
	# NOTE: while stripping mappings, we cannot detect inappropriate usage,
	# unlike other SDFoo (no 'N') subs.  Consider SDWhere mildly deprecated,
	# and prefer SDWhereN with explicit handling of all returned mappings.
	my $ref = SDWhereN(@_);
	return	if ! defined $ref;
	return	if @$ref == 0;
	my @ary = ($ref->[-1]);	# lose all but last
	return nto1 \@ary;
}



#
# SDRun - Run an arbitrary SD command.
#
# sd command [-opts] [arg ...]
# SDRun('command', [\'-opts',] ['arg', ...])
#
#   Return @out/undef on success/failure.
#
# FUTURE: support sdpopenopts?
#
sub SDRun {
my $command = shift(@_);
my $opts = shiftopts(@_);
my @args = @_;

	clearwarnerr;

	local *PIPE;
	sdpopen(*PIPE, "$command $opts", @args) || return;
	my @out = readfilt *PIPE;
	sdpclose *PIPE;

	return	if @out == 0 && $? != 0;
	return wantarray ? @out : \@out;
}



#
# DoSet - SDSet/AdminSet implementation.
#
sub DoSet {
my $command = shift(@_);

	clearwarnerr;

	my %set;
	local *PIPE;
	sdpopen(*PIPE, $command) || return;
	while (my $rec = readfilt *PIPE, 'info') {
		next if $rec =~ /^info: (\[.*\])?$/;
		enext $rec	if $rec !~ /^info: (.*?)=(.*) \((.+)\)$/;
		$set{"\U$1\E"} = $2;
		$set{"\U$1\E_type"} = $3;
	}
	sdpclose *PIPE;

	return	if keys %set == 0 && $? != 0;
	return wantarray ? %set : \%set;
}


#
# SD[Admin]Set - Set variables in the registry, or, more commonly, retrieve
# variables from the environment/.ini file/registry.  EXPERIMENTAL INTERFACE
# MAY CHANGE.
#
# sd set [-s -S service] [var[=[value]] ...]
# SDSet()
#
# sd admin set [var[=[value]] ...]
# SDAdminSet()
#
#   %set = (
#     'SDVAR1'      => 'sdvalue1',
#     'SDVAR1_type' => 'set',		# (i.e. registry) or 'config' (i.e. ini
#     'SDVAR2'      => 'sdvalue2',	#  file) or 'environment'
#     'SDVAR2_type' => 'config',
#     ...
#   )
#
#   Return %set/undef on success/failure.
#
# NOTE: Returned value does not reflect settings in %config.
# NOTE: In SD.pm, variable names are guaranteed to be upper-case; in sd.exe
# user case is preserved.
# NOTE: SDSet is called indirectly from eprint in all SD*, from SDDiff and from
# SDGetEffective
#
# FUTURE: support setting variables? with a hash (reference)?
# FUTURE: split getting and setting into SDGet and SDSet?
#
sub SDSet      { return DoSet('set',       @_); }
sub SDAdminSet { return DoSet('admin set', @_); }
sub _SDSet     { return internal(\&SDSet,  @_); }



#
# SDAdminStatus[N] - Show status of connections to the server.  EXPERIMENTAL
# INTERFACE MAY CHANGE.
#
# sd admin status [-abcdehpqrD -m count -K kernelms -U userms] [id ...]
# SDAdminStatusN([\'-abcdehprD -m count -K kernelms -U userms',] [id, ...])
#
#   @status = (
#     \%status1,	# as described below
#     \%status2,
#     ...
#   )
#
#   Return @status/undef on success/failure.
#
# SDAdminStatus([\'-abcdehprD -m count -K kernelms -U userms',] id)
#
#   %status = (
#     'id'        => 123456,
#     'state'     => 'active'				# or 'dbwait' or 'completed'
#     'user'      => 'MYDOMAIN\\myalias',
#     'client'    => 'MYCLIENTNAME',
#     'machine'   => 'MYMACHINE',
#     'startTime' => 1122334455,			# seconds since epoch
#     'duration'  => 42,					# in milliseconds
#     'kernelCPU' => 10,					# in milliseconds
#     'userCPU'   => 15,					# in milliseconds
#     ...									# more fields depending on options
#   )
#
#   Return %status/undef on success/failure.
#
# NOTE: -q flag is meaningless here as header line is never returned in
# @status; there is no harm (but no point) in using -q with SDAdminStatus.
#
# FUTURE: return -r global (i.e. non-per-thread) output in @status
# FUTURE: Field names and format are currently raw -ztag=1 values.  Return
# time values as human-readable strings and index database references by name,
# at least?
#
sub SDAdminStatusN {
my $opts = shiftopts(@_);
my @ids = @_;

	clearwarnerr;

	my ($rstatus, @status);
	local *PIPE;
	sdpopen(*PIPE, opt 'ztag', "admin status $opts", @ids) || return;
	while (my $rec = readfilt *PIPE) {
		# empty line indicates end of record ...
		if ($rec =~ /^info:\s*$/ && defined $rstatus) {
			push @status, $rstatus;
			undef $rstatus;
		} elsif ($rec =~ /^info1: (\w+)(?: (.*))?$/) {
			if (defined $rstatus->{$1}) {	# ... except on Unix with -s -ztag
				push @status, $rstatus;
				undef $rstatus;
			}
			$rstatus->{$1} = defined $2 ? $2 : 1;
		} elsif ($rec =~ /^info: (.*?): /) {
			next;	# lose global memory pressure info
		} else {
			enext $rec;
		}
	}
	sdpclose *PIPE;
	# handle any partial record
	push @status, $rstatus	if defined $rstatus;

	return	if @status == 0 && $? != 0;
	return wantarray ? @status : \@status;
}
sub SDAdminStatus { return nto1 SDAdminStatusN(@_); }



#
# Non-standard exports - 'extra-value' operations that do not correspond
# directly to SD commands.
#

#
# specnorm - Normalize depot- (or client-) syntax mapping specification rspec.
# If rspec is a reference, normalize referenced spec in place.  Regardless,
# return normalized mapping spec.
#
# THIS FUNCTION IS DEPRECATED.  DO NOT USE IN NEW CODE.  Really, it just
# does some arbitrary munging of perfectly good depotspecs.
#
sub specnorm {
my($rspec) = @_;

	my $spec = ref $rspec ? $$rspec : $rspec;

	$spec = "/$spec/";					# so ends aren't special
	$spec =~ s!\.{4,}!...!;				# ., .. caught by sd client, more, here
	$spec =~ s!([^/])\.\.\.!$1/...!g; 	# ensure preceding /
	$spec =~ s!\.\.\.([^/])!.../$1!g;	# ensure following /
	$spec =~ s!^/(.*)/$!$1!;			# remove temporary ends we added

	$$rspec = $spec		if ref $rspec;
	return $spec;
}



#
# splitspec - Separate @rev or #rev revision(-range) specifier from a
# depot-syntax string, returning the file portion.  In list context, return
# both parts.  Empty file portion is returned as empty string; lack of revision
# specifier is returned as undef.  EXPERIMENTAL INTERFACE MAY CHANGE.
#
# (spec|view)* subs generally do not permit arguments to include revision
# specifiers, so splitspec may be useful to trim them from data that may
# initially include them.  Be sure to provide scalar context to avoid
# adding the revision specifier as an unwanted argument:
#     if (specmatch(scalar splitspec($userstring), $specpat)) { ... }
#
sub splitspec {
my($specstr) = @_;

	$specstr =~ s/([@#].*$)//;
	return wantarray ? ($specstr, $1) : $specstr;
}


#
# specstr - Convert depot-syntax string to perl string suitable for use as left
# argument to =~ when matching depotSpecs.  See specmatch below for details.
#
sub specstr ($) {
my($specstr) = @_;

	if ($specstr =~ /[@#]/) {
		synthcaller "specstr must not contain revision specifiers\n";
		return;
	}

	# munge specstr to have canonical single character wildcard metacharacters
	# for easier matching:
	#    *, %n  ->  $star
	#    ...    ->  $dots
	# compare with specpat's mpwildpat table (no table here for simplicity)
	$specstr =~ s/(\*|%\d)/$star/g;
	$specstr =~ s/\.\.\./$dots/g;

	return $specstr;
}


#
# unspecstr - Undo specstr encoding.  As %d wildcards lose their identity when
# encoded by specstr, these will be restored here as simple * wildcards.
#
sub unspecstr ($) {
my($specstr) = @_;

	$specstr =~ s/$dots/.../go;
	$specstr =~ s/$star/*/go;
	return $specstr;
}


#
# specopt - Optimize specstr (i.e. return value from call to sub specstr) to
# remove redundant wildcards.  E.g.:
#    ***        -> *
#    ......*... -> ...
# For use in specific circumstances (specpatint) only; it's generally bad form
# to 'helpfully' but unnecessarily modify user data.
#
# FUTURE: consider aspects (if faster) of:
#    $specstr =~ tr/\xff/\xff/s; # can't use $star; tr doesn't interpolate
#    $specstr =~ s/[$star$dots][$star$dots]+/$dots/og; # xx+ better than x{2,}?
#
sub specopt ($) {
my($specstr) = @_;

	# first pattern ensures no two adjacent stars; second squeezes runs of two
	# or more wildcards, which due to first must contain at least one instance
	# of dots, to a single instance of dots
	1 while $specstr =~ s/$star{2,}/$star/o || $specstr =~ s/[$star$dots]{2,}/$dots/o;

	return $specstr;
}


#
# quotesdmeta - Escape SD metacharacters in specpat.  Like quotemeta, applicable
# to user data before use as a pattern.
#
sub quotesdmeta {
my($specpat) = @_;

	$specpat =~ s/(\*|%\d|\.\.\.|:)/$esc$1/g;
	return $specpat;
}


use vars qw(%mpwildpat %mppatwild);
%mpwildpat = (						# map SD wildcard to internal code/pattern
	'*'		=> $mstar,	# also '%n'
	'...'	=> $mdots,
	':*'	=> $star,	# also ':%n'
	':...'	=> $dots,
	'::'	=> $esc,
	# other	=> quotemeta self, 		# including :anything-but-:/*/...
);
%mppatwild = reverse %mpwildpat;	# map regex to SD wildcard (%n lost)

$mpwildpat{":%$_"} = $mpwildpat{':*'}	foreach (1..9);	# :%n aliases :*
$mpwildpat{ "%$_"} = $mpwildpat{ '*'}	foreach (1..9);	#  %n aliases  *


#
# specpat - Convert depot-syntax string to perl regex suitable for use as
# right argument to =~ when matching depotSpecs.  See specmatch below for
# details.
#
# FUTURE: populate tables on first use?
#
sub specpat ($) {
my($specpat) = @_;

	if ($specpat =~ /[@#]/) {
		synthcaller "specpat must not contain revision specifiers\n";
		return;
	}

	# 1 - translate wildcards to regex equivalents, literal wildcards to
	#     canonical single metacharacters, and quotemeta the rest.  Translation
	#     pattern is optimized to find more common tokens first, but final
	#     component (matching \W[^*%.:]*) must be last, even though likely most
	#     common, to not take precedence over more specific preceding terms.
	#     Avoid unnecessary quotemeta calls, but once one is needed, pass it as
	#     many characters as possible.
	$specpat =~ s/(\*|%\d|\.\.\.|:(?:\*|%\d|\.\.\.|:)|\W[^*%.:]*)/$mpwildpat{$1} || quotemeta($1)/ge;

	# 2 - make pattern match only complete string, case insensitively
	$specpat = qr/^$specpat$/i;

	return $specpat;
}


#
# unspecpat - Undo specpat encoding.
#
sub unspecpat ($) {
my($specpat) = @_;

	# restore specpat regex to string (numbered steps correspond with specpat)
	# 2 - remove string anchors and /x modifiers expressed as (?i-xsm:^stuff$)
	$specpat =~ s/\$[^\$]*$//;
	$specpat =~ s/^.*?\^//;

	# 1 - unquotemeta, restore literal wildcards with escape characters and
	#     translate regexes to SD wildcards.  Order of components is roughly
	#     reverse of specpat.  \\. can safely be first as it does not take
	#     precedence over any more specific following terms.
	$specpat =~ s/(\\.|$star|$dots|$esc|\Q$mstar\E|\Q$mdots\E)/$mppatwild{$1} || substr($1, 1)/geo;

	return $specpat;
}


#
# specmatch - Return 'specstr matches specpat'.  Both specstr and specpat must
# be in depot syntax.  Neither spec may contain @/# revision specifiers.  Both
# specs may contain */%n/... wildcards; specpat almost always will.  specpat
# only may contain escaped or non-counting (preceded by :) wildcards to be
# considered as literal text -- :* and :... . :%n is indistinguishable from :*
# -- either will match %n or * in specstr.  :: indicates a literal : in cases
# where a single : would otherwise escape * or ... .  An escaped wildcard
# indicates that specstr must contain exactly that wildcard and not just
# arbitrary characters; * is to :* as .* is to \.\* in perl.  Do not consider :
# as a general escape character; behaviour approximates escaping within perl
# single quotes, affecting only a handful of sequences.  : preceding any other
# characters or sequences of characters has no special behaviour.
#
# If specstr does not contain wildcards, the meaning of 'match' is the intuitive
# one -- does the set of possible files specified by specpat include specstr?
#
# If specstr does contain wildcards, 'match' means 'does specpat include every
# possible file that specstr includes?'.  Note that specpat may describe
# additional files.  I.e. specstr matches specpat if specpat describes a
# superset of the files specstr describes.
#
# In list context, return value is a list containing components of specstr as
# matched by wildcards in specpat (or the empty list indicating there was no
# match).
#
# Note escaped wildcard support is currently non-uniform across subs:
#
#   API family                 arguments           supported escapes
#   ---------                  --------            ----------------
#   specpat/specmatch          specpat             :*  :...  ::
#   specpatrep/specsubst       specpat specrep     :*  :...
#   viewpatrep/viewsubst       rview               :*  :...
#   specpatint/specintersect   <none>              <none>
#
#
# For better performance when matching with many specstrs and/or many specpats
# it is worth caching compiled forms of spec args and then inlining the actual
# match.  Cache the values as you see fit, emulating the basic behaviour of
# specmatch below:
# - clearwarnerr if you expect to check failures in subsequent steps with
#   SDError/SDWarning.
# - cache $specstr = specstr '//spec/str' for strings to be matched.  If you
#   can guarantee the strings will contain no */%n/... wildcards, there is no
#   need to call specstr.
# - cache $specpat = specpat '//spec/pat/...' for strings to be matched
#   against.
# - perform the actual match with $specstr =~ $specpat, using your cached
#   values, instead of calling specmatch
# - if match is performed in list context (i.e. you care about what each
#   specpat wildcard matched) and specstr may contain wildcards, apply
#   unspecstr to each element of the result list
#
#
# FUTURE: consider \es
# FUTURE: validate arguments are defined? fully-qualified (i.e. =~ m!^//!)?
# FUTURE: additional function that accepts multiple match specs or perhaps a
# full view
# FUTURE: enhanced syntax that allows wildcards not yet known to SD? (easy
# case: ? for any single character, not including /)
#
sub specmatch {
my($specstr, $specpat) = @_;

	clearwarnerr;

	# convert from depot syntax to canonical literal and regex, respectively
	$specstr = specstr $specstr;
	$specpat = specpat $specpat;

	return	if ! defined $specstr || ! defined $specpat;

	# finally, match as a regex
	if (wantarray) {
		my @ret = $specstr =~ $specpat;
		return map { unspecstr $_ } @ret;
	} else {
		return $specstr =~ $specpat;
	}
}


#
# specpatint - Convert depot-syntax string to function reference suitable for
# use in comparing specstrs (provided later) for intersection with the specpat
# specified.  See specintersect below for details on usage.
#
sub specpatint ($) {
my($specpat) = @_;

	if ($specpat =~ /[@#]/) {
		synthcaller "specpat must not contain revision specifiers\n";
		return;
	}

	# 'Compile' specpat into a simple, traditional NFA.  Later, execute the NFA
	# for provided specstrs to match them.  Reproducing this basic perl regex
	# support allows inserting extra behaviour to specially handle wildcard
	# characters in specstrs, changing the meaning of 'matching' to desired
	# 'intersection' (matching at least one of the set represented by specstr).
	#
	# Because SD wildcards are few and simple (both * and ... are simple
	# variants of traditional regex .*), translation from specpat to NFA is
	# straightforward.  Each token (single literal character including slash,
	# asterisk wildcard or ellipsis wildcard) in specpat has a corresponding
	# state node in the NFA representing 'have consumed at least one input
	# token matching me'.  Each literal state is entered for the only time when
	# its defining token character is consumed.  Each wildcard state is entered
	# for the first time when one of the token characters it can match is
	# consumed.  Because wildcards can (and usually do) match multiple
	# characters, wildcard states can be re-entered (looping to themselves) on
	# subsequent characters.  Because wildcards can also match zero tokens,
	# wildcard states may be bypassed by token characters matching the state
	# following the wildcard.  For example:
	#
	#   $specpat eq '/d/.../*'     becomes:
	#                                             /\ any              /\ no/
	#                                            |  |                |  |
	#                                            v /                 v /
	#   .sss.     .---.     .---.     .---.     .---.     .fff.     .---.
	#   |   |---->| / |---->| d |---->| / |---->|...|---->| / |---->| * |
	#   `---'  /  `---'  d  `---'  /  `---' any `---'  /  `---' no/ `fff'
	#                                   |                   ^
	#                                    \__________________/
	#                                             /
	#     0         1         2         3         4         5         6
	#
	# where:
	#  sss - represents the start state.  Like any other node, the start node
	#        may have two edges leaving it if the next node (i.e. the first
	#        from specpat) is a wildcard.
	#  fff - represents final/accepting states.  If any of these states are
	#        active at end of input specstr, the NFA accepts specstr as
	#        matching.
	#  no/ - any character but slash
	#  any - any character including slash
	#
	# This diagram is represented as a hash (%nfa) mapping each state:input to
	# its successor state.  $nfa{n:sym} represents what state to transition to
	# from state n on symbol (or set of symbols) sym.  If no hash entry exists
	# for a state:input pair, that transition is illegal.  The example above
	# is encoded as:
	#
	#     $nfa{0:/}   == 1     $nfa{3:any} == 4     $nfa{4:/}   == 5
	#     $nfa{1:d}   == 2     $nfa{3:/}   == 5     $nfa{5:no/} == 6
	#     $nfa{2:/}   == 3     $nfa{4:any} == 4     $nfa{6:no/} == 6
	#
	# Actual state names (i.e. tokens they represent) are kept in @pat, a
	# simple expansion of $specpat into an array of characters, used both to
	# construct %nfa and at interpret time.
	#
	# We construct %nfa from left to right, generating transition edges leaving
	# each state by looking forward at the next state, and if wild, the state
	# after that.  As * and ... are very similar (differing only in acceptance
	# of /), the only interesting construct is that at state 4.  A * at that
	# position instead of ... would generate the identical edges, except that
	# the 'any' transitions would be 'no/'.  The * node at state 6 illustrates
	# that transition edges for nodes 'off the end' are simply dropped.  If
	# there were a state 7, edges from 5 and 6 to it would look much like those
	# from 3 and 4 to 5.
	#
	# An important implicit assumption is that there are no adjacent wildcards
	# in specpat.  If adjacent wildcards were permitted, constructions could
	# become more complex (e.g. if state 5 were a wildcard, there would be need
	# for additional edges from 3 to 6 and 4 to 6 at least).  Fortunately,
	# all combinations of adjacent SD wildcards are redundant and can be
	# optimized away (** -> *, ...... and ...* -> ...) before NFA construction
	# begins.  If, in future, SD gains more powerful wildcards, adjacency may
	# become meaningful and this assumption will need to be revisited (likely
	# resulting in 'if's becoming 'while's below).
	#
	# Final states are the last literal node (which must be matched) and all
	# trailing wildcard nodes (which may match zero characters and so don't
	# exclude preceding nodes).  Because of the non-adjacent-wildcards
	# assumption, there can be at most one trailing wildcard node and hence,
	# exactly one or two final states.  The extreme case of an empty specpat
	# generates a correct NFA, which we choose to consider as not intersecting
	# with anything by deeming state 0 to never be an acceptable final state.
	# As specstr and specpat are symmetric, this implies that the empty specstr
	# also does not intersect with any specpat.
	#
	# Use of the set representations 'any' and 'no/' conveniently results in
	# no more than one transition per input token class, keeping the values in
	# %nfa simple scalars.  E.g. A slash in state 3 can take us to both states
	# 4 and 5, but these need not both be encoded on $nfa{3:/} as $nfa{3:any}
	# takes care of one of them.  Different representations (perhaps due to
	# future SD wildcard enhancements) may require the values of %nfa to be
	# lists of next states.  For these set representations to be useful, the
	# interpreter must be aware of their meanings, and look for 'any' and 'no/'
	# transitions whenever processing tokens whose values are in those sets.
	#
	# The interpreter basically iterates over input tokens following allowable
	# state transitions in %nfa (and considering 'any' and 'no/' as described
	# above).  If that was all it did, we would have replicated a small piece
	# of native perl regular expression support.  The purpose of all this is to
	# allow adding additional logic for handling wildcards in the input string
	# being matched, and to be able to return interesting state from the match.
	# See comment near the interpreter for more details.
	#
	# The division of work between compile and interpret time is somewhat
	# arbitrary.  The meanings of 'any' and 'no/' could be encoded directly in
	# %nfa so that the interpreter would not need to be aware of them.  This
	# would cost extra compile time and storage space, with the benefit of
	# simpler and faster interpret time.  Also, the transitions to take when
	# wildcards are encountered in specstr could be pre-compiled into %nfa
	# instead of determined at interpret time, with similar tradeoffs.  The
	# current division seems a good compromise, with relatively small storage
	# required, a traditional NFA representation and the 'interesting stuff'
	# all in the interpreter.
	#
	# FUTURE: consider moving 'any' and 'no/' transitions to %nfa as well as
	# transitions for '*' and '...'.  As discussed, this would increase compile
	# time and space usage, at the benefit of faster interpret time.
	# FUTURE: store @pat and @finalstates in %nfa to make it a self-contained,
	# exportable representation?
	# FUTURE: consider multi-character literal states: rename no/ and any to be
	# out of band, tokenize specpat into alternating literal sequences and
	# wildcards instead of individual characters... and then things get hard in
	# the interpreter at *1*


	# optimize redundant wildcards and tokenize pattern (easier to index chars
	# as array)
	my @pat = split //, specopt specstr $specpat;
	unshift @pat, '';						# prepend start state

	# encode state machine as transition edges for each possible input token
	local $; = ':';	# subscript separator for emulated multi-dimensional arrays
	my %nfa;

	for (my $state = 0; $state < @pat; $state++) {

		# loop back to this node if it's a wildcard
		$nfa{$state, 'no/'} = $state	if $pat[$state] eq $star;
		$nfa{$state, 'any'} = $state	if $pat[$state] eq $dots;

		# transition to next node if there is one
		if ($state + 1 < @pat) {
			my $fstar = $pat[$state + 1] eq $star;
			my $fdots = $pat[$state + 1] eq $dots;

			if ($fstar || $fdots) {	# wild
				$nfa{$state, 'no/'} = $state + 1	if $fstar;
				$nfa{$state, 'any'} = $state + 1	if $fdots;

				# transition to next next node (past wildcard) if there is one
				if ($state + 2 < @pat) {
					# non-redundant specpat guarantees this one isn't wild
					$nfa{$state, $pat[$state + 2]} = $state + 2;
				}

			} else { # tame
				$nfa{$state, $pat[$state + 1]} = $state + 1;
			}
		}
	}
	###my @p; push @p, unspecstr($_) for @pat; print "pat == !", join('!', @p), "!\n";###
	###print "\$nfa{$_} == $nfa{$_}\n" for sort { my ($x) = $a =~ /(\d+)/; my ($y) = $b =~ /(\d+)/; $x <=> $y } keys %nfa;###

	# final states are those from last literal (which must be matched) through
	# trailing wildcards (which are satisfied with no tokens).  Non-redundant
	# specpat guarantees at most one consecutive wildcard, hence, only need to
	# examine last two states.
	my @finalstates = ($#pat);
	unshift @finalstates, $#pat-1	if $pat[-1] eq $star || $pat[-1] eq $dots;

	# choose to consider empty input/machine as non-accepting
	@finalstates = ()	if $finalstates[0] < 1;
	###print "final states == @finalstates\n\n";###

	# create closure that actually compares specstrs (provided at call time)
	# for intersection by running NFA
	my $fnint = sub {
		my($specstr, $fxwild) = @_;

		# 'Interpret' the NFA.  With the start state as initial set of states,
		# iterate over input tokens, generating a new set of states -- all
		# those reachable from the current set on the current token.
		#
		# REASON #1 FOR EXISTENCE OF THIS MECHANISM: A ... token in specstr
		# represents infinitely many strings of arbitrary composition.  In
		# particular, it represents sequences of tokens to reach any succeeding
		# (higher-numbered) state.  Hence, consider ... as having encountered
		# all of those strings and aim to add all following states to the next
		# state set.  To ensure that all states >= n are added to the next
		# state set, copy the current state n, and add states > n up to but not
		# including m, the next highest state found in the current state set.
		# m and beyond are handled on m's own iteration in current state set.
		# Among the represented strings is the empty (no token) string.  With
		# no token, there is no transition, justifying the copy of the current
		# state to the next state set.
		#
		# REASON #2 FOR EXISTENCE OF THIS MECHANISM: A * token in specstr
		# represents infinitely many strings not containing any slash.  In
		# particular, it represents sequences of tokens to reach any succeeding
		# state not requiring a slash token.  Add states as in the ... case,
		# but additionally, stop before the next literal slash state.
		#
		# REASON #3 FOR EXISTENCE OF THIS MECHANISM: With each transition,
		# augment a minimal string to reach this state, considering the
		# intersection of the set of characters represented by the token and
		# the set of allowable characters to reach the state.
		#
		# For all other tokens, in a given state, consider the transition on
		# that token as well as the 'any' set (for all tokens) and the 'no/'
		# set (for all tokens but slash).
		#
		# There is no need for an early termination test; when the set of
		# states becomes empty (which ultimately means no match) iterating over
		# subsequent tokens does no work and quickly ends with the set of
		# states still empty.
		#
		# FUTURE: adding sort at *1* would guarantee determinism; prove order
		# here has no impact on return string.  Different selection policies at
		# *2* would result in different return strings.  Prove a) that current
		# selection policy is best single string b) there's no need to remember
		# sets of all strings to reach each state to find a correct string
		# (keeping in mind that no single string may be sufficient).
		# FUTURE: ponder correctness of wildcard placeholders in returned
		# string if fxwild.  Make it default when sure.  Ponder need for
		# specstr call in final state test.

		local $; = ':';		# match subscript separator used at NFA create time

		# keys are set of current states, values are canonical input string to
		# reach corresponding states.  Start state is always the one
		# represented by '' prepended to @pat.
		my %states = (0, $pat[0]);

		###print "input  == ", unspecstr $specstr, "\n";###
		foreach my $token (split //, $specstr) {
			###print "states == ", join(' ', sort { $a <=> $b } keys %states), "\nvalues == ", join(' ', map { unspecstr $states{$_} } sort { $a <=> $b } keys %states), "\n\ntoken  == ", unspecstr $token, "\n";###
			my %newstates;	# states/canonical input transitioned to this token

			# track new state and minimal string to reach it; prefer longest
			# string in case of multiple to choose from (literal characters in
			# all should be the same; hence, longer means more wildcards).  Use
			# of local *glob assignment is sneaky, indirect way needed to
			# generate nested sub with normal access to %states and %newstates.
			local *newstate = sub {
				my($newstate, $state, $tokens) = @_;
				my $specstr = "$states{$state}$tokens";
				$newstates{$newstate} = $specstr
					if ! exists $newstates{$newstate}	# *2*
					   || length($newstates{$newstate}) < length($specstr);
			};

			if ($token eq $star || $token eq $dots) {
				foreach my $state (keys %states) {
					my $tokens = ''; # accumulate characters to each next state
					if ($fxwild && ($pat[$state] eq $star || $pat[$state] eq $dots)) {
						# no characters on wildcard at literal
						$tokens = ($token eq $star) ? $token : $pat[$state];
					}
					newstate($state, $state, $tokens);
					for (my $i = $state + 1; $i < @pat; $i++) {
						last 	if exists $states{$i};
						last	if $token eq $star && $pat[$i] eq '/';
						if ($fxwild) {
							# clamp pat dots to token star
							$tokens .= ($token eq $star && $pat[$i] eq $dots)
											? $token : $pat[$i];
						} else {
							# wildcards need no characters
							$tokens .= ($pat[$i] eq $star || $pat[$i] eq $dots)
											? '' : $pat[$i];
						}
						newstate($i, $state, $tokens);
					}
				}
			} else {	# all literals including slash
				foreach my $state (keys %states) {	# *1*
					my @keys = ($token, 'any');
					push @keys, 'no/'	if $token ne '/';
					foreach my $key (@keys) {
						my $new = $nfa{$state, $key};
						next	if ! defined $new;
						newstate($new, $state, $token);
					}
				}
			}
			%states = %newstates;
		}
		###print "states == ", join(' ', sort { $a <=> $b } keys %states), "\nvalues == ", join(' ', map { unspecstr $states{$_} } sort { $a <=> $b } keys %states), "\nfinal states == @finalstates (prefer ", ($fxwild ? 'last' : 'first'), ")\n\n";###

		# are we in a final == accepting state?
		foreach my $finalstate ($fxwild ? reverse @finalstates : @finalstates) {
			return unspecstr specopt $states{$finalstate} # optimize wildcards
				if exists $states{$finalstate};			  # needed for fxwild
		}
		return;
	};

	return $fnint;
}


#
# specintersect - Return 'specstr intersects specpat'.  Both specstr and
# specpat must be in depot syntax.  Neither spec may contain @/# revision
# specifiers.  Both specs may contain */%n/... wildcards and almost always
# will.  Escaped or non-counting (preceded by :) wildcards are not currently
# supported.
#
# Because the notion of set intersection is symmetric, so are specstr and
# specpat -- swapping them should result in the same return truth value.  If
# neither or only one of the specs contains wildcards, the meaning of
# 'intersects' is the same as that for 'match' in specmatch.  A call to
# specmatch with the same arguments (spec with wildcards, if any, passed
# second) will yield the same truth value as specintersect -- 'does the set of
# possible files specified by specpat include specstr?'
#
# If both specs contain wildcards, 'intersect' means 'does there exist a
# filespec that is matched by both specstr and specpat?'.  Note that both
# specstr and specpat may describe additional files and that the intersecting
# files need not exist in any depot.  Also, note that on true return,
# specintersect yields a string describing a near-minimal filespec in the
# intersection.  If fxwild, returned string includes wildcard placeholders
# describing the intersection more completely.  Note that intersection may not
# be describable with a single SD pattern; e.g. complete intersection of //*a*
# and //*b* is //*a*b* and //*b*a*.  EXPERIMENTAL fxwild INTERFACE AND VALUE
# MAY CHANGE.
#
#
# For better performance when comparing with many specstrs and/or many specpats
# it is worth caching compiled forms of spec args and then inlining the actual
# match.  Cache the values as you see fit, emulating the basic behaviour of
# specintersect below:
# - clearwarnerr if you expect to check failures in subsequent steps with
#   SDError/SDWarning.
# - cache $specstr = specstr '//spec/str' for strings to be matched.  If you
#   can guarantee the strings will contain no */%n/... wildcards, there is no
#   need to call specstr.
# - cache $fnint = specpatint('//spec/pat/...') for strings to be compared
#   against for intersection.
# - perform the actual comparison with $fintersect = $fnint->($specstr), using
#   your cached values, instead of calling specintersect
#
#
# FUTURE: see relevant specmatch FUTURE comments
#
sub specintersect {
my($specstr, $specpat, $fxwild) = @_;

	clearwarnerr;

	# convert from depot syntax to canonical literal and intersection function,
	# respectively
	$specstr = specstr $specstr;
	my $fnint = specpatint($specpat);

	return	if ! defined $specstr || ! defined $fnint;

	# finally, compare according to intersection function
	return $fnint->($specstr, $fxwild);
}


#
# specpatrep - Convert depot-syntax strings to function reference suitable for
# use in mapping specstrs (provided later) according to the mapping implied by
# the specpat and specrep pair specified.  See specsubst below for details.
#
# floosecorrespond (only available when specpatrep is called directly) loosens
# the requirement that wildcards exactly match between specpat and specrep.  If
# specified, specpat can have more wildcards than specrep.  Extra (trailing)
# wildcards in specpat match string fragments that are not replicated through
# specrep.  %n syntax allows controlling which *-like wildcards are discarded;
# there is no analogous way to identify ... wildcards.
#
# FUTURE: support :: as escaped escape.  Precede splits with s///g using
# patterns similar to sub specpat (but preserving %n), after which splits can
# be simplified (no look-behind) yet still handle e.g. ::* correctly.  Changes
# in representation may affect entire subr.
# FUTURE: invent syntax for numbering ... wildcards analogous to %n for *.
#
sub specpatrep ($$;$) {
my($specpat, $specrep, $floosecorrespond) = @_;

	if ($specpat =~ /[@#]/) {
		synthcaller "specpat must not contain revision specifiers\n";
		return;
	}
	if ($specrep =~ /[@#]/) {
		synthcaller "specrep must not contain revision specifiers\n";
		return;
	}

	# split search/replace patterns into alternating literal/wildcard
	# components.  Specify limit of -1 to ensure a final (possibly empty)
	# literal component.  Standard split ensures a leading (possibly empty)
	# literal component.  ?<! negative look-behind assertion ensures escaped
	# wildcard tokens in rep are not considered as wild.  Note: negative split
	# limits and look-behind assertions require perl $] > 5.002, possibly
	# higher.
	my @pat = split /(?<!$esc)(\*|%\d|\.\.\.)/, $specpat, -1;
	my @rep = split /(?<!$esc)(\*|%\d|\.\.\.)/, $specrep, -1;

	# validate wildcard correspondence in patterns; first by number ...
	if ($floosecorrespond ? (@pat < @rep) : (@pat != @rep)) {
		synthcaller
		  "*/%n/... wildcards do not correspond between specpat and specrep\n";
		return;
	}

	# ... and then item by item.  Even components are always literals; odd
	# components, wildcards.  Collect odd components from pat ...
	my (@stars, @dotss, @percents);
	for (my $i = 1; $i < @pat; $i += 2) {
		if ($pat[$i] eq '*') {
			push @stars, $i;
		} elsif ($pat[$i] =~ /^%(\d)$/) {
			if (defined $percents[$1]) {
				synthcaller "only one '%$1' allowed in specpat\n";
				return;
			}
			$percents[$1] = $i;
		} else { # if ($pat[$i] eq '...')
			push @dotss, $i;
		}
	}

	# ... and ensure each occurs exactly (floosecorrespond: no more than) once
	# in rep.  Wildcard order need not be the same, so construct maporder to
	# indicate how they're rearranged between pat and rep.  nth item in
	# maporder is index of component in pat (and hence, in matches) that
	# belongs at the index in matches indicated by the nth component in odds.
	# Whew!
	my (@odds, @maporder);
	for (my $i = 1; $i < @rep; $i += 2) {
		push @odds, $i;		# just a handy list of odd (wildcard) indices
		if ($rep[$i] eq '*') {
			last	if @stars < 1;
			push @maporder, shift @stars;
		} elsif ($rep[$i] =~ /^%(\d)$/) {
			last	if ! defined $percents[$1];
			push @maporder, $percents[$1];
			undef $percents[$1];
		} else { # if ($rep[$i] eq '...')
			last	if @dotss < 1;
			push @maporder, shift @dotss;
		}
	}

	# odds and maporder are grown in parallel, so an early out above results in
	# a size mismatch between them.  Early out indicates attempt to pull from
	# an empty bucket, implying a mismatch.  If no early out, then all is well:
	# every item was pulled and all buckets are empty.  (If floosecorrespond,
	# unpulled items may remain; these are the discarded wildcards).
	if (@odds != @maporder) {
		synthcaller
		  "*/%n/... wildcards do not correspond between specpat and specrep\n";
		return;
	}

	# translate pat into regex.  For wildcard (odd) components, see specpat
	# notes for details; logic is analogous.  Even (literal) component handling
	# is specstresque as these need to match specstr-encoded data exactly.
	# FUTURE: track odd/even state explicitly to eliminate ifs for literal
	# components
	my $pat = '';
	foreach my $comp (@pat) {
		if ($comp eq '*' || $comp =~ /^%\d$/) {	# always odd
			$pat .= $mstar;
		} elsif ($comp eq '...') {				# always odd
			$pat .= $mdots;
		} else {	# literal, including literal wildcards; always even
			$comp =~ s/$esc(\*|%\d)/$star/go;
			$comp =~ s/$esc\.\.\./$dots/go;
			$pat .= '(' . quotemeta($comp) . ')';
		}
	}
	$pat = qr/^$pat$/i;

	# remove rep literal wildcard escape characters; they've done their job.
	# Expressing them in their raw form (instead of as $star, $dots) allows
	# preserving %d, but requires that unspecstr not alter them further.
	for (my $i = 0; $i < @rep; $i += 2) {
		$rep[$i] =~ s/$esc(\*|%\d|\.\.\.)/$1/go;
	}

	# create closure that actually maps specstrs (provided at call time)
	my $fnmap = sub {
		my($specstr, $fnomatchundef) = @_;

		# split specstr according to pat.  Analogous to @pat and @rep, even
		# components of @matches are matched literal text; odd components,
		# text matched by wildcards in pat.
		my @matches = $specstr =~ $pat;

		# replace matched literal (even) elements with corresponding elements
		# from rep and reorder matched wildcard (odd) elements within matches.
		# If not matched, specstr is not in scope of search/replace view;
		# return it without mapping.
		if (@matches) {
			# FUTURE: worth it to pre-compile @evens and assign by slicing?
			for (my $i = 0; $i < @rep; $i += 2) {
				$matches[$i] = $rep[$i];
			}

			# slice assignment is cool and fast and (most importantly) requires
			# no explicit temporaries for the swapping
			@matches[@odds] = @matches[@maporder];

			# replacement may be shorter (i.e. have fewer elements) than
			# original if floosecorrespond; extra items are now junk
			$#matches = $#rep;

			$specstr = join '', @matches;
		} elsif ($fnomatchundef) {
			return;
		}

		# always undo specstr's encoding of wildcards before returning.
		return unspecstr $specstr;
	};

	return $fnmap;
}


#
# specsubst - Return specstr after analog of 'specstr =~ s/specpat/specrep/'.
# All of specstr, specpat and specrep must be in depot syntax.  None may
# contain @/# revision specifiers.  All may contain */%n/... wildcards;
# specpat and specrep usually will.  Wildcards must correspond in type and
# number between specpat and specrep; reordering (e.g. %n) wildcards is allowed
# as by SD.  specpat and specrep only may contain escaped or non-counting
# (preceded by :) wildcards to be considered as literal text -- :* and :... .
# :%n is indistinguishable from :* in specpat -- either will match %n or * in
# specstr.  :%n in specrep will be preserved.  :: is not currently supported.
#
# Use specsubst to map a specstr according to the mapping implied between
# specpat and specrep; similar to how SD maps depotspecs into clients (using
# client views), other parts of the depot (using branch views) and labels
# (using label views).  A specstr will be mapped if it matches specpat
# according to specmatch.  An unmapped specstr will be returned unchanged
# unless fnomatchundef, in which case undef will be returned for unmapped
# specstrs.
#
#
# For better performance when mapping with many specstrs and/or many specpat/
# specrep pairs, it is worth caching compiled forms of spec args and then
# inlining the actual mapping operation.  Cache the values as you see fit,
# emulating the basic behaviour of specsubst below:
# - clearwarnerr if you expect to check failures in subsequent steps with
#   SDError/SDWarning.
# - cache $specstr = specstr '//spec/str' for strings to be matched.  If you
#   can guarantee the strings will contain no */%n/... wildcards, there is no
#   need to call specstr.
# - cache $fnmap = specpatrep('//spec/pat/...', '//spec/rep/...') for pairs of
#   strings defining a mapping.
# - perform the actual mapping with $specstr = $fnmap->($specstr), using your
#   cached values, instead of calling specsubst
#
#
# FUTURE: support :: (through specpatrep) as escaped escape for use on
# non-depotspec strings (e.g. sd users allows wildcards in user argument)
# FUTURE: should specsubst be named specmap?
# FUTURE: see relevant specmatch FUTURE comments
# FUTURE: fnomatchundef should always be true; migrate current users and change
# interface (here and in specpatrep-returned fnmap)?
# FUTURE: expose specpatrep floosecorrespond option?
#
sub specsubst {
my($specstr, $specpat, $specrep, $fnomatchundef) = @_;

	clearwarnerr;

	# convert from depot syntax to canonical literal and mapping function,
	# respectively
	$specstr = specstr $specstr;
	my $fnmap = specpatrep($specpat, $specrep);

	return	if ! defined $specstr || ! defined $fnmap;

	# finally, map according to mapping function
	return $fnmap->($specstr, $fnomatchundef);
}


#
# viewpatrep - Convert pairs of depot-syntax strings to function reference
# suitable for use in mapping specstrs (provided later) according to the view
# implied by the pairs.  See viewsubst below for details.
#
sub viewpatrep {
my($rview, $freverse) = @_;

	# Generate list of specpatrep function references representing view.  Non-
	# reference items in the list indicate 'unmap' values in view for following
	# function references.  List is in preferred search order (i.e. 'reversed'
	# top to bottom from input view) so traversal should iterate over list
	# normally.  Note that representation is optimized for few exclusionary
	# mappings (which matches generally preferred SD usage).  Unrelated to the
	# top-to-bottom reversal, if freverse, exchange left and right sides of
	# view to map in the other direction (i.e. from targetSpec to depotSpec).

	my @rfnmaps;
	foreach my $rmapping (reverse @{$rview}) {
		push @rfnmaps, $rmapping->{unmap}	if exists $rmapping->{unmap};
		my $rfnmap = $freverse
			? specpatrep($rmapping->{targetSpec}, $rmapping->{depotSpec})
			: specpatrep($rmapping->{depotSpec}, $rmapping->{targetSpec});
		return	if ! defined $rfnmap;
		push @rfnmaps, $rfnmap;
	}

	# create closure that actually maps specstrs (provided at call time)
	my $fnmapview = sub {
		my($specstr) = @_;

		my $funmap;
		foreach my $rfnmap (@rfnmaps) {
			if (! ref $rfnmap) {
				$funmap = $rfnmap;
				next;
			}
			my $mapped = $rfnmap->($specstr, 1);	# fnomatchundef
			if (defined $mapped) {
				return 	if $funmap;					# explicitly unmapped
				return $mapped;
			}
			undef $funmap;
		}
		return;
	};

	return $fnmapview;
}


#
# viewsubst - Return specstr after mapping through an ordered set of mappings
# expressed as a View (described at SDGetBranch) in rview.  Constraints are as
# described for specsubst, with specpat corresponding to depotSpec field in
# view records ('left-hand side') and specrep corresponding to targetSpec field
# ('right-hand side').  If freverse, exchange meanings of left-hand and
# right-hand sides.  Return undef if specstr is not mapped by any pair in rview
# or if applicable mapping in rview is exclusionary (matching the traditional
# meaning for a view).  Compare with specsubst default behaviour of returning
# original for unmapped specstr.
#
# For better performance when mapping with many specstrs and/or many views, it
# is worth caching compiled forms of args and then inlining the actual mapping
# operation, again as described for specsubst, with rview replacing specpat and
# specrep.
#
# FUTURE: handle multiple specstrs to reduce cases where caller must inline
# modified versions of this sub
# FUTURE: see relevant specsubst FUTURE comments
#
sub viewsubst {
my($specstr, $rview, $freverse) = @_;

	clearwarnerr;

	# convert from depot syntax to canonical literal and view mapping function,
	# respectively
	$specstr = specstr $specstr;
	my $fnmapview = viewpatrep($rview, $freverse);

	return	if ! defined $specstr || ! defined $fnmapview;

	# finally, map according to mapping function
	return $fnmapview->($specstr);
}



# constant representing incomplete back reference
sub selfref () { '<0>' }	# any out-of-range value would do

#
# backref - Return nth item in rstack of strings with symbolic references to
# other strings in stack expanded.  rstack size is defined by cstack; stack has
# elements 0 to cstack-1, with zero considered out of range (present to
# simplify indexing).  undef values in rstack (explicit or with indices >
# $#$rstack) are considered the empty string.  n out of bounds returns a range
# error.  Symbolic reference out of bounds during expansion returns self-
# reference error, in support of idiom of using selfref to indicate stack item
# being defined, which cannot be referenced while evaluating other items to
# become part of it.  (Malformed stack items can therefore, perhaps
# inappropriately, lead to self-reference errors.)  Errors are returned as
# references to strings.
#
# Typical access pattern: n is arbitrary location within stack (reflecting user
# reference to $n).  Symbolic references to be expanded refer only to other
# stack entries with increasing indices (representing nested <> groups, which
# are numbered higher) by construction in tagref and stack assignment.
# Recursion will stop with no further symbolic references, or as some reference
# goes out of range, returning error.  selfref is itself out of range (although
# with a too-small value, not too-large).  Malformed stack items could result
# in a loop, but recursion stops (and returns error) when depth exceeds cstack,
# by which point some item must have been visited twice.
#
# FUTURE: distinguish self-reference (n == 0) from loops, other malformed cases
#
# History: considered an alternative scheme rooted in
#   $rstack->[$n] =~ s/<(\d+)>/_backref($1, $rstack, $cstack)/eg;
# We can't reliably return failure (_backref() || return would be fooled by 0
# and empty string) so need to fail with die and wrap s/// with eval to catch.
# s/// modifies stack in place (saving resolved symbolic references) making
# subsequent references faster, but is not completely cleared out when
# backtracking to new alternatives (consider <a<x>|<$2>> <$1>: $1 freezes
# rstack->[2] at 'x', so $2 resolves as 'x' in second alternative instead of
# '').  To solve this requires cloning stack at each alternative.  Current
# approach prefers to do minimal work up front, pushing as much evaluation as
# possible on actual back references.  Repeated back references will repeat
# some work, but overhead for no-back-reference cases is minimal.
#
sub backref {	# entrypoint
my($n, $rstack, $cstack) = @_;

	return \"Invalid back reference '\$$n'."
		if $n == 0 || abs($n) >= $cstack;

	my $nSav = $n;
	$n = $cstack + $n		if $n < 0;	# resolve -ve index

	my $str = _backref($n, $rstack, $cstack, 1);
	return \"Self-referential back reference '\$$nSav'."
		if ! defined $str;

	# FUTURE: assert $str !~ tr/<|>//;
	return $str;
}

sub _backref {	# recursive implementation
my($n, $rstack, $cstack, $nrec) = @_;

	return	if $n == 0 || $n >= $cstack || $nrec > $cstack;

	return ''	if ! defined $rstack->[$n];

	my @str = split /<(\d+)>/, $rstack->[$n];	# empty trailing fields kept
												#  due to captured delimiters

	for (my $i = 1; $i < @str; $i += 2) {	# odd items are symbolic references
		$str[$i] = _backref($str[$i], $rstack, $cstack, $nrec + 1);
		return	if ! defined $str[$i];
	}

	return join '', @str;
}


#
# tagref - Return str with top-level <> groups replaced by symbolic references
# starting with n, which can later be expanded to current values by backref.
#
sub tagref {
my($str, $n) = @_;

	my @str = split /([<>])/, $str;

	# replace contents of each outermost <> group with symbolic name (index) of
	# group it represents (reusing <> delimiters; these characters are still
	# not allowed literally)
	my $open;
	my $depth = 0;
	my $copen = 0;
	for (my $i = 1; $i < @str; $i += 2) {	# odd items are metacharacters
		if ($str[$i] eq '<') {
			if (++$depth == 1) {	# open scope on first <
				$open = $i;
			}
			$copen++;
		} elsif ($str[$i] eq '>') {
			if (--$depth == 0) {	# close scope on matching >
				# replace just the contents (i.e. don't touch <>)
				splice @str, $open + 1, $i - $open - 1,	# pad with '' items for
					   $n, ('') x ($i - $open - 2);		#  constant array size
				$n += $copen;
				$copen = 0;
			}
		} # FUTURE: else assert unreached?
	}
	# FUTURE: assert depth == 0?

	return join '', @str;
}


#
# evaltoken - Evaluate str as back reference ('$1'), variable ('$foo') or
# function call ('&bar($1)'), using data from other arguments.  Strings not
# identified as special (i.e. not starting with $ or &) evaluate to themselves.
# Return evaluated string or reference to error message on failure.
#
sub evaltoken {
my($str, $rmpfns, $rstack, $cstack) = @_;

	if ($str =~ /^[\$\&]/) {
		if ($str =~ /^\$(-?\d{1,2})$/) {					# back reference
			$str = backref($1, $rstack, $cstack);

		} elsif ($str =~ /^\$([._a-z][.\w]*)$/i) {			# variable
			return \"Unknown variable '\$$1'."
				if ! exists $rmpfns->{$1} || ref $rmpfns->{$1};
			$str = $rmpfns->{$1};
			return \"Variable '\$$1' expansion contains invalid character '<|>'."
				if $str =~ tr/<|>//;

		} elsif ($str =~ /^&([.\w]+)\(\$(-?\d{1,2})\)$/) {	# function call
			return \"Unknown function '\&$1'."
				if ! exists $rmpfns->{$1} || ref $rmpfns->{$1} ne 'CODE';
			$str = backref($2, $rstack, $cstack);
			return $str		if ref $str;
			$str = $rmpfns->{$1}->($str);
			return \"Function '\&$1($2)' result contains invalid character '<|>'."
				if $str =~ tr/<|>//;

		} else {
			return \"Syntax error '$str'.";
		}
	}

	return $str;
}


#
# expextspec - Expand an extended syntax depotspec into a list of equivalent
# traditional syntax depotspecs, returning the list.  Syntax errors set sderror
# and return empty list.
#
# Extended syntax:
# - <a|b|...> sequences expand to each of a, b, ... in turn
# - within <>, each alternative (a, b, ... above) may be a special token:
#   - $n (i.e. $1, $2, ...) referring to the current expanded value of the nth
#     instance of <> within str, n < index of current <> and n <= 99, nth group
#     identified by nth < counting from start of str
#   - $-n (i.e. $-1, $-2, ...) referring to the current expanded value of the nth
#     instance of <> preceding the $-n token, and abs(n) <= 99, counting
#     occurrences of < backwards from the $
#   - $var referring to caller-provided variable in rmpfns, where the name
#     ('var' in this example) must consist of one or more characters, each of
#     which must be alphanumeric, '.' or '_'; the first character may not be
#     numeric
#   - &fn($n) referring to caller-provided function of one argument in rmpfns,
#     where the name ('fn' in this example) must consist of one or more
#     characters, each of which must be alphanumeric, '.' or '_' and $n is
#     as in preceding point
#
# Relative back references can be non-intuitive, particularly in constructs like
# '<x>...<$-1>', in which $-1 refers to itself, not the group containing 'x'.
#
# Hybrid API (for internal use but EXPORT_OK) expects caller to clearwarnerr.
#
# Expansion finds first, outermost <> group, replaces that (in turn) with each
# alternative defined within it, recursing with the resultant string, and
# returns with the aggregated results of the recursive calls.  Each recursion
# considers alternatives effectively in parallel, and removes one <>,
# guaranteeing eventual termination.  Variable and function expansion is
# straightforward (but values are not allowed to contain <|> characters, to
# avoid need for supporting literals).
#
# Back reference support is more complex.  The reference index of any group
# must be constant across all alternatives, even though it can be affected by
# groups in alternatives not taken in a particular recursion.  The relevant
# information is available when alternatives are chosen, and passed to
# recursive calls in rskip; a set of spoken-for group indices.  When recursing,
# the next group is generally n+1 when it's nested (i.e. alternative itself
# contains a child <> as it's contiguous with current group n in the string),
# but can be n+more (requiring skipping indices allocated to neighbour
# alternatives) when the alternative contains no <> groups.  In this case, the
# next <> encountered will be a following sibling group within the current
# alternative in some parent recursion (and so, lexically after neighbour
# alternatives not yet considered at any level).
#
# Expansions of back references may implicitly refer to other back references
# (representing contained <> groups).  Current alternative <> contents are
# stored in a stack, with contained <> groups represented by symbolic
# references (using similar syntax: <n> replaces <all|<nested|groups>>).
# Symbolic references are expanded when a back reference is actually made, for
# lazy evaluation efficiency, but also, to avoid having to clear out stale
# values when backtracking: expansions of references <n can refer to <> groups
# >n, which must be cleared out when starting a new alternative at n.
#
# FUTURE: formally define alternative, sibling, neighbour, parent
# FUTURE: generate errors for "useless back reference always returns ''"
# FUTURE: parameterize delimiter characters to allow easy switch to (say) {,}
# FUTURE: split str once in expextspec and pass ref to array of tokens to
# _expextspec instead of str; complicates data access and special token
# resolution, but may be faster because of fewer splits
# FUTURE: more syntax extensions; e.g. means of expressing literal < | > ?
#
sub expextspec {	# entrypoint
my($str, $rmpfns) = @_;

	$rmpfns = {}	if ! defined $rmpfns;
	my @ret = _expextspec($str, $rmpfns, [undef], 1, {});	# 1-based stack
	my ($rerror) = grep { ref } @ret;	# collect first error only

	if (defined $rerror) {
		synthcaller "$$rerror\n";
		return;
	}
	return @ret;
}

sub _expextspec {	# recursive implementation
my($str, $rmpfns, $rstack, $n, $rskip) = @_;

	my @str = split /([<|>])/, $str;
	return $str		if @str <= 1;	# quick return if no metacharacters

	# find delimiters for first, outer <a|b> sequence, remembering their
	# indices, and total number of nested sequences, with opportunistic syntax
	# checking
	my ($open, @seps, $close);
	my $depth = 0;
	my $copen = 0;
	for (my $i = 1; $i < @str; $i += 2) {	# odd items are metacharacters
		if ($str[$i] eq '<') {
			if (++$depth == 1) {	# open scope on first <
				$open = $i;
			}
			$copen++;
		} elsif ($str[$i] eq '|') {
			if ($depth == 1) {
				push @seps, $i;
			} elsif ($depth < 1) {
				return \"Unexpected '|'.";
			}
		} elsif ($str[$i] eq '>') {
			if (--$depth == 0) {	# close scope on matching >
				$close = $i;
				last;
			} elsif ($depth < 0) {
				return \"Unexpected '>'.";
			}
		} # FUTURE: else assert unreached?
	}

	if (defined $close) {	# FUTURE: assert defined $open?
		# there is a first, outer well-formed <> group

		# reserve all indices to be consumed within this <> in skip set
		@{$rskip}{$n + 1 .. $n + $copen - 1} = ();
		# FUTURE: assert all bits just set are new?

		my @ret;

		# generate alternatives
		my $cstack = $n + 1;
		my $prev = $open;
		foreach my $sep (@seps, $close) {
			# prepare stack (see sub backref for details) for next iteration:
			# 1 - mark $n as unavailable while being built; evaluation of $n or
			#     parent referring to $n discovers selfref, returning error
			$rstack->[$n] = selfref;
			# 2 - discard items >$n from prior alternatives and deeper calls.
			#     Items <$n (from higher calls) are valid and unchanged
			#     (backref does not modify rstack).  Note this does not imply
			#     $n is top of stack; <> groups within earlier (left)
			#     alternatives of $n have higher indices (up to cstack-1), and
			#     while always empty, are legal to reference
			splice @$rstack, $n + 1;

			# evaluate alternative as special token
			my $alt = evaltoken(join('', @str[$prev+1..$sep-1]),
								$rmpfns, $rstack, $cstack);
			return $alt		if ref $alt;

			# release indices (possibly none) for use in this alternative
			my $copenalt = $alt =~ tr/<//;	# number of <>s within alternative
			delete @{$rskip}{$cstack .. $cstack + $copenalt - 1};

			# index of next <> must be greater than any seen; may be 'nchild'
			# == cstack (when copenalt > 0) or 'nsibling' to some parent >
			# cstack (found by skipping indices belonging to neighbours)
			my $nnext = $cstack;
			$nnext++	while exists $rskip->{$nnext};

			# stack expansion pattern with symbolic references
			$rstack->[$n] = tagref($alt, $nnext);

			# return further expansions of generated string set
			# FUTURE: more efficient to pre-join prefix and suffix?
			push @ret, _expextspec(join('', @str[0..$open-1],
										$alt,
										@str[$close+1..$#str]),
								   $rmpfns, $rstack, $nnext, $rskip);
			$cstack += $copenalt;
			$prev = $sep;
		}

		# FUTURE: assert rskip describe same set as on entry
		return @ret;
	} elsif (defined $open) {	# && ! defined $close
		return \"Missing '>'.";
	} else {
		return $str;
	}
}



use vars qw(%mpaliastypemod %mptypemodalias %mptypeimpmod);
%mpaliastypemod = (		# map type alias to base type+modifiers
	# values must contain a '+' and list modifiers in canonical order
	ctext     => 'text+C',
	cxtext    => 'text+Cx',
	ktext     => 'text+k',
	kxtext    => 'text+kx',
	ltext     => 'text+F',
	xltext    => 'text+Fx',
	xtext     => 'text+x',
	ttext     => 'text+T',
	kunicode  => 'unicode+k',
	kxunicode => 'unicode+kx',
	xunicode  => 'unicode+x',
	tempobj   => 'binary+Sw',
	ubinary   => 'binary+F',
	uxbinary  => 'binary+Fx',
	xbinary   => 'binary+x',
	xtempobj  => 'binary+Swx',
	tbinary   => 'binary+T',
	uresource => 'resource+F',
);

%mptypemodalias = reverse %mpaliastypemod;

%mptypeimpmod = (		# map base type to default implied modifiers
	text      => 'D',
	unicode   => 'D',
	binary    => 'C',
	symlink   => 'D',
	apple     => 'C',
	resource  => 'C',
);

#
# typenorm - Normalize depot filetype in rtype.  Type aliases are replaced by
# base type+modifiers.  If rtype is a reference, normalize referenced filetype
# string in place.  Regardless, return normalized filetype string.  Unknown
# types and inappropriate modifiers set sderror and return undef.  Examine
# returned string for individual filetype properties by extracting letters
# with regular expressions.
#
# Implicit modifiers (e.g. 'text' with no modifiers is equivalent to 'text+D')
# are not included by default (no tnformat), or if tnformat is specified as
# tnNormal.  if tnformat is tnAliases, output is like tnNormal except that
# type aliases will be used for exact matches; see sd help filetypes for
# reference.  If tnformat is tnAll, implicit storage type modifiers are
# included.  If tnformat is tnTypeOnly, only base type is returned.  If
# tnformat is tnModOnly, only type modifiers, including implicit ones, are
# returned.
#
# Hybrid API (for internal use but EXPORT_OK) expects caller to clearwarnerr.
#
# FUTURE: populate tables on first use?
# FUTURE: consider a single table, mpaliastypmod, which includes basic types
# and where all values include storage modifier.  Common code would be simpler
# and faster but data would no longer mirror sd help filetypes output.
# mptypeimpmod would still be required for tnNormal and tnAliases formatting.
# FUTURE: report errors for special unsupported cases: resource+x, symlink+x
# FUTURE: as +0 is read-only, it may be an error depending on intended use
# FUTURE: fewer hardcoded modifier letter lists (marked with 'current' below)
# FUTURE: in list context, return base type and modifiers as separate elements?
#
sub typenorm {
my($rtype, $tnformat) = @_;

	my $type = ref $rtype ? $$rtype : $rtype;
	$tnformat = tnNormal	if ! defined $tnformat;

	my ($base, $mod) = split /\+/, $type, 2;
	$mod = '' 	if ! defined $mod;

	# sanity check caller-specified explicit modifiers
	if ($mod =~ tr/CDFSTkemwx0//c) {	# all current modifiers
		# sderror text mimics sd reopen -t errors
		synthcaller "Invalid file type modifier on '$type'.\n";
		return;
	}
	if (($mod =~ tr/CDFST//) > 1) {	# current storage modifiers
		synthcaller "Too many storage modifiers on '$type'.\n";
		return;
	}


	# expand type aliases
	# note that alias expanded modifiers are 'weak'; in
	#   ltext+D == (text+F)+D == text+D
	# explicit +D wins over weak +F without too-many-storage-modifiers error
	my $weak;
	if (exists $mpaliastypemod{$base}) {
		($base, $weak) = split /\+/, $mpaliastypemod{$base}, 2;
		# all in mpaliastypemod have modifiers, ensuring weak is defined
	} else {
		$weak = '';
	}

	# sanity check type after expansion
	if (! exists $mptypeimpmod{$base}) {
		synthcaller "Invalid file type '$type'.\n";
		return;
	}

	# early out if modnorm won't be used
	if ($tnformat == tnTypeOnly) {
		$type = $base;
		goto RETURN_TYPE;
	}


	# determine actual modifiers given $mod, $weak and implicit storage type
	# modifiers in $mptypeimpmod{$base}

	# UPPER CASE storage type: single explicit modifier if there is one, else
	# weak modifier if there is one, else implicit modifier from mptypeimpmod
	my ($modnorm) = "$mod$weak$mptypeimpmod{$base}" =~ /([A-Z])/;

	# lower case client types: sorted (like SD; not quite alphabetical)/uniqued
	# set of explicit and weak modifiers; multiple occurrences allowed
	$weak =~ tr/A-Z//d;		$mod =~ tr/A-Z//d;
	my %client;
	@client{split(//, "$weak$mod")} = (1) x (length($weak) + length($mod));
	foreach my $ct (qw(k e m w x 0)) {	# current client modifiers
		$modnorm .= $ct	if exists $client{$ct};
	}


	# compose return string from base and modnorm according to specified format
	if ($tnformat == tnNormal) {
		$modnorm =~ s/$mptypeimpmod{$base}//;
		$type = $base . (($modnorm eq '') ? '' : "+$modnorm");
	} elsif ($tnformat == tnAliases) {	# superset of tnNormal
		$modnorm =~ s/$mptypeimpmod{$base}//;
		$type = $base . (($modnorm eq '') ? '' : "+$modnorm");
		$type = $mptypemodalias{$type}	if exists $mptypemodalias{$type};
		# all in mptypemodalias are canonical, ensuring alias will be found
	} elsif ($tnformat == tnAll) {
		$type = $base . (($modnorm eq '') ? '' : "+$modnorm");
#	} elsif ($tnformat == tnTypeOnly) {	# early out above
#		$type = $base;
	} elsif ($tnformat == tnModOnly) {	# all modifiers, including implicit
		$type = $modnorm;
	} # FUTURE: else assert unreached?

  RETURN_TYPE:
	$$rtype = $type		if ref $rtype;
	return $type;
}



#
# SDWarning/Error - Return warning/error text in sdwarning/error from last SD*
# call, or undef if no warning/error text available.  If called with \'-s'
# argument, (actually, any true argument, right now) text returned is suitable
# for further parsing (sd -s format).  Otherwise, it's suitable for immediate
# printing (as output by sd without -s).  THE MEANING OF THE ARGUMENT WAS
# REVERSED PRIOR TO $VERSION 0.33 OF SD.PM.  Adjust old code.
#
# SDExit - Return exit code from last SD* call.  Should be needed very rarely.
#
sub SDWarning {
	if (! $_[0]) {
		my @ret = mappd @sdwarning;
		return wantarray ? @ret : join '', @ret;
	} else {
		return wantarray ? @sdwarning : join '', @sdwarning;
	}
}

sub SDError {
	if (! $_[0]) {
		my @ret = mappd @sderror;
		return wantarray ? @ret : join '', @ret;
	} else {
		return wantarray ? @sderror : join '', @sderror;
	}
}

sub SDExit {
	return $sdexit;
}


#
# SDVersion - Return version of current sd client (sd.exe, when lc sdc eq
# sdcClient) or server (sds.exe at configured or ambient port, when lc sdc eq
# sdcServer).  In scalar context, return version as single descriptive string
# including sd component, any beta indicator and platform.  In list context,
# return (sdc, major, minor, build, dot, beta, platform).  Return undef/empty
# list on failure.
#
# Perforce versions are somewhat supported.  'p4' and 'p4d' are understood as
# sdc synonyms for 'sd'/sdcClient and 'sds'/sdcServer respectively.  Returned
# version strings/lists reflect actual product in sdc.  While the same array
# fields are returned for Perforce, the ranges of version numbers are very
# different (e.g. 2004.2.76994.0 vs 3.5.8130.1), the platform field is slightly
# different (e.g. 'NTX86' vs. 'NT X86') and the Perforce build date is not
# returned.
#
# FUTURE: cache results in new %ver, and save sd info client version when
# SDVersion(sdcServer) is called.  Invalidate on ConfigSD calls.  Cache server
# values per port, but a single client value.  Cache won't be invalidated if
# outside forces upgrade client or server, but caller can clear the cache using
# ConfigSD to specify a new (or the existing) value for sdexe.
#
# See text on 'macro functions' at 'Implementation Notes'.
#
sub SDVersion {
my($sdc) = @_;

	clearwarnerr;

	if (! defined $sdc) {
		synthcaller "sd component must be specified\n";
		return;
	}

	# suppress text and info; use local instead of ConfigSD() so original
	# value is automatically restored on return
	local $config{echo} = $config{echo} & (echoWarning | echoError);

	my $lcsdc = lc $sdc;

	if ($lcsdc eq sdcClient || $lcsdc eq 'p4') {

		local *PIPE;
		sdpopen(*PIPE, '-V') || return;
		my @out = readfilt *PIPE, 'info';
		sdpclose *PIPE;

		return	if @out == 0 && $? != 0;

		foreach my $line (@out) {
			if (my ($verplat, @verplat) = $line =~ m!^info: Source Depot, Version ((SD) $rever4 $remplat2)!) {
				# 'SD 3.6.8904.0 Beta (NT X64)'
				#     or
				# ('SD', 3, 6, 8904, 0, 'Beta'/undef, 'NT X64')
				return wantarray ? @verplat : $verplat;
			} elsif (($verplat, @verplat) = $line =~ m!^info: Rev. ((P4)/(\w+)/(\d+)\.(\d+)/(\d+))!) {
				# pad, rearrange 'P4/NTX86/2004.2/76994 (2005/03/08)'
				push @verplat, 0, undef, splice(@verplat, 1, 1);
				return wantarray ? @verplat : $verplat;
			}
		}

	} elsif ($lcsdc eq sdcServer || $lcsdc eq 'p4d') {

		my $rinfo = SDInfo();
		return	if ! defined $rinfo;

		my $version = $rinfo->{'Server version'};

		if (defined $version) {
		 	if (my ($verplat, @verplat) = $version =~ m!^((SDS) $rever4 $remplat2)!) {
				return wantarray ? @verplat : $verplat;
			} elsif (($verplat, @verplat) = $version =~ m!^((P4D)/(\w+)/(\d+)\.(\d+)/(\d+))!) {
				push @verplat, 0, undef, splice(@verplat, 1, 1);
				return wantarray ? @verplat : $verplat;
			}
		}

	} else {
		synthcaller "unknown sd component $sdc specified\n";
		return;
	}

	synthinternal "no/unexpected version information returned by $sdc\n";
	return;
}


#
# SDAtLeastVersion - Return 'version of sd component sdcreq is that described
# by verreq or greater'.  sdc is an sdc constant value indicating (currently)
# client or server.  verreq is a number: e.g. 2 or 3.5, string: '2' or
# '3.5.8130.1' or list of integers: (2) or (3, 5, 8130, 1).  Return undef
# if required version is not met, on failure to detect version for comparison,
# or if values are not comparable (e.g. Perforce version to be compared with
# SD version).
#
# A typical invocation is:
#   if (SDAtLeastVersion(sdcClient, 2.7)) { 2.7-specific-stuff ... }
# List context return from SDVersion is an acceptable argument list:
#   SDAtLeastVersion(SDVersion(sdcClient or sdcServer))
# should always return true.  Describe ranges with two invocations:
#   SDAtLeastVersion(sdcServer, 2.0) && ! SDAtLeastVersion(sdcServer, 3.0)
# is true for any 2.x SD server.
#
# See text on 'macro functions' at 'Implementation Notes'.
#
sub SDAtLeastVersion {
my($sdcreq, @verreq) = @_;

	clearwarnerr;

	# canonicalize required version as array
	if (@verreq == 0) {
		synthcaller "sd component and required version must be specified\n";
		return;
	} elsif (@verreq == 1) {	# single (dotted) string or number (maybe one dot)
		@verreq = split(/\./, $verreq[0]);
	} # else assume list of integers

	push @verreq, 0	while @verreq < 4;	# pad to at least four components

	my @actual = SDVersion($sdcreq);
	return	if ! @actual;		# sdwarning/error set by SDVersion

	# compare components; different products (e.g. p4, sds) aren't comparable
	return	if lc shift @actual ne lc $sdcreq;

	# compare version elements
	foreach my $i (1..4) {
		my $actual = shift @actual;
		my $req    = shift @verreq;
		if ($actual != $req) {
			if ($i == 2) {				# SDAPI documentation indicates minor
				$actual = "0.$actual";	#  version is to be treated as a
				$req    = "0.$req";		#  decimal fraction
			}
			return $actual > $req;
		}
	}

	# equal through all components; exactly equal counts as 'at least'
	return 1;
}
sub _SDAtLeastVersion { return internal(\&SDAtLeastVersion, @_); }


#
# SDSyncSD - Ensure sd.exe is newest in this branch (or specified revision, if
# revision is specified,) syncing it if necessary.  Return %sync/undef on
# sync/no-sync needed.  Use copy of current sd.exe from client to do the sync.
# It's inappropriate to call this if binarch\sd.exe is not in the client or
# depot.
#
# FUTURE: explicit handling of interesting cases such as user having old
# revision opened for edit, or old revision being in use outside this instance
# of SD.pm
# FUTURE: use sd.exe#head instead of sd.exe#have? Get it with
# SDPrintFile($bin{sd2}, $sd);
#
sub SDSyncSD {
my($rev) = @_;

	$rev = ''	if ! defined $rev;
	my $sd = "$bin{sd}$rev";

	my $rh = SDSync(opt '-n', $sd);
	if (defined $rh) {
		local $config{safesync} = 1;	# instead of ConfigSD(safesync => 1) so
		return SDSync($sd);				# it's automatically restored on return
	}
	return;
}


#
# getudomain - Return current user's domain determined by one of a couple of
# methods or undef if not available.  Win32::Domain should do this but is buggy
# and usually returns machine domain.  Emulate use Win32 at runtime if
# available (so there's no hard dependency on that module).
#
sub getudomain {
	my $udomain;
	local $SIG{__DIE__};	# prevent __DIE__ being called during eval
	if (eval { require Win32 }) {
		eval { import Win32 };
		my ($sid, $sidtype);
		eval "Win32::LookupAccountName('', Win32::LoginName(), \$udomain, \$sid, \$sidtype)";
	} elsif (defined $ENV{USERDOMAIN}) {
		$udomain = $ENV{USERDOMAIN};
	}
	return $udomain;
}


# Map SD variable name to SD option (mpvaropt), or fallback SD variable name
# (mpvarfb), or environment variable name (mpvarfbenv), or default value
# (mpvarfbdef).  All keys and values that may be used as keys next iteration
# are in canonical upper case.  Keep tables in sync with sd help variables.

use vars qw(%mpvaropt %mpvarfb %mpvarfbenv %mpvarfbdef);
%mpvaropt = (
	SDCLIENT         => 'client',
	SDHOST           => 'host',
	SDPORT           => 'port',
	SDPROXY          => 'proxy',
	SDUSER           => 'user',
);

%mpvarfb = (
	SDDIFF           => 'SDUDIFF',
	SDFORMEDITOR     => 'SDEDITOR',
	SDEDITOR         => 'SDUEDITOR',
);

%mpvarfbenv = (
	SDUDIFF          => 'DIFF',
	SDUEDITOR        => 'EDITOR',
	SDMERGE          => 'MERGE',
	SDPAGER          => 'PAGER',
);

%mpvarfbdef = (
	# DIFF           => internal,
	EDITOR           => $fwin ? 'notepad.exe' : 'vi',
	# MERGE          => internal,
	# PAGER          => no pager,
	SDALIASES        => 'sdaliases.ini',
	SDAUTH           =>
		$fwin
			? sub {
				my $id = Win32::GetOSVersion();
				return 'negotiate ntlm md5domain'	if $id == 2;	# WinNT
				return 'negotiate ntlm'				if $id == 1;	# Win9x
				return '';
			  }
			: sub {
				return 'md5domain md5token'			if $^O eq 'interix';
				return 'md5token';	# including 'darwin' (MacOSX) and 'unix'
			  },
	SDCONFIG         => 'sd.ini',
	SDCLIENT         =>
		$fwin
			? sub { return Win32::NodeName() }
			: sub { my $host = qx(hostname); chomp $host; return $host },
	SDHOST           =>
		$fwin
			? sub { return Win32::NodeName() }
			: sub { my $host = qx(hostname); chomp $host; return $host },
	# SDLOCATION     => '',
	# SDPASSWD       => '',
	SDUSER           =>
		$fwin
			? sub {
				my $udomain = getudomain();
				if (defined $udomain) {
					$udomain .= '\\';
				} else {
					$udomain = '';
				}
				return $udomain . Win32::LoginName();
			  }
		   : sub { return $ENV{USER} },

	# preferences (normally mixed case but case-insensitive; hence upper here)
	ATTRWARNING      => '0x0E',
	ATTRERROR        => '0x0C',
	ATTRSUMMARY      => '0x0D',
	ATTRTRANSPARENCY => 0,
	BYPASSPROXY      => 0,
	COLORIZEOUTPUT   => 1,
	NEVERRECYCLE     => 0,
);


#
# SDGetEffective - Retrieve 'effective' value of specified SD variable from the
# environment/.ini file/registry.  If variable is defined and not the empty
# string, effective value is the value of the variable.  If variable is not
# defined or is the empty string, effective value is the effective value of the
# variable it falls back to or the default value specified by 'sd help
# variables'.  If rset (from previous [_]SDSet) is passed in, use it as base
# environment instead of calling _SDSet internally (and eliminate any chance of
# _SDSet failure).  Command line values (from %config) override all.
#
# Return effective value/undef on success/failure.  Return empty string for
# non-SD variables.  AS OF $VERSION 2.73, VARIABLE NAME undef IS CONSIDERED
# FAILURE (returning undef) instead of a non-SD variable (returning '').
#
# NOTE: Variables that fall back to Source Depot internal values (e.g. internal
# diff, internal merge and no pager) fall back to the empty string here.
# FUTURE: support Server Preferences and Server Variables? PWD on non-Windows
# systems?
# FUTURE: mode or sub that overrides effective value based on other state:
#   return current console colours for AttrError/Warning/Summary
#       if SDGetEffective(ColorizeOutput) == 0
#   return combination of current and specified console colours for Attr*
#       if SDGetEffective(AttrTransparency) != 0
#   return 0 for BypassProxy
#       if defined config{proxy}
#   return file found according to sd help inifiles search rules for SDAliases
#       if ! -f SDGetEffective(SDAliases)
#
sub SDGetEffective {
my $var = shift @_;
my $rset = @_ ? rshifthash(@_) : undef;

	if (! defined $var) {
		synthcaller "variable name must be specified and not 'undef'\n";
		return;
	}

	$var = uc $var;

	# command line options (represented as config entries) override even
	# explicit variable values
	if (exists $mpvaropt{$var}
	 && defined $config{$mpvaropt{$var}}
	 && $config{$mpvaropt{$var}} ne '')
	{
		return $config{$mpvaropt{$var}};
	}

	if (! defined $rset) {
		$rset = _SDSet();
		return	if $? != 0;
	}

  RETRY:
	if (defined $rset->{$var} && $rset->{$var} ne '') {
		return $rset->{$var};
	} elsif (exists $mpvarfb{$var}) {	# fall back to SD variable
		$var = $mpvarfb{$var};
		goto RETRY;
	}

	if (exists $mpvarfbenv{$var}) {		# fall back to environment variable
		$var = $mpvarfbenv{$var};
		if (defined $ENV{$var} && $ENV{$var} ne '') {
			return $ENV{$var};
		}
	}

	if (exists $mpvarfbdef{$var}) {		# fall back to default
		return ref $mpvarfbdef{$var}
			? &{$mpvarfbdef{$var}}
			: $mpvarfbdef{$var};
	}

	return '';	# undef only indicates _SDSet failure
}



#
# BEGIN - Load-time initialization.
#
BEGIN {
InitSD();
}


#
# END - Unload-time termination.
#
END {
local ($!, $?);		# so following cleanup doesn't trash exit code
unlink $bin{sd2}	if -f $bin{sd2};		# if safesync ever used
}


1;

