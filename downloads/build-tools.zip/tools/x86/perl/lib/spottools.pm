#Based on Office otools.pm

package spottools;

$VERSION = '1.04';

=head1 NAME

spottools - Perl pragma to configure scripts to run in an spottools environment

=head1 SYNOPSIS

    # SPOT standard perl scripts should begin with:

    BEGIN {	# common spottools script configuration -- do not edit
    require "$ENV{SPOROOT}\\tools\\x86\\perl\\lib\\spottools.pm"; import spottools;
    }

    # ... which will set @INC appropriately to find the standard and
    # spot-specific perl libraries.

    # 'import spottools' takes some options to configure additional common,
    # but not universal, spottools script behaviour:

    'libscriptdir' prepends the directory containing the calling script to
                   the @INC path, so modules located in the script
                   directory will be found by 'use'.

    'warnfmt'      will change the formatting of perl warnings to an
                   Office-specific layout (prefixing the output text with
                   'Warning:') and perl dies (prefixing output text with
                   'Error:') followed by the callstack where the warning
                   or error occurred.  Note: the current format is subject
                   to change.

=head1 DESCRIPTION

C<use spottools> will configure the calling script to function properly in an
spottools environment.  Principally, it sets @INC suitably to allow require and
use to find modules in spottools.

Generally, scripts should not care about the content of @INC, trusting it to be
correctly managed by spottools.pm.  Select scripts, however, need to find files
other than through 'require' or 'use'.  These may count on $INC[-1] referencing
the root of the perl library (i.e. 'spottools\lib\perl') even if no
environment variables (i.e. %spottools%) are set, when using perl5.6.  Any
additions to @INC made outside of spottools.pm should prepend (unshift) to
preserve this guarantee.

Additionally, based on the presence of optional arguments to the use or import
statement, the module will configure additional common, but not universal,
behaviours.  _All_ spottools perl scripts should invoke this module.

If the script environment were already set, one could simply 'use spottools;'
instead of require'ing spottools.pm with a full path, and explicitly calling the
spottools import method, but it's to set this environment that we're doing all of
this in the first place -- catch 22.

See  http://officedev/perltips.htm  for more detailed information on 
perl tools and standards.

=head1 AUTHOR

Stephan Mueller, E<lt>F<smueller@microsoft.com>E<gt>

=cut

require 5;		#or 5.6 or 5.8
#use strict;	# can't find it yet

sub callstack {
	my $index = 0;
	my $file;
	my $line;
	while (my (undef, $nextfile, $nextline, $subroutine) = caller(++$index)) {
		print STDERR "  $subroutine in $file line $line\n" if $line;
		($file, $line)=($nextfile,$nextline);
	}
	print STDERR "  main in $file line $line\n" if $line;
}

sub import {
	shift;	# skip package name

	# set standard @INC; $l last guarantees root in $INC[-1]
	my $l = "$ENV{SPOROOT}\\tools\\x86\\perl";
	# choose old and busted or new hotness dynamically
	@INC = ($] < 5.008)
		? ("$l\\lib", "$l\\site\\lib", $l)
		: ("$l\\58", "$l\\site\\58", $l);

	# options
	# FUTURE: should carps become croaks?
	while ($_ = shift) {
		if ($_ eq 'libscriptdir') {
			my $zero = (defined $PerlApp::VERSION) ? PerlApp::exe() : $0;
			my ($scriptdir) = $zero =~ m!(.*)[\\/].*!;
			if (defined $scriptdir) {
				unshift @INC, $scriptdir;
			} else {
				require Carp;
				Carp::carp("Script name in \$0 '$zero' includes no directory to add to \@INC in 'import spottools 'libscriptdir''");
			}
		} elsif ($_ eq 'warnfmt') {
			$SIG{__WARN__} = sub { print STDERR "Warning: @_"; callstack; };
			# $SIG{__DIE__} = sub { print STDERR "Error: @_"; callstack; };
		} else {
			require Carp;
			Carp::carp("Unknown option '$_' passed to 'import spottools'");
		}
	}
}

1;

